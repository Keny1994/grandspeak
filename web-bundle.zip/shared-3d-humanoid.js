/* ============================================================================
 * GRANDSPEAK 5★ · SHARED PBR LIGHTING & ANATOMICAL 16-JOINT HUMANOID ENGINE
 * 100% Procedural Three.js r128 (zero external .glb/CDN dependencies).
 * Shared across Resort 3D (/flashcard/city/), Tình huống 3D (/flashcard/places/),
 * and Phòng học 3D (/flashcard/room/).
 * ============================================================================ */
(function () {
  'use strict';
  var T = window.THREE;
  if (!T) return;

  function safeHex(c, fallback) {
    if (c === undefined || c === null || Number.isNaN(c)) return fallback !== undefined ? fallback : 0xffffff;
    return c;
  }
  function shadeHex(c, k) {
    var col = new T.Color(safeHex(c));
    return (k < 1 ? col.multiplyScalar(k) : col.lerp(new T.Color(0xffffff), Math.min(1, k - 1))).getHex();
  }
  function lumHex(c) {
    var col = new T.Color(safeHex(c));
    return col.r * 0.299 + col.g * 0.587 + col.b * 0.114;
  }

  /* ── PROCEDURAL TEXTURES & PBR IBL ENVIRONMENT (CACHED) ── */
  var TEX_CACHE = {};
  function makeCanvasTex(key, w, h, draw, wrap) {
    if (TEX_CACHE[key]) return TEX_CACHE[key];
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h);
    var t = new T.CanvasTexture(c);
    t.encoding = T.sRGBEncoding;
    if (wrap) { t.wrapS = t.wrapT = T.RepeatWrapping; }
    TEX_CACHE[key] = t;
    return t;
  }

  function aoShadowTex() {
    return makeCanvasTex('ao_disc', 128, 128, function (g, w, h) {
      var rg = g.createRadialGradient(w / 2, h / 2, 6, w / 2, h / 2, w / 2 - 2);
      rg.addColorStop(0, 'rgba(12, 22, 18, 0.42)');
      rg.addColorStop(0.55, 'rgba(12, 22, 18, 0.18)');
      rg.addColorStop(1, 'rgba(12, 22, 18, 0)');
      g.fillStyle = rg;
      g.fillRect(0, 0, w, h);
    }, false);
  }

  function fabricBump() {
    if (TEX_CACHE.fabric_bump) return TEX_CACHE.fabric_bump;
    var c = document.createElement('canvas'); c.width = c.height = 64;
    var g = c.getContext('2d');
    g.fillStyle = '#808080'; g.fillRect(0, 0, 64, 64);
    for (var y = 0; y < 64; y += 4) {
      g.fillStyle = y % 8 === 0 ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.12)';
      g.fillRect(0, y, 64, 2);
    }
    for (var x = 0; x < 64; x += 4) {
      g.fillStyle = x % 8 === 0 ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.09)';
      g.fillRect(x, 0, 2, 64);
    }
    var t = new T.CanvasTexture(c);
    t.wrapS = t.wrapT = T.RepeatWrapping;
    t.repeat.set(4, 4);
    TEX_CACHE.fabric_bump = t;
    return t;
  }

  function waterNormal() {
    if (TEX_CACHE.water_bump) return TEX_CACHE.water_bump;
    var c = document.createElement('canvas'); c.width = c.height = 256;
    var g = c.getContext('2d');
    g.fillStyle = '#808080'; g.fillRect(0, 0, 256, 256);
    for (var i = 0; i < 180; i++) {
      var x = (i * 73) % 256, y = (i * 137) % 256, rx = 18 + (i % 5) * 8, ry = 5 + (i % 3) * 3;
      var rg = g.createRadialGradient(x, y, 1, x, y, rx);
      rg.addColorStop(0, i % 2 ? 'rgba(255,255,255,0.22)' : 'rgba(40,40,40,0.2)');
      rg.addColorStop(1, 'rgba(128,128,128,0)');
      g.fillStyle = rg;
      g.save(); g.translate(x, y); g.scale(1, ry / rx); g.beginPath(); g.arc(0, 0, rx, 0, Math.PI * 2); g.fill(); g.restore();
    }
    var t = new T.CanvasTexture(c);
    t.wrapS = t.wrapT = T.RepeatWrapping;
    t.repeat.set(14, 14);
    TEX_CACHE.water_bump = t;
    return t;
  }

  function woodTex(baseHex, darkHex) {
    var k = 'wood_' + safeHex(baseHex, 0x8b5e34) + '_' + safeHex(darkHex, 0x5c3a1e);
    return makeCanvasTex(k, 256, 256, function (g, w, h) {
      g.fillStyle = '#' + new T.Color(safeHex(baseHex, 0x8b5e34)).getHexString();
      g.fillRect(0, 0, w, h);
      g.strokeStyle = '#' + new T.Color(safeHex(darkHex, 0x5c3a1e)).getHexString();
      g.globalAlpha = 0.24;
      for (var y = 0; y < h; y += 6) {
        g.lineWidth = (y % 18 === 0) ? 2 : 1;
        g.beginPath(); g.moveTo(0, y);
        g.bezierCurveTo(w * 0.33, y + Math.sin(y) * 4, w * 0.66, y - Math.cos(y) * 4, w, y);
        g.stroke();
      }
      g.globalAlpha = 1;
    }, true);
  }

  function marbleTex(baseHex, veinHex) {
    var k = 'marble_' + safeHex(baseHex, 0xfaf6ee) + '_' + safeHex(veinHex, 0xc9b38c);
    return makeCanvasTex(k, 256, 256, function (g, w, h) {
      g.fillStyle = '#' + new T.Color(safeHex(baseHex, 0xfaf6ee)).getHexString();
      g.fillRect(0, 0, w, h);
      g.strokeStyle = '#' + new T.Color(safeHex(veinHex, 0xc9b38c)).getHexString();
      g.globalAlpha = 0.28; g.lineWidth = 1.6;
      for (var i = 0; i < 8; i++) {
        g.beginPath(); g.moveTo(0, (i * 34) % h);
        g.bezierCurveTo(w * 0.35, (i * 51 + 40) % h, w * 0.7, (i * 23 + 90) % h, w, (i * 67 + 20) % h);
        g.stroke();
      }
      g.globalAlpha = 1;
    }, true);
  }

  function grassTex() {
    var t = makeCanvasTex('tropical_grass', 256, 256, function (g, w, h) {
      g.fillStyle = '#5da74f';
      g.fillRect(0, 0, w, h);
      var shades = ['#67b357', '#539b46', '#72bd61', '#4d9240'];
      for (var i = 0; i < 420; i++) {
        var x = (i * 53) % w, y = (i * 97) % h;
        g.fillStyle = shades[i % shades.length];
        g.globalAlpha = 0.32;
        g.fillRect(x, y, 6 + (i % 5) * 3, 3 + (i % 3) * 2);
      }
      g.globalAlpha = 1;
    }, true);
    t.repeat.set(32, 26);
    return t;
  }

  function sandTex() {
    var t = makeCanvasTex('coral_sand', 256, 256, function (g, w, h) {
      g.fillStyle = '#dfc38d';
      g.fillRect(0, 0, w, h);
      for (var y = 0; y < h; y += 8) {
        g.strokeStyle = (y % 16 === 0) ? 'rgba(255,248,230,0.22)' : 'rgba(180,145,92,0.16)';
        g.lineWidth = 3;
        g.beginPath(); g.moveTo(0, y);
        g.bezierCurveTo(w * 0.33, y + 2, w * 0.66, y - 2, w, y);
        g.stroke();
      }
      for (var i = 0; i < 260; i++) {
        g.fillStyle = (i % 2) ? 'rgba(255,250,235,0.24)' : 'rgba(166,130,78,0.18)';
        g.fillRect((i * 67) % w, (i * 113) % h, 2, 2);
      }
    }, true);
    t.repeat.set(28, 8);
    return t;
  }

  function setupPBR(renderer, scene, opts) {
    opts = opts || {};
    if (!renderer || !scene) return;
    renderer.outputEncoding = T.sRGBEncoding;
    if (T.LinearToneMapping !== undefined) {
      renderer.toneMapping = T.LinearToneMapping;
      renderer.toneMappingExposure = opts.exposure || 0.92;
    } else if (T.NoToneMapping !== undefined) {
      renderer.toneMapping = T.NoToneMapping;
    }
  }

  /* ── CACHED SCULPTED GEOMETRIES FOR 16-JOINT ANATOMICAL HUMANOID ──
   * Canonical human proportions: 1.0x height = ~2.80 units (head ~0.39, shoulder width ~0.58)
   */
  var GEO = null;
  var MAT = {};
  function pbrMat(c, opts) {
    var hc = safeHex(c, 0xffffff);
    var k = hc + '|' + (opts ? JSON.stringify(opts) : '');
    if (!MAT[k]) {
      MAT[k] = new T.MeshStandardMaterial(Object.assign({
        color: hc, roughness: 0.72, metalness: 0.05
      }, opts || {}));
    }
    return MAT[k];
  }
  function skinMat(c) {
    var hc = safeHex(c, 0xf2c9a6);
    var k = 'skin_' + hc;
    if (!MAT[k]) MAT[k] = new T.MeshStandardMaterial({ color: hc, roughness: 0.56, metalness: 0.02 });
    return MAT[k];
  }
  function clothMat(c) {
    var hc = safeHex(c, 0x163a2c);
    var k = 'cloth_' + hc;
    if (!MAT[k]) MAT[k] = new T.MeshStandardMaterial({ color: hc, roughness: 0.76, metalness: 0.03, bumpMap: fabricBump(), bumpScale: 0.008 });
    return MAT[k];
  }

  function initGeo() {
    if (GEO) return GEO;
    function lathePts(arr, seg) {
      return new T.LatheGeometry(arr.map(function (p) { return new T.Vector2(p[0], p[1]); }), seg || 20);
    }

    /* Sculpted male & female torsos with anatomically realistic waist/chest/shoulder taper */
    var torsoM = lathePts([
      [0.01, 0.0], [0.185, 0.02], [0.175, 0.16], [0.172, 0.30], [0.205, 0.48],
      [0.235, 0.64], [0.245, 0.76], [0.195, 0.84], [0.095, 0.87], [0.01, 0.88]
    ], 22);
    var torsoF = lathePts([
      [0.01, 0.0], [0.188, 0.02], [0.155, 0.18], [0.145, 0.30], [0.185, 0.46],
      [0.210, 0.62], [0.212, 0.74], [0.170, 0.82], [0.085, 0.86], [0.01, 0.87]
    ], 22);

    /* Anatomical cranium + tapered jaw + cheekbones */
    var head = lathePts([
      [0.00, -0.175], [0.055, -0.165], [0.098, -0.135], [0.128, -0.085],
      [0.146, -0.020], [0.156, 0.045], [0.158, 0.110], [0.142, 0.165],
      [0.095, 0.205], [0.00, 0.218]
    ], 24);

    /* Sculpted upper arm (shoulder -> bicep -> elbow) & forearm (elbow -> taper -> wrist) */
    var upperArm = lathePts([
      [0.00, 0.03], [0.068, 0.0], [0.066, -0.10], [0.058, -0.22], [0.050, -0.34], [0.045, -0.37], [0.00, -0.38]
    ], 14);
    var foreArm = lathePts([
      [0.00, 0.02], [0.049, 0.0], [0.052, -0.09], [0.044, -0.20], [0.036, -0.33], [0.032, -0.35], [0.00, -0.36]
    ], 14);

    /* Sculpted thigh & calf */
    var thigh = lathePts([
      [0.00, 0.04], [0.098, 0.0], [0.096, -0.12], [0.084, -0.30], [0.070, -0.49], [0.062, -0.53], [0.00, -0.54]
    ], 16);
    var calf = lathePts([
      [0.00, 0.03], [0.064, 0.0], [0.072, -0.14], [0.064, -0.28], [0.048, -0.48], [0.044, -0.51], [0.00, -0.52]
    ], 16);

    /* Tailored leather shoe / heel (ExtrudeGeometry silhouette) */
    var shoeShape = new T.Shape();
    shoeShape.moveTo(-0.05, -0.07);
    shoeShape.lineTo(0.05, -0.07);
    shoeShape.quadraticCurveTo(0.058, 0.04, 0.046, 0.14);
    shoeShape.quadraticCurveTo(0.0, 0.185, -0.046, 0.14);
    shoeShape.quadraticCurveTo(-0.058, 0.04, -0.05, -0.07);
    var shoeGeo = new T.ExtrudeGeometry(shoeShape, { depth: 0.062, bevelEnabled: true, bevelThickness: 0.015, bevelSize: 0.012, bevelSegments: 2 });
    shoeGeo.rotateX(Math.PI / 2);

    /* Jacket left/right lapel */
    var lapelShape = new T.Shape();
    lapelShape.moveTo(0, 0);
    lapelShape.lineTo(0.065, 0.24);
    lapelShape.lineTo(0.022, 0.34);
    lapelShape.lineTo(-0.015, 0.20);
    lapelShape.closePath();
    var lapelGeo = new T.ExtrudeGeometry(lapelShape, { depth: 0.016, bevelEnabled: true, bevelThickness: 0.004, bevelSize: 0.004, bevelSegments: 1 });

    /* Vertex-sculpted hair shell with realistic hairline & generous cranium coverage (no skull poke-through) */
    var hairShell = new T.SphereGeometry(1, 28, 16, -Math.PI / 2, Math.PI * 2, 0, Math.PI);
    var hp = hairShell.attributes.position, hn = hairShell.attributes.normal;
    for (var hi = 0; hi < hp.count; hi++) {
      var ux = hp.getX(hi), uy = hp.getY(hi), uz = hp.getZ(hi);
      var hv = Math.acos(Math.max(-1, Math.min(1, uy))) / Math.PI;
      var az = Math.atan2(ux, uz), fr = Math.cos(az), fp = Math.max(0, fr);
      var line = 0.62 + (fr < 0 ? -0.22 * fr : -0.18 * Math.pow(fr, 1.4)) + 0.06 * Math.sin(az) * fp;
      var th = hv * line * Math.PI;
      var hr = 0.182 - 0.008 * Math.pow(hv, 3) + 0.012 * Math.sin(hv * Math.PI) * fp;
      var nx = Math.sin(th) * Math.sin(az), ny = Math.cos(th), nz = Math.sin(th) * Math.cos(az);
      hp.setXYZ(hi, nx * hr, ny * hr * 1.28, nz * hr * 1.10);
      hn.setXYZ(hi, nx, ny, nz);
    }

    /* Ao Dai flowing panel (tapered trapezoid) */
    var panelShape = new T.Shape();
    panelShape.moveTo(-0.145, 0); panelShape.lineTo(0.145, 0);
    panelShape.lineTo(0.19, -0.78); panelShape.lineTo(-0.19, -0.78); panelShape.closePath();
    var aoPanel = new T.ExtrudeGeometry(panelShape, { depth: 0.024, bevelEnabled: true, bevelThickness: 0.005, bevelSize: 0.004, bevelSegments: 1 });

    /* Sculpted skirt */
    var skirt = lathePts([[0.18, 0.02], [0.215, -0.12], [0.255, -0.34], [0.285, -0.52]], 22);
    var longSkirt = lathePts([[0.17, 0.02], [0.21, -0.24], [0.25, -0.62], [0.275, -0.92]], 22);

    /* Sculpted nose ridge, ear, iris & palm */
    var nose = new T.ConeGeometry(0.022, 0.062, 6);
    var ear = new T.SphereGeometry(0.032, 10, 8);
    var eyeSclera = new T.SphereGeometry(0.026, 12, 10);
    var eyeIris = new T.SphereGeometry(0.016, 12, 10);
    var eyePupil = new T.SphereGeometry(0.0085, 8, 8);
    var catchlight = new T.SphereGeometry(0.0045, 6, 6);
    var palm = new T.SphereGeometry(0.038, 12, 10);
    var thumb = new T.CylinderGeometry(0.009, 0.011, 0.036, 6);
    var fingers = new T.SphereGeometry(0.028, 10, 8);

    GEO = {
      torsoM: torsoM, torsoF: torsoF, head: head, upperArm: upperArm, foreArm: foreArm,
      thigh: thigh, calf: calf, shoe: shoeGeo, lapel: lapelGeo, hairShell: hairShell,
      aoPanel: aoPanel, skirt: skirt, longSkirt: longSkirt, nose: nose, ear: ear,
      eyeSclera: eyeSclera, eyeIris: eyeIris, eyePupil: eyePupil, catchlight: catchlight,
      palm: palm, thumb: thumb, fingers: fingers
    };
    return GEO;
  }

  function addM(geo, m, x, y, z, p, sh) {
    var o = new T.Mesh(geo, m);
    o.position.set(x || 0, y || 0, z || 0);
    if (sh !== false) o.castShadow = true;
    o.receiveShadow = true;
    if (p) p.add(o);
    return o;
  }

  function makeHumanoid(spec) {
    spec = spec || {};
    var G = initGeo();
    var g = new T.Group();
    var targetH = spec.height || 2.80;
    var rigScale = targetH / 2.78;
    var rig = new T.Group();
    rig.scale.setScalar(rigScale);
    g.add(rig);

    /* Soft AO contact shadow on ground */
    var aoM = new T.MeshBasicMaterial({ map: aoShadowTex(), transparent: true, depthWrite: false, opacity: 0.72 });
    var ao = new T.Mesh(new T.PlaneGeometry(0.95, 0.95), aoM);
    ao.rotation.x = -Math.PI / 2; ao.position.y = 0.02; ao.castShadow = false; ao.receiveShadow = false;
    g.add(ao);

    var skColor = safeHex(spec.skin, 0xf2c9a6);
    var topColor = safeHex(spec.top || spec.shirt, 0x163a2c);
    var legColor = safeHex(spec.leg || spec.pants, 0x12261f);
    var hairColor = safeHex(spec.hair, 0x241c18);
    var shoeColor = safeHex(spec.shoe, lumHex(legColor) > 0.45 ? 0x5c3a1e : 0x18181b);
    var longSleeve = spec.longSleeve !== undefined ? !!spec.longSleeve : (!!spec.tie || !!spec.vest || !!spec.dress || !!spec.toque || lumHex(topColor) < 0.25);
    var female = !!(spec.long || spec.dress || spec.skirt || spec.female);

    var skinM = skinMat(skColor);
    var topM = clothMat(topColor);
    var vestM = spec.vest ? clothMat(spec.vest) : topM;
    var legM = clothMat(legColor);
    var shoeM = pbrMat(shoeColor, { roughness: 0.36, metalness: 0.14 });
    var whiteM = clothMat(0xfaf8f3);
    var goldM = pbrMat(0xd4a94e, { roughness: 0.28, metalness: 0.65 });
    var hairM = pbrMat(hairColor, { roughness: 0.62, metalness: 0.04, side: T.DoubleSide });
    var darkM = pbrMat(0x1e293b, { roughness: 0.3 });

    /* Hip root at anatomical leg height y = 1.18 (thigh 0.52 + calf 0.50 + ankle/sole 0.16) */
    var HIP_Y = 1.18;
    var hips = new T.Group();
    hips.position.y = HIP_Y;
    rig.add(hips);

    /* Pelvis + Belt */
    var pelvis = addM(new T.SphereGeometry(0.182, 18, 12), legM, 0, 0.02, 0, hips);
    pelvis.scale.set(1.06, 0.62, 0.72);
    if (!spec.dress) {
      var belt = addM(new T.CylinderGeometry(0.182, 0.186, 0.055, 18), shoeM, 0, 0.075, 0, hips);
      belt.scale.z = 0.72;
      addM(new T.BoxGeometry(0.055, 0.042, 0.02), goldM, 0, 0.075, 0.132, hips);
    }

    /* Spine / Chest (pivots at lower back y = 0.08) */
    var chest = new T.Group();
    chest.position.y = 0.08;
    hips.add(chest);

    var torso = addM(female ? G.torsoF : G.torsoM, spec.vest ? vestM : topM, 0, -0.04, 0, chest);
    torso.scale.set(1.04, 1.0, 0.68);

    /* Jacket Lapels, Crisp Collar & Role-Specific 5★ Uniform Insignia */
    if (spec.tie || spec.vest || spec.bowtie) {
      var shirtV = addM(new T.BoxGeometry(0.11, 0.34, 0.03), whiteM, 0, 0.60, 0.145, chest);
      shirtV.rotation.x = -0.06;
      var l1 = addM(G.lapel, clothMat(shadeHex(spec.vest || topColor, 0.85)), -0.05, 0.42, 0.148, chest);
      l1.rotation.z = 0.14;
      var l2 = addM(G.lapel, clothMat(shadeHex(spec.vest || topColor, 0.85)), 0.05, 0.42, 0.148, chest);
      l2.scale.x = -1; l2.rotation.z = -0.14;
      if (spec.bowtie) {
        var btM = clothMat(spec.bowtie === true ? 0x111827 : spec.bowtie);
        addM(new T.BoxGeometry(0.036, 0.028, 0.024), btM, -0.024, 0.74, 0.158, chest).rotation.z = 0.18;
        addM(new T.BoxGeometry(0.036, 0.028, 0.024), btM, 0.024, 0.74, 0.158, chest).rotation.z = -0.18;
        addM(new T.BoxGeometry(0.018, 0.022, 0.026), goldM, 0, 0.74, 0.160, chest);
      } else if (spec.tie) {
        var tieM = clothMat(spec.tie);
        addM(new T.BoxGeometry(0.042, 0.038, 0.024), tieM, 0, 0.73, 0.156, chest);
        var tieBody = addM(new T.BoxGeometry(0.038, 0.25, 0.016), tieM, 0, 0.57, 0.154, chest);
        tieBody.rotation.x = -0.06;
      }
      /* 5-Star Golden Hospitality Nameplate on left chest */
      addM(new T.BoxGeometry(0.062, 0.022, 0.012), goldM, 0.095, 0.62, 0.148, chest);
    }
    /* Double-breasted Chef Coat Buttons */
    if (spec.toque || spec.chefButtons) {
      [-0.048, 0.048].forEach(function (bx) {
        [0.34, 0.46, 0.58, 0.68].forEach(function (by) {
          addM(new T.SphereGeometry(0.012, 8, 6), darkM, bx, by, 0.152, chest, false);
        });
      });
    }
    /* Bellman / Captain Golden Epaulets & Brass Buttons */
    if (spec.epaulets) {
      [-1, 1].forEach(function (s) {
        addM(new T.BoxGeometry(0.095, 0.024, 0.065), goldM, s * (female ? 0.195 : 0.215), 0.79, 0.01, chest, false).rotation.z = -s * 0.15;
      });
      [-0.052, 0.052].forEach(function (bx) {
        [0.36, 0.49, 0.62].forEach(function (by) {
          addM(new T.SphereGeometry(0.013, 8, 6), goldM, bx, by, 0.154, chest, false);
        });
      });
    }
    /* Les Clefs d'Or Crossed Golden Keys (VIP Concierge) */
    if (spec.clefsDor) {
      [-1, 1].forEach(function (s) {
        var kPin = addM(new T.BoxGeometry(0.036, 0.010, 0.012), goldM, s * 0.088, 0.69, 0.156, chest, false);
        kPin.rotation.z = s * 0.65;
      });
    }
    /* Sommelier Silver Tastevin Cup & Ribbon */
    if (spec.tastevin) {
      var silM = pbrMat(0xe2e8f0, { roughness: 0.2, metalness: 0.8 });
      addM(new T.CylinderGeometry(0.028, 0.022, 0.014, 12), silM, 0, 0.48, 0.162, chest, false).rotation.x = Math.PI / 2;
    }
    var collar = addM(new T.TorusGeometry(0.088, 0.022, 8, 18), spec.dress ? topM : whiteM, 0, 0.82, 0.005, chest);
    collar.rotation.x = Math.PI / 2; collar.scale.z = 0.82;

    if (spec.apron) {
      var apronM = clothMat(spec.apron);
      var ap = addM(new T.LatheGeometry([
        [0.195, -0.42], [0.185, -0.18], [0.192, 0.08], [0.196, 0.30]
      ].map(function (p) { return new T.Vector2(p[0], p[1]); }), 18, -0.82, 1.64), apronM, 0, 0.06, 0, chest);
      ap.material = new T.MeshStandardMaterial({ color: safeHex(spec.apron), roughness: 0.74, side: T.DoubleSide });
      ap.scale.z = 0.72;
      [-1, 1].forEach(function (s) {
        var st = addM(new T.BoxGeometry(0.032, 0.42, 0.014), apronM, s * 0.095, 0.56, 0.145, chest);
        st.rotation.z = s * 0.14;
      });
    }

    var frontPanel = null, backPanel = null, skirtMesh = null;
    if (spec.dress) {
      frontPanel = addM(G.aoPanel, clothMat(topColor), 0, 0.06, 0.105, hips);
      frontPanel.material = new T.MeshStandardMaterial({ color: safeHex(topColor), roughness: 0.68, side: T.DoubleSide });
      backPanel = addM(G.aoPanel, frontPanel.material, 0, 0.06, -0.115, hips);
      var beltTrim = addM(new T.CylinderGeometry(0.168, 0.172, 0.045, 20), goldM, 0, 0.08, 0, hips);
      beltTrim.scale.z = 0.72;
      addM(new T.BoxGeometry(0.045, 0.032, 0.018), goldM, 0.08, 0.58, 0.145, chest);
    } else if (spec.skirt) {
      skirtMesh = addM(G.skirt, clothMat(spec.skirt), 0, 0.02, 0, hips);
      skirtMesh.material = new T.MeshStandardMaterial({ color: safeHex(spec.skirt), roughness: 0.72, side: T.DoubleSide });
      skirtMesh.scale.z = 0.76;
    }

    /* Neck & Sculpted Cranium */
    var neck = addM(new T.CylinderGeometry(0.056, 0.068, 0.14, 14), skinM, 0, 0.88, 0, chest);
    void neck;
    var head = new T.Group();
    head.position.set(0, 1.08, 0.01);
    chest.add(head);

    var skull = addM(G.head, skinM, 0, 0, 0, head);
    skull.scale.set(1.0, 1.0, 1.06);

    /* Ears, Nose Bridge & Facial Structure */
    [-1, 1].forEach(function (s) {
      var er = addM(G.ear, skinM, s * 0.156, 0.0, -0.01, head, false);
      er.scale.set(0.45, 1.15, 0.75);
    });
    var noseM = pbrMat(shadeHex(skColor, 0.94), { roughness: 0.54 });
    var ns = addM(G.nose, noseM, 0, -0.008, 0.165, head, false);
    ns.rotation.x = 0.42; ns.scale.set(0.75, 1.15, 0.85);

    /* Expressive Layered Eyes (Sclera + Iris + Pupil + Catchlight + Eyelashes) */
    var irisColor = lumHex(hairColor) < 0.16 ? 0x2b1d14 : 0x3b4e63;
    var scleraM = pbrMat(0xfdfdfd, { roughness: 0.2 });
    var irisM = pbrMat(irisColor, { roughness: 0.25 });
    var lipColor = female ? 0xc25964 : 0xb56862;
    var lipM = pbrMat(lipColor, { roughness: 0.48 });
    var blushM = pbrMat(0xf2a79c, { roughness: 0.7, transparent: true, opacity: 0.55 });

    var eyes = [-1, 1].map(function (s) {
      var ew = new T.Group();
      ew.position.set(s * 0.056, 0.036, 0.138);
      head.add(ew);
      var sc = addM(G.eyeSclera, scleraM, 0, 0, 0, ew, false); sc.scale.set(1.18, 0.92, 0.52);
      var ir = addM(G.eyeIris, irisM, 0, 0, 0.009, ew, false); ir.scale.set(1.0, 1.02, 0.55);
      addM(G.eyePupil, darkM, 0, 0, 0.013, ew, false).scale.set(1, 1, 0.6);
      addM(G.catchlight, scleraM, 0.007, 0.008, 0.017, ew, false);

      /* Eyelash upper arch */
      var lash = addM(new T.BoxGeometry(0.052, 0.009, 0.014), hairM, 0, 0.024, 0.010, ew, false);
      lash.rotation.z = s * -0.06;

      /* Sculpted eyebrow in head space */
      var brow = addM(new T.BoxGeometry(0.058, 0.012, 0.014), hairM, s * 0.058, 0.088, 0.146, head, false);
      brow.rotation.z = s * -0.08;
      /* Subtle warm cheek blush */
      var ch = addM(new T.SphereGeometry(0.032, 8, 6), blushM, s * 0.095, -0.032, 0.125, head, false);
      ch.scale.set(1.1, 0.55, 0.3);
      return ew;
    });

    /* Mouth: Gentle Smile Arch + Animated Speech Lip Opening */
    var smile = addM(new T.TorusGeometry(0.032, 0.0065, 6, 14, Math.PI), lipM, 0, -0.068, 0.140, head, false);
    smile.rotation.set(0.24, 0, Math.PI);
    var mouth = addM(new T.SphereGeometry(0.025, 10, 8), pbrMat(0x7c2d36, { roughness: 0.5 }), 0, -0.082, 0.136, head, false);
    mouth.scale.set(1.15, 0.72, 0.45);
    mouth.visible = false;

    /* Sculpted 3D Hair Styles + Hospitality Headwear */
    var hShell = addM(G.hairShell, hairM, 0, 0.015, -0.01, head);
    hShell.rotation.x = -0.26;
    /* Top crown volume + sideburns / temple framing locks */
    var crownCap = addM(new T.SphereGeometry(0.165, 16, 10), hairM, 0, 0.085, -0.01, head);
    crownCap.scale.set(1.02, 0.92, 1.05);
    [-1, 1].forEach(function (s) {
      var lock = addM(new T.SphereGeometry(0.048, 10, 8), hairM, s * 0.146, -0.01, 0.035, head, false);
      lock.scale.set(0.48, female ? 2.4 : 1.2, 0.75);
    });
    /* Stylized front hair swoop / bangs */
    var bang = addM(new T.SphereGeometry(0.11, 14, 10), hairM, 0.015, 0.148, 0.072, head, false);
    bang.scale.set(1.25, 0.56, 0.95); bang.rotation.z = -0.15;
    if (female && !spec.toque && !spec.cap) {
      /* Classic Chignon Low Bun with Golden Trâm Cài tucked flush to nape */
      var bun = addM(new T.SphereGeometry(0.078, 12, 10), hairM, 0, -0.035, -0.155, head);
      bun.scale.set(1.08, 0.95, 0.88);
      if (spec.dress) {
        var pin = addM(new T.CylinderGeometry(0.006, 0.004, 0.24, 6), goldM, 0, -0.025, -0.175, head, false);
        pin.rotation.z = 1.25;
      } else if (spec.long) {
        var backHair = addM(new T.LatheGeometry([
          [0.01, 0.06], [0.155, 0.0], [0.175, -0.12], [0.165, -0.26], [0.125, -0.34], [0.01, -0.36]
        ].map(function (p) { return new T.Vector2(p[0], p[1]); }), 16, Math.PI * 0.55, Math.PI * 0.9), hairM, 0, 0.02, -0.01, head);
        backHair.scale.z = 1.05;
      }
    }
    if (spec.toque) {
      addM(new T.CylinderGeometry(0.148, 0.138, 0.14, 18), whiteM, 0, 0.19, 0, head);
      var puff = addM(new T.SphereGeometry(0.172, 18, 12), whiteM, 0, 0.30, 0, head);
      puff.scale.set(1, 0.68, 1);
    } else if (spec.cap) {
      var capM = clothMat(spec.cap);
      addM(new T.CylinderGeometry(0.162, 0.168, 0.075, 18), capM, 0, 0.16, 0, head);
      addM(new T.SphereGeometry(0.162, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.5), capM, 0, 0.195, 0, head).scale.set(1, 0.45, 1);
      var brim = addM(new T.CylinderGeometry(0.135, 0.135, 0.016, 16, 1, false, -0.9, 1.8), pbrMat(shadeHex(spec.cap, 0.65), { roughness: 0.3 }), 0, 0.135, 0.09, head);
      brim.rotation.x = 0.18;
      addM(new T.BoxGeometry(0.04, 0.028, 0.015), goldM, 0, 0.165, 0.165, head, false);
    } else if (spec.crown) {
      var cr = addM(new T.CylinderGeometry(0.088, 0.072, 0.068, 8), goldM, 0, 0.215, 0, head);
      cr.rotation.y = 0.4;
    }

    /* ── ARTICULATED 3-JOINT ARMS (Shoulder → Elbow → Sculpted Hand / Butler Glove) ── */
    var sleeveM = (spec.vest && !spec.dress && spec.shirtSleeve) ? whiteM : (longSleeve ? topM : skinM);
    var handM = spec.gloves ? whiteM : skinM;
    var arms = [-1, 1].map(function (s) {
      var sh = new T.Group();
      sh.position.set(s * (female ? 0.245 : 0.268), 0.72, 0);
      chest.add(sh);

      addM(new T.SphereGeometry(0.072, 12, 10), sleeveM, 0, 0, 0, sh);
      if (longSleeve) {
        addM(G.upperArm, sleeveM, 0, 0, 0, sh);
      } else {
        var shortSlv = addM(G.upperArm, topM, 0, 0, 0, sh);
        shortSlv.scale.set(1.06, 0.56, 1.06);
        addM(G.upperArm, skinM, 0, -0.04, 0, sh).scale.set(0.86, 0.92, 0.86);
      }

      var elb = new T.Group();
      elb.position.y = -0.35;
      sh.add(elb);
      addM(new T.SphereGeometry(0.048, 10, 8), sleeveM, 0, 0, 0, elb, false);
      addM(G.foreArm, sleeveM, 0, 0, 0, elb);
      if (longSleeve) {
        addM(new T.CylinderGeometry(0.036, 0.034, 0.032, 10), whiteM, 0, -0.33, 0, elb, false);
      }

      /* Sculpted Palm + Thumb + Curved Fingers */
      var wrist = new T.Group();
      wrist.position.y = -0.365;
      elb.add(wrist);
      var pm = addM(G.palm, handM, 0, -0.032, 0, wrist, false); pm.scale.set(0.62, 1.05, 0.95);
      var fg = addM(G.fingers, handM, 0, -0.082, 0.008, wrist, false); fg.scale.set(0.62, 1.15, 0.92);
      var th = addM(G.thumb, handM, -s * 0.022, -0.025, 0.036, wrist, false);
      th.rotation.set(0.55, 0, -s * 0.35);

      sh.rotation.z = s * 0.08;
      return { sh: sh, elb: elb, wrist: wrist, s: s };
    });

    /* ── ARTICULATED 3-JOINT LEGS (Hip → Knee → Calf → Tailored Shoe) ── */
    var legSkin = (spec.skirt && !spec.dress) ? skinM : legM;
    var legs = [-1, 1].map(function (s) {
      var hp = new T.Group();
      hp.position.set(s * 0.105, 0, 0);
      hips.add(hp);
      addM(new T.SphereGeometry(0.095, 12, 10), legM, 0, 0, 0, hp, false);
      addM(G.thigh, legM, 0, 0, 0, hp);

      var kn = new T.Group();
      kn.position.y = -0.51;
      hp.add(kn);
      addM(new T.SphereGeometry(0.062, 10, 8), legSkin, 0, 0, 0, kn, false);
      addM(G.calf, legSkin, 0, 0, 0, kn);

      var foot = new T.Group();
      foot.position.y = -0.51;
      kn.add(foot);
      addM(G.shoe, shoeM, 0, -0.068, 0.035, foot);
      return { hp: hp, kn: kn, foot: foot, s: s };
    });

    /* ── LIVING HUMAN KINEMATICS STATE CONTROLLER ── */
    var seed = Math.random() * 100;
    var blinkTimer = 1.4 + Math.random() * 3.2;
    var blinkDur = 0;
    var headYaw = 0, headPitch = 0, chestBend = 0, pendingLookYaw = null;
    var waveUntil = 0, bowUntil = 0, sitMode = false, driveMode = false;

    function lerpAng(cur, target, alpha) {
      return cur + (target - cur) * Math.min(1, alpha);
    }

    function applyKinematics(ph, moving, dt, opts) {
      dt = Math.min(0.05, dt || 0.016);
      opts = opts || {};
      var nowSec = performance.now() * 0.001 + seed;
      if (waveUntil > 0) waveUntil = Math.max(0, waveUntil - dt);
      if (bowUntil > 0) bowUntil = Math.max(0, bowUntil - dt);

      /* Natural Blinking */
      blinkTimer -= dt;
      if (blinkTimer <= 0) {
        blinkDur = 0.13;
        blinkTimer = 2.4 + Math.random() * 3.4;
      }
      var eyeScaleY = 1;
      if (blinkDur > 0) {
        blinkDur = Math.max(0, blinkDur - dt);
        eyeScaleY = 0.12;
      }
      eyes[0].scale.y = eyeScaleY;
      eyes[1].scale.y = eyeScaleY;

      var talk = !!(opts.talk || g.userData.talk);
      var aiState = opts.state || g.userData.aiState || 'idle';
      var waving = !moving && (waveUntil > 0 || aiState === 'wave' || (opts.clk && opts.clk < (g.userData.waveUntil || 0)));
      var bowing = !moving && (bowUntil > 0 || aiState === 'bow');
      var sitting = !!(opts.sit || sitMode || driveMode);
      var riding = !!(opts.drive || driveMode);

      /* Talk Mouth Lip-Sync */
      smile.visible = !talk;
      mouth.visible = talk;
      if (talk) {
        mouth.scale.y = 0.45 + Math.abs(Math.sin(nowSec * 12.5)) * 0.75;
        mouth.scale.x = 0.95 + Math.sin(nowSec * 7.3) * 0.2;
      }

      /* Gaze Tracking (Local Yaw/Pitch toward POI or Player) */
      var wantHeadYaw = opts.lookYaw !== undefined ? opts.lookYaw : (pendingLookYaw !== null ? pendingLookYaw : (aiState === 'admire' ? Math.sin(nowSec * 0.7) * 0.42 : Math.sin(nowSec * 0.55) * 0.11));
      pendingLookYaw = null;
      var wantHeadPitch = opts.lookPitch !== undefined ? opts.lookPitch : (talk ? Math.sin(nowSec * 5.2) * 0.05 : aiState === 'notes' ? 0.28 : 0.02);
      headYaw = lerpAng(headYaw, Math.max(-0.68, Math.min(0.68, wantHeadYaw)), dt * 6);
      headPitch = lerpAng(headPitch, Math.max(-0.35, Math.min(0.45, wantHeadPitch)), dt * 6);
      head.rotation.y = headYaw;
      head.rotation.x = headPitch + (bowing ? 0.22 : 0);

      if (sitting) {
        var biking = !!opts.bike;
        hips.position.y = typeof opts.sit === 'number' ? opts.sit : (riding ? 0.72 : 0.62);
        hips.rotation.set(0, 0, 0);
        var sitLean = biking ? 0.22 : (riding ? 0.08 : (aiState === 'notes' ? 0.16 : 0.04));
        chestBend = lerpAng(chestBend, sitLean, dt * 6);
        chest.rotation.set(chestBend, headYaw * 0.15, 0);
        if (skirtMesh) { skirtMesh.rotation.x = -1.32; skirtMesh.scale.y = 0.65; }
        if (frontPanel) { frontPanel.rotation.x = -1.42; backPanel.rotation.x = -1.35; }
        legs.forEach(function (lg, li) {
          if (biking) {
            var ped = ph + (li ? Math.PI : 0);
            lg.hp.rotation.x = -0.92 + Math.sin(ped) * 0.42;
            lg.kn.rotation.x = 1.05 - Math.sin(ped) * 0.38;
            lg.foot.rotation.x = -0.15;
          } else {
            lg.hp.rotation.x = riding ? -1.32 : -1.48;
            lg.kn.rotation.x = riding ? 1.18 : 1.48;
            lg.foot.rotation.x = riding ? -0.12 : 0;
          }
        });
        arms.forEach(function (ar, i) {
          if (i === 1 && waving) {
            ar.sh.rotation.x = -2.25; ar.sh.rotation.z = 0.28;
            ar.elb.rotation.x = -0.75; ar.elb.rotation.z = Math.sin(nowSec * 10.5) * 0.38;
          } else if (riding) {
            ar.sh.rotation.x = biking ? -1.18 : -1.12;
            ar.sh.rotation.z = -ar.s * (biking ? 0.08 : 0.16);
            ar.elb.rotation.x = biking ? -0.42 : -0.58;
            ar.elb.rotation.z = (opts.steer || 0) * 0.22;
          } else if (aiState === 'notes' && i === 1) {
            ar.sh.rotation.x = -0.82; ar.sh.rotation.z = -0.14;
            ar.elb.rotation.x = -0.85 + Math.sin(nowSec * 8) * 0.08;
            ar.elb.rotation.z = Math.cos(nowSec * 5) * 0.06;
          } else {
            ar.sh.rotation.x = -0.78 + Math.sin(nowSec * 1.6 + i) * 0.03;
            ar.sh.rotation.z = ar.s * 0.08;
            ar.elb.rotation.x = -0.72;
            ar.elb.rotation.z = 0;
          }
        });
        return;
      }

      if (skirtMesh) { skirtMesh.rotation.x = 0; skirtMesh.scale.y = 1; }

      /* Standing / Walking Biomechanics */
      var w = moving ? Math.sin(ph) : 0;
      var idleShift = !moving && !bowing ? Math.sin(nowSec * 0.95) * 0.035 : 0;
      var stepLen = (spec.dress || spec.skirt) ? 0.34 : 0.56;

      hips.position.y = HIP_Y + (moving ? Math.abs(Math.sin(ph)) * 0.048 - 0.024 : Math.sin(nowSec * 1.9) * 0.008);
      hips.rotation.y = moving ? Math.sin(ph) * 0.085 : idleShift * 0.6;
      hips.rotation.z = moving ? Math.cos(ph) * 0.032 : idleShift * 0.4;

      var wantChestX = bowing ? 0.34 : (moving ? 0.06 : 0.01 + Math.sin(nowSec * 1.9) * 0.012);
      chestBend = lerpAng(chestBend, wantChestX, dt * 7);
      chest.rotation.x = chestBend;
      chest.rotation.y = moving ? -Math.sin(ph) * 0.095 : (talk ? Math.sin(nowSec * 1.8) * 0.07 : headYaw * 0.18);
      chest.rotation.z = moving ? -hips.rotation.z * 0.65 : 0;

      /* Flowing Ao Dai Silk Panels */
      if (frontPanel) {
        frontPanel.rotation.x = moving ? -0.18 - Math.abs(w) * 0.16 : -0.04;
        backPanel.rotation.x = moving ? 0.22 + Math.abs(w) * 0.18 : 0.05;
      }

      /* Articulated Legs: Swing + Knee Flexion + Heel Strike */
      legs.forEach(function (lg, i) {
        var p = ph + (i ? Math.PI : 0);
        if (moving) {
          var swingHip = -Math.sin(p) * stepLen;
          var kneeBend = Math.max(0.05, Math.cos(p) * (spec.dress ? 0.52 : 0.88));
          lg.hp.rotation.x = swingHip;
          lg.kn.rotation.x = kneeBend;
          lg.foot.rotation.x = -swingHip * 0.35 - kneeBend * 0.28;
        } else {
          lg.hp.rotation.x = lerpAng(lg.hp.rotation.x, (i === 0 ? idleShift : -idleShift) * 0.8, dt * 8);
          lg.kn.rotation.x = lerpAng(lg.kn.rotation.x, 0.04, dt * 8);
          lg.foot.rotation.x = lerpAng(lg.foot.rotation.x, 0, dt * 8);
        }
      });

      /* Articulated Arms: Swing Counter-Phase / Hospitality Bow / Waving / Talking / Pointing */
      arms.forEach(function (ar, i) {
        if (bowing) {
          if (i === 1) {
            ar.sh.rotation.x = lerpAng(ar.sh.rotation.x, -0.95, dt * 8);
            ar.sh.rotation.z = lerpAng(ar.sh.rotation.z, -0.35, dt * 8);
            ar.elb.rotation.x = lerpAng(ar.elb.rotation.x, -1.25, dt * 8);
            ar.elb.rotation.z = 0;
          } else {
            ar.sh.rotation.x = lerpAng(ar.sh.rotation.x, -0.22, dt * 8);
            ar.sh.rotation.z = lerpAng(ar.sh.rotation.z, -0.05, dt * 8);
            ar.elb.rotation.x = lerpAng(ar.elb.rotation.x, -0.45, dt * 8);
          }
          return;
        }
        if (i === 1 && waving) {
          ar.sh.rotation.x = lerpAng(ar.sh.rotation.x, -2.35, dt * 10);
          ar.sh.rotation.z = lerpAng(ar.sh.rotation.z, 0.28, dt * 10);
          ar.elb.rotation.x = lerpAng(ar.elb.rotation.x, -0.62, dt * 10);
          ar.elb.rotation.z = Math.sin(nowSec * 11) * 0.36;
          return;
        }
        if (aiState === 'point_board' && i === 1 && !moving) {
          ar.sh.rotation.x = lerpAng(ar.sh.rotation.x, -1.38 + Math.sin(nowSec * 2.4) * 0.14, dt * 6);
          ar.sh.rotation.z = lerpAng(ar.sh.rotation.z, 0.22 + Math.cos(nowSec * 1.9) * 0.08, dt * 6);
          ar.elb.rotation.x = lerpAng(ar.elb.rotation.x, -0.35, dt * 6);
          ar.elb.rotation.z = 0;
          return;
        }
        if (talk && !moving) {
          var gest = Math.sin(nowSec * 3.6 + i * 2.1);
          ar.sh.rotation.x = lerpAng(ar.sh.rotation.x, -0.48 + gest * 0.22, dt * 7);
          ar.sh.rotation.z = lerpAng(ar.sh.rotation.z, ar.s * (0.14 + Math.max(0, gest) * 0.12), dt * 7);
          ar.elb.rotation.x = lerpAng(ar.elb.rotation.x, -0.92 + Math.cos(nowSec * 4.2 + i) * 0.26, dt * 7);
          ar.elb.rotation.z = Math.sin(nowSec * 3.0 + i) * 0.1;
          ar.wrist.rotation.z = ar.s * Math.sin(nowSec * 4.5) * 0.2;
          return;
        }
        if (aiState === 'work' && !moving) {
          ar.sh.rotation.x = lerpAng(ar.sh.rotation.x, -0.55 + Math.sin(nowSec * 2.6 + i * 1.6) * 0.12, dt * 6);
          ar.sh.rotation.z = lerpAng(ar.sh.rotation.z, ar.s * 0.08, dt * 6);
          ar.elb.rotation.x = lerpAng(ar.elb.rotation.x, -0.82 + Math.sin(nowSec * 3.4 + i) * 0.15, dt * 6);
          ar.elb.rotation.z = 0;
          return;
        }
        var p = ph + (i ? 0 : Math.PI);
        var sw = moving ? -Math.sin(p) * 0.46 : Math.sin(nowSec * 1.4 + i * 2) * 0.025;
        ar.sh.rotation.x = lerpAng(ar.sh.rotation.x, sw, dt * 9);
        ar.sh.rotation.z = lerpAng(ar.sh.rotation.z, ar.s * 0.08, dt * 9);
        ar.elb.rotation.x = lerpAng(ar.elb.rotation.x, moving ? -0.28 - Math.max(0, -Math.sin(p)) * 0.35 : -0.14, dt * 9);
        ar.elb.rotation.z = 0;
        ar.wrist.rotation.z = 0;
      });
    }

    var lastClk = 0;
    g.userData.rig = rig;
    g.userData.hips = hips;
    g.userData.chest = chest;
    g.userData.head = head;
    g.userData.body = hips;
    g.userData.arms = arms.map(function (a) { return a.sh; });
    g.userData.legs = [];
    g.userData.eyes = eyes;
    g.userData.smile = smile;
    g.userData.mouth = mouth;
    g.userData.tagY = spec.toque ? targetH + 0.45 : targetH + 0.28;
    g.userData.wave = function (sec) { waveUntil = sec || 2.0; };
    g.userData.bow = function (sec) { bowUntil = sec || 1.6; };
    g.userData.isWaving = function () { return waveUntil > 0; };
    g.userData.sit = function (on, isDrive) {
      sitMode = !!on;
      driveMode = !!isDrive;
      applyKinematics(0, false, 0.05, { sit: on, drive: isDrive });
    };
    g.userData.update = function (ph, moving, dt, sitVal, extraOpts) {
      applyKinematics(ph, moving, dt, Object.assign({ sit: sitVal }, extraOpts || {}));
    };
    g.userData.walk = function (t, moving, clk, extraOpts) {
      var dt = lastClk ? Math.max(0.008, Math.min(0.05, (clk || 0) - lastClk)) : 0.016;
      if (clk) lastClk = clk;
      applyKinematics(t, moving, dt, Object.assign({ clk: clk, sit: sitMode }, extraOpts || {}));
    };
    g.userData.lookTowards = function (worldPt) {
      if (!worldPt) { pendingLookYaw = null; return; }
      var dx = worldPt.x - g.position.x, dz = worldPt.z - g.position.z;
      if (dx * dx + dz * dz < 0.05) { pendingLookYaw = 0; return; }
      var ang = Math.atan2(dx, dz) - g.rotation.y;
      while (ang > Math.PI) ang -= Math.PI * 2;
      while (ang < -Math.PI) ang += Math.PI * 2;
      pendingLookYaw = Math.max(-0.7, Math.min(0.7, ang));
    };

    return g;
  }

  window.GSHumanoid = {
    make: makeHumanoid,
    setupPBR: setupPBR,
    pbrMat: pbrMat,
    skinMat: skinMat,
    clothMat: clothMat,
    safeHex: safeHex,
    shade: shadeHex,
    tex: {
      aoShadow: aoShadowTex,
      fabricBump: fabricBump,
      waterNormal: waterNormal,
      wood: woodTex,
      marble: marbleTex,
      grass: grassTex,
      sand: sandTex
    }
  };
})();
