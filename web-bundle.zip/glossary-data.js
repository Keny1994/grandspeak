const HOSPITALITY_GLOSSARY=[
  {
    "id": "BAR_01",
    "category": "Barista & Beverage",
    "term": "Espresso shot",
    "type": "Noun phrase",
    "vi": "Một chiết xuất cà phê đậm đặc (tiêu chuẩn 25–30ml)",
    "ipa": "/eˈspres.oʊ ʃɑːt/",
    "phonetic_vi": "ẹt-S-PRÉT-sầu shót (Lưu ý: đọc âm /e/, không đọc là 'ích-xì-prét-xô')",
    "example_en": "Would you like a **single** or a **double** espresso shot?",
    "example_vi": "Quý khách muốn dùng 1 shot hay 2 shot espresso đậm vị ạ?",
    "tags": [
      "barista",
      "coffee",
      "order"
    ]
  },
  {
    "id": "BAR_02",
    "category": "Barista & Beverage",
    "term": "Microfoam",
    "type": "Noun",
    "vi": "Lớp bọt sữa siêu mịn, bóng mượt (dùng cho Latte Art / Cappuccino)",
    "ipa": "/ˈmaɪ.kroʊ.foʊm/",
    "phonetic_vi": "MAI-crâu-phôm",
    "example_en": "Our Cappuccino is topped with velvety **microfoam**.",
    "example_vi": "Món Cappuccino bên em có lớp bọt sữa đánh mịn mượt phía trên ạ.",
    "tags": [
      "barista",
      "milk",
      "technique"
    ]
  },
  {
    "id": "BAR_03",
    "category": "Barista & Beverage",
    "term": "Decaf (Decaffeinated)",
    "type": "Adjective / Noun",
    "vi": "Cà phê đã tách bỏ caffeine (dành cho khách sợ mất ngủ/tim đập nhanh)",
    "ipa": "/ˈdiː.kæf/",
    "phonetic_vi": "ĐI-cáp",
    "example_en": "Do you have **decaf** coffee available?",
    "example_vi": "Quán mình có phục vụ cà phê tách caffeine (decaf) không?",
    "tags": [
      "barista",
      "coffee",
      "custom"
    ]
  },
  {
    "id": "BAR_04",
    "category": "Barista & Beverage",
    "term": "Oat milk",
    "type": "Noun phrase",
    "vi": "Sữa yến mạch (loại sữa thực vật phổ biến nhất thay thế sữa bò)",
    "ipa": "/oʊt mɪlk/",
    "phonetic_vi": "ÂU-tờ miu",
    "example_en": "Can I swap regular milk for **oat milk**?",
    "example_vi": "Tôi có thể đổi sữa tươi thường sang sữa yến mạch được không?",
    "tags": [
      "barista",
      "milk",
      "vegan",
      "allergy"
    ]
  },
  {
    "id": "BAR_05",
    "category": "Barista & Beverage",
    "term": "Soy milk / Almond milk",
    "type": "Noun phrase",
    "vi": "Sữa đậu nành / Sữa hạnh nhân",
    "ipa": "/sɔɪ mɪlk/ - /ˈɑː.mənd mɪlk/",
    "phonetic_vi": "XOI miu / A-mần miu (Lưu ý: chữ 'l' trong almond là âm câm)",
    "example_en": "We offer both **soy milk** and **almond milk** for dairy-free guests.",
    "example_vi": "Bên em có cả sữa đậu nành và sữa hạnh nhân cho khách kiêng sữa động vật ạ.",
    "tags": [
      "barista",
      "milk",
      "vegan",
      "allergy"
    ]
  },
  {
    "id": "BAR_06",
    "category": "Barista & Beverage",
    "term": "Condensed milk",
    "type": "Noun phrase",
    "vi": "Sữa đặc có đường (nguyên liệu linh hồn của Cà phê Sữa đá / Bạc xỉu)",
    "ipa": "/kənˈdenst mɪlk/",
    "phonetic_vi": "cần-ĐEN-s-tờ miu",
    "example_en": "Vietnamese iced coffee is made with sweet **condensed milk**.",
    "example_vi": "Cà phê sữa đá Việt Nam được pha cùng sữa đặc ngọt dịu ạ.",
    "tags": [
      "barista",
      "milk",
      "vietnamese_coffee"
    ]
  },
  {
    "id": "BAR_07",
    "category": "Barista & Beverage",
    "term": "Skinny / Skim milk",
    "type": "Adjective / Noun",
    "vi": "Sữa tách béo / Đồ uống pha bằng sữa không béo",
    "ipa": "/ˈskɪn.i/ - /skɪm mɪlk/",
    "phonetic_vi": "S-KIN-ni / S-KIM miu",
    "example_en": "I'd like a **skinny** Latte with no sugar, please.",
    "example_vi": "Cho tôi một ly Latte sữa tách béo và không đường nhé.",
    "tags": [
      "barista",
      "milk",
      "diet"
    ]
  },
  {
    "id": "BAR_08",
    "category": "Barista & Beverage",
    "term": "Syrup / Drizzle",
    "type": "Noun",
    "vi": "Si-rô tạo hương vị / Lớp sốt rưới trang trí trên bề mặt (caramel, sô-cô-la)",
    "ipa": "/ˈsɪr.əp/ - /ˈdrɪz.əl/",
    "phonetic_vi": "XI-rập / ĐRÍT-dồ",
    "example_en": "Would you like caramel **drizzle** on top of your foam?",
    "example_vi": "Quý khách có muốn rưới thêm sốt caramel lên lớp bọt sữa không ạ?",
    "tags": [
      "barista",
      "sweetness",
      "topping"
    ]
  },
  {
    "id": "BAR_09",
    "category": "Barista & Beverage",
    "term": "Sugar-free / Unsweetened",
    "type": "Adjective",
    "vi": "Hoàn toàn không đường / Nguyên chất không ngọt",
    "ipa": "/ˈʃʊɡ.ər.friː/ - /ʌnˈswiː.tənd/",
    "phonetic_vi": "SHU-gờ-phri / ăn-S-WÍT-tần",
    "example_en": "Is this matcha base **unsweetened**?",
    "example_vi": "Cốt bột matcha này đã có đường sẵn chưa hay nguyên chất không ngọt?",
    "tags": [
      "barista",
      "sweetness",
      "diet"
    ]
  },
  {
    "id": "BAR_10",
    "category": "Barista & Beverage",
    "term": "Easy ice / Light ice",
    "type": "Noun phrase",
    "vi": "Ít đá (cách khách bản xứ thường gọi thay vì 'less ice')",
    "ipa": "/ˈiː.zi aɪs/ - /laɪt aɪs/",
    "phonetic_vi": "I-di ai / LAI-tờ ai",
    "example_en": "Can I get an iced Americano with **easy ice**?",
    "example_vi": "Cho tôi một ly Americano đá nhưng lấy ít đá thôi nhé.",
    "tags": [
      "barista",
      "ice",
      "custom"
    ]
  },
  {
    "id": "BAR_11",
    "category": "Barista & Beverage",
    "term": "Room temperature",
    "type": "Noun phrase",
    "vi": "Nhiệt độ phòng (không đá, không làm nóng)",
    "ipa": "/ruːm ˈtem.prə.tʃər/",
    "phonetic_vi": "rum TEM-prơ-chờ",
    "example_en": "Could I have a bottle of water at **room temperature**?",
    "example_vi": "Cho tôi một chai nước suối ở nhiệt độ thường (không ướp lạnh) nhé.",
    "tags": [
      "barista",
      "temperature",
      "custom"
    ]
  },
  {
    "id": "BAR_12",
    "category": "Barista & Beverage",
    "term": "Lukewarm / Kid's temp",
    "type": "Adjective / Noun",
    "vi": "Ấm vừa phải (khoảng 50-55°C, uống được ngay không sợ bỏng lưỡi)",
    "ipa": "/ˈluːk.wɔːrm/",
    "phonetic_vi": "LÚC-wom",
    "example_en": "Please steam the milk **lukewarm** so my daughter can drink it right away.",
    "example_vi": "Làm ơn đánh sữa ấm vừa thôi để con gái tôi uống được luôn nhé.",
    "tags": [
      "barista",
      "temperature",
      "custom"
    ]
  },
  {
    "id": "BAR_13",
    "category": "Barista & Beverage",
    "term": "Whipped cream",
    "type": "Noun phrase",
    "vi": "Kem tươi đánh bông (xịt trên đá xay, cacao, trà đào)",
    "ipa": "/wɪpt kriːm/",
    "phonetic_vi": "WÍP-tờ crim",
    "example_en": "Does this ice-blended drink come with **whipped cream**?",
    "example_vi": "Món đá xay này có xịt sẵn kem tươi ở trên không?",
    "tags": [
      "barista",
      "topping"
    ]
  },
  {
    "id": "BAR_14",
    "category": "Barista & Beverage",
    "term": "Boba / Tapioca pearls",
    "type": "Noun",
    "vi": "Trân châu (hạt trân châu làm từ bột năng)",
    "ipa": "/ˈboʊ.bə/ - /ˌtæp.iˈoʊ.kə pɜːrlz/",
    "phonetic_vi": "BÂU-bà / ta-pi-ÂU-cờ pơ-l-s",
    "example_en": "Would you like chewy **white boba** or **golden pearls**?",
    "example_vi": "Mình muốn thêm trân châu trắng giòn dai hay trân châu hoàng kim ạ?",
    "tags": [
      "barista",
      "topping",
      "tea"
    ]
  },
  {
    "id": "BAR_15",
    "category": "Barista & Beverage",
    "term": "Salted cream foam",
    "type": "Noun phrase",
    "vi": "Lớp kem muối mặn béo (dùng cho Cà phê muối / Trà kem phô mai)",
    "ipa": "/ˈsɔːl.tɪd kriːm foʊm/",
    "phonetic_vi": "XON-tịt crim phôm",
    "example_en": "Our Salt Coffee features a rich, savory **salted cream foam** on top.",
    "example_vi": "Món Cà phê Muối bên em có lớp kem muối béo mặn đặc trưng ở phía trên ạ.",
    "tags": [
      "barista",
      "topping",
      "signature"
    ]
  },
  {
    "id": "BAR_16",
    "category": "Barista & Beverage",
    "term": "Brewed tea / Steeped to order",
    "type": "Noun phrase",
    "vi": "Trà ủ nguyên lá / Trà pha mới theo từng ly khi khách gọi",
    "ipa": "/bruːd tiː/ - /stiːpt tuː ˈɔːr.dər/",
    "phonetic_vi": "BRU-đờ ti / S-TÍP-tờ tu O-đờ",
    "example_en": "Our Oolong tea is freshly **brewed**, so it has a deep floral aroma.",
    "example_vi": "Trà Ô long bên em được ủ mới nguyên lá nên giữ trọn hương thơm hoa cỏ tự nhiên ạ.",
    "tags": [
      "barista",
      "tea",
      "quality"
    ]
  },
  {
    "id": "BAR_17",
    "category": "Barista & Beverage",
    "term": "Acidity vs. Bitterness",
    "type": "Noun",
    "vi": "Độ chua thanh tự nhiên (hạt Arabica) và Độ đắng đậm (hạt Robusta)",
    "ipa": "/əˈsɪd.ə.t̬i/ - /ˈbɪt̬.ər.nəs/",
    "phonetic_vi": "ờ-XI-đờ-ti / BÍT-tờ-nợt-s",
    "example_en": "This blend has low **acidity** and a bold, chocolaty **bitterness**.",
    "example_vi": "Dòng cà phê phối trộn này ít chua và có vị đắng đậm hương sô-cô-la ạ.",
    "tags": [
      "barista",
      "coffee",
      "taste"
    ]
  },
  {
    "id": "BAR_18",
    "category": "Barista & Beverage",
    "term": "Cold brew",
    "type": "Noun phrase",
    "vi": "Cà phê ủ lạnh (chiết xuất bằng nước lạnh từ 12–24 tiếng, vị êm dịu)",
    "ipa": "/koʊld bruː/",
    "phonetic_vi": "CÂU-đờ bru",
    "example_en": "Our **Cold brew** is steeped for 16 hours for a super smooth finish.",
    "example_vi": "Cà phê ủ lạnh bên em được ngâm 16 tiếng nên hậu vị cực kỳ êm mượt ạ.",
    "tags": [
      "barista",
      "coffee"
    ]
  },
  {
    "id": "BAR_19",
    "category": "Barista & Beverage",
    "term": "Ice-blended / Frappe",
    "type": "Adjective / Noun",
    "vi": "Món đá xay nhuyễn",
    "ipa": "/aɪs ˈblen.dɪd/ - /fræp/",
    "phonetic_vi": "ai-s BLEN-địt / PHRÁP",
    "example_en": "Would you prefer your Matcha **iced** with cubes or **ice-blended**?",
    "example_vi": "Mình thích uống Matcha khuấy đá viên hay làm kiểu đá xay nhuyễn ạ?",
    "tags": [
      "barista",
      "ice",
      "order"
    ]
  },
  {
    "id": "BAR_20",
    "category": "Barista & Beverage",
    "term": "Cup sleeve / Carrier tray",
    "type": "Noun phrase",
    "vi": "Đai giấy chống nóng bọc quanh ly / Khay giấy đựng nhiều ly mang đi",
    "ipa": "/kʌp sliːv/ - /ˈkær.i.ər treɪ/",
    "phonetic_vi": "CẮP s-líp / KE-ri-ờ trây",
    "example_en": "Let me put a **cup sleeve** on that hot Americano and a **carrier tray** for your takeaway.",
    "example_vi": "Để em lồng thêm đai chống nóng vào ly Americano và đặt vào khay mang đi giúp mình nhé.",
    "tags": [
      "barista",
      "takeaway",
      "packaging"
    ]
  },
  {
    "id": "POS_01",
    "category": "Cashier & POS",
    "term": "For here or to go? (Dine-in or Takeaway?)",
    "type": "Phrase",
    "vi": "Dùng tại quán hay mang đi?",
    "ipa": "/fɔːr hɪər ɔːr tuː ɡoʊ?/",
    "phonetic_vi": "pho HIA o tu GÂU?",
    "example_en": "Will that be **for here** in a ceramic mug or **to go** in a paper cup?",
    "example_vi": "Mình dùng tại quán trong cốc sứ hay đựng ly giấy mang đi ạ?",
    "tags": [
      "pos",
      "order",
      "greeting"
    ]
  },
  {
    "id": "POS_02",
    "category": "Cashier & POS",
    "term": "Contactless payment / Tap to pay",
    "type": "Noun phrase",
    "vi": "Thanh toán chạm không tiếp xúc (thẻ chip PayWave, Apple Pay, Samsung Pay)",
    "ipa": "/ˈkɑːn.tækt.ləs ˈpeɪ.mənt/",
    "phonetic_vi": "CON-tác-lợt-s PÂY-mần",
    "example_en": "Our POS terminal accepts **contactless payment** and Apple Pay.",
    "example_vi": "Máy POS bên em có nhận thanh toán chạm thẻ không tiếp xúc và Apple Pay ạ.",
    "tags": [
      "pos",
      "payment"
    ]
  },
  {
    "id": "POS_03",
    "category": "Cashier & POS",
    "term": "QR Code transfer",
    "type": "Noun phrase",
    "vi": "Chuyển khoản quét mã QR (VietQR / Ví điện tử)",
    "ipa": "/ˌkjuːˈɑːr koʊd ˈtræns.fɜːr/",
    "phonetic_vi": "kiu-A cất TRAN-s-phơ",
    "example_en": "You can scan this **QR code** at the counter if you have a Vietnamese banking app.",
    "example_vi": "Quý khách có thể quét mã QR ngay tại quầy nếu có ứng dụng ngân hàng Việt Nam ạ.",
    "tags": [
      "pos",
      "payment"
    ]
  },
  {
    "id": "POS_04",
    "category": "Cashier & POS",
    "term": "Split the bill / Separate checks",
    "type": "Verb phrase / Noun",
    "vi": "Tách hóa đơn thanh toán riêng từng người",
    "ipa": "/splɪt ðə bɪl/ - /ˈsep.rət tʃeks/",
    "phonetic_vi": "S-PLÍT đờ biu / XÉP-prợt chếc-s",
    "example_en": "No problem at all, I can easily **split the bill** for the three of you.",
    "example_vi": "Dạ hoàn toàn được ạ, em có thể tách hóa đơn riêng cho cả 3 mình nhé.",
    "tags": [
      "pos",
      "payment",
      "billing"
    ]
  },
  {
    "id": "POS_05",
    "category": "Cashier & POS",
    "term": "Exact change / Small bills",
    "type": "Noun phrase",
    "vi": "Tiền lẻ vừa đủ (không cần thối lại) / Tiền mệnh giá nhỏ",
    "ipa": "/ɪɡˈzækt tʃeɪndʒ/ - /smɔːl bɪlz/",
    "phonetic_vi": "ịch-ZÁC chên-chờ / s-mon BIU-s",
    "example_en": "Do you happen to have **small bills** or **exact change**? I'm running low on change.",
    "example_vi": "Quý khách có tình cờ mang tiền mệnh giá nhỏ hay tiền lẻ vừa đủ không ạ? Quầy em đang hơi thiếu tiền lẻ.",
    "tags": [
      "pos",
      "cash",
      "payment"
    ]
  },
  {
    "id": "POS_06",
    "category": "Cashier & POS",
    "term": "Receipt vs. VAT Invoice",
    "type": "Noun",
    "vi": "Hóa đơn bán hàng in nhiệt tại quầy vs. Hóa đơn đỏ giá trị gia tăng (VAT)",
    "ipa": "/rɪˈsiːt/ - /ˌviː.eɪˈtiː ˈɪn.vɔɪs/",
    "phonetic_vi": "rì-XÍT (âm p câm) / vi-ây-ti IN-voi-s",
    "example_en": "Here is your **receipt**. Please fill out this QR form if your company needs a **VAT invoice**.",
    "example_vi": "Đây là hóa đơn thanh toán ạ. Quý khách vui lòng quét mã điền thông tin nếu công ty cần xuất hóa đơn VAT nhé.",
    "tags": [
      "pos",
      "billing"
    ]
  },
  {
    "id": "POS_07",
    "category": "Cashier & POS",
    "term": "Buzzer / Coaster pager",
    "type": "Noun",
    "vi": "Thẻ báo rung tự phục vụ",
    "ipa": "/ˈbʌz.ər/ - /ˈkoʊ.stər ˈpeɪ.dʒər/",
    "phonetic_vi": "BẮT-dờ / CÂU-s-tờ PÂY-chờ",
    "example_en": "Please hold onto this **buzzer**; it will light up when your drink is ready.",
    "example_vi": "Quý khách vui lòng cầm thẻ báo rung này nhé; thẻ sẽ sáng đèn khi đồ uống hoàn tất ạ.",
    "tags": [
      "pos",
      "pickup"
    ]
  },
  {
    "id": "POS_08",
    "category": "Cashier & POS",
    "term": "Combo deal / Set menu",
    "type": "Noun phrase",
    "vi": "Gói ưu đãi kết hợp (Nước + Bánh) giá tiết kiệm hơn mua lẻ",
    "ipa": "/ˈkɑːm.boʊ diːl/",
    "phonetic_vi": "COM-bâu điu",
    "example_en": "If you get the **combo deal** with a pastry, you save twenty thousand Dong.",
    "example_vi": "Nếu mình chọn theo gói Combo kèm bánh ngọt sẽ tiết kiệm được 20 nghìn đồng ạ.",
    "tags": [
      "pos",
      "upsell",
      "promo"
    ]
  },
  {
    "id": "POS_09",
    "category": "Cashier & POS",
    "term": "Add-on / Extra topping",
    "type": "Noun",
    "vi": "Phần gọi thêm có tính phí (thêm trân châu, thêm kem phô mai, thêm shot)",
    "ipa": "/ˈæd.ɑːn/ - /ˈek.strə ˈtɑː.pɪŋ/",
    "phonetic_vi": "ÁT-on / ÉC-s-trờ TÓP-pình",
    "example_en": "Each **extra topping** is an additional ten thousand Dong.",
    "example_vi": "Mỗi phần topping gọi thêm có giá là 10 nghìn đồng ạ.",
    "tags": [
      "pos",
      "upsell",
      "custom"
    ]
  },
  {
    "id": "POS_10",
    "category": "Cashier & POS",
    "term": "Complimentary / On the house",
    "type": "Adjective / Idiom",
    "vi": "Miễn phí / Quán mời tặng khách (dùng khi đền bù sự cố hoặc tri ân khách VIP)",
    "ipa": "/ˌkɑːm.pləˈmen.tər.i/ - /ɑːn ðə haʊs/",
    "phonetic_vi": "com-plờ-MEN-tờ-ri / on đờ HAO-s",
    "example_en": "This pastry is **on the house** to apologize for the wait.",
    "example_vi": "Phần bánh ngọt này quán xin gửi tặng miễn phí để tạ lỗi vì đã để mình đợi lâu ạ.",
    "tags": [
      "pos",
      "recovery",
      "promo"
    ]
  },
  {
    "id": "POS_11",
    "category": "Cashier & POS",
    "term": "Void an item / Refund",
    "type": "Verb phrase / Noun",
    "vi": "Hủy một món đã bấm trên máy POS / Hoàn lại tiền cho khách",
    "ipa": "/vɔɪd ən ˈaɪ.t̬əm/ - /ˈriː.fʌnd/",
    "phonetic_vi": "VOI-đờ ần AI-tầm / RI-phăn",
    "example_en": "Let me **void** that item and give you a full **refund** in cash right away.",
    "example_vi": "Để em hủy món đó trên máy và hoàn lại đủ tiền mặt cho quý khách ngay bây giờ ạ.",
    "tags": [
      "pos",
      "recovery",
      "billing"
    ]
  },
  {
    "id": "POS_12",
    "category": "Cashier & POS",
    "term": "Card declined / Transaction failed",
    "type": "Noun phrase",
    "vi": "Thẻ bị từ chối thanh toán / Giao dịch không thành công",
    "ipa": "/kɑːrd dɪˈklaɪnd/ - /trænˈzæk.ʃən feɪld/",
    "phonetic_vi": "cạt đì-CLAI-n-đờ / tràn-ZÁC-shần phê-ồ-đờ",
    "example_en": "I'm sorry, it says the **transaction failed**. Would you like to try another card?",
    "example_vi": "Em xin lỗi, máy báo giao dịch chưa thành công. Quý khách có muốn thử lại bằng một thẻ khác không ạ?",
    "tags": [
      "pos",
      "payment",
      "error"
    ]
  },
  {
    "id": "POS_13",
    "category": "Cashier & POS",
    "term": "Service charge",
    "type": "Noun phrase",
    "vi": "Phí phục vụ (thường từ 5% trong các nhà hàng/lounge)",
    "ipa": "/ˈsɜːr.vɪs tʃɑːrdʒ/",
    "phonetic_vi": "XƠ-vịt-s cha-chờ",
    "example_en": "Please note that our menu prices already include VAT and **service charge**.",
    "example_vi": "Giá trên thực đơn bên em đã bao gồm thuế VAT và phí phục vụ rồi ạ.",
    "tags": [
      "pos",
      "billing"
    ]
  },
  {
    "id": "POS_14",
    "category": "Cashier & POS",
    "term": "Loyalty card / Membership points",
    "type": "Noun phrase",
    "vi": "Thẻ khách hàng thân thiết / Điểm tích lũy thành viên",
    "ipa": "/ˈlɔɪ.əl.ti kɑːrd/ - /ˈmem.bər.ʃɪp pɔɪnts/",
    "phonetic_vi": "LOI-ồ-ti cạt / MEM-bờ-shíp poi-s",
    "example_en": "May I have your phone number to collect **membership points**?",
    "example_vi": "Cho em xin số điện thoại để tích điểm thành viên cho mình nhé ạ?",
    "tags": [
      "pos",
      "loyalty"
    ]
  },
  {
    "id": "POS_15",
    "category": "Cashier & POS",
    "term": "Voucher / Promo code",
    "type": "Noun",
    "vi": "Phiếu giảm giá / Mã khuyến mãi",
    "ipa": "/ˈvaʊ.tʃər/ - /ˈproʊ.moʊ koʊd/",
    "phonetic_vi": "VAO-chờ / PRÂU-mâu cất",
    "example_en": "Please show me your **voucher** before I print the final bill.",
    "example_vi": "Quý khách vui lòng đưa mã voucher cho em quét trước khi em chốt in hóa đơn nhé.",
    "tags": [
      "pos",
      "promo"
    ]
  },
  {
    "id": "POS_16",
    "category": "Cashier & POS",
    "term": "Out of stock / Eighty-sixed (86'd)",
    "type": "Adjective / Slang",
    "vi": "Hết hàng / Tạm ngưng phục vụ món đó trong ca (thuật ngữ nội bộ F&B: 86)",
    "ipa": "/aʊt əv stɑːk/ - /ˌeɪ.t̬iˈsɪkst/",
    "phonetic_vi": "AO ợp s-tóc / ây-ti-XÍCH-s-tờ",
    "example_en": "I'm so sorry, our Matcha Croissant is currently **out of stock**.",
    "example_vi": "Em rất tiếc, bánh sừng bò Matcha hiện tại đang tạm hết hàng mất rồi ạ.",
    "tags": [
      "pos",
      "sold_out"
    ]
  },
  {
    "id": "POS_17",
    "category": "Cashier & POS",
    "term": "Pick-up counter",
    "type": "Noun phrase",
    "vi": "Quầy trả món / Khu vực nhận đồ uống",
    "ipa": "/ˈpɪk.ʌp ˈkaʊn.t̬ər/",
    "phonetic_vi": "PÍCH-cắp CAO-tờ",
    "example_en": "You can collect your drinks at the **pick-up counter** on the left.",
    "example_vi": "Quý khách có thể nhận đồ uống tại quầy trả món phía bên tay trái nhé ạ.",
    "tags": [
      "pos",
      "pickup"
    ]
  },
  {
    "id": "POS_18",
    "category": "Cashier & POS",
    "term": "Denominations",
    "type": "Noun",
    "vi": "Các mệnh giá tiền (rất quan trọng khi hướng dẫn khách nước ngoài phân biệt tờ 20.000đ và 500.000đ)",
    "ipa": "/dɪˌnɑː.məˈneɪ.ʃənz/",
    "phonetic_vi": "đì-no-mờ-NÂY-shần-s",
    "example_en": "Be careful—the 20k and 500k blue notes look similar in **denomination**!",
    "example_vi": "Quý khách lưu ý nhé—tờ 20 nghìn và 500 nghìn màu xanh dương nhìn khá giống nhau đấy ạ!",
    "tags": [
      "pos",
      "cash"
    ]
  },
  {
    "id": "POS_19",
    "category": "Cashier & POS",
    "term": "Queue / Line up",
    "type": "Noun / Verb",
    "vi": "Hàng chờ / Xếp hàng theo thứ tự",
    "ipa": "/kjuː/ - /laɪn ʌp/",
    "phonetic_vi": "KIU / LAI-n‿ắp",
    "example_en": "Could you please **line up** here? I'll be right with you next.",
    "example_vi": "Quý khách vui lòng xếp hàng tại lối này giúp em nhé, em sẽ phục vụ mình ngay tiếp theo đây ạ.",
    "tags": [
      "pos",
      "queue"
    ]
  },
  {
    "id": "POS_20",
    "category": "Cashier & POS",
    "term": "Shift handover / Cash drawer",
    "type": "Noun phrase",
    "vi": "Bàn giao ca / Ngăn kéo đựng tiền tại quầy thu ngân",
    "ipa": "/ʃɪft ˈhændˌoʊ.vər/ - /kæʃ drɔːr/",
    "phonetic_vi": "SHÍP HAN-âu-vờ / KÉT-sh đro",
    "example_en": "Please give me 30 seconds to finish our **shift handover** at the register.",
    "example_vi": "Xin quý khách đợi em 30 giây để hoàn tất bước giao ca trên máy thu ngân nhé.",
    "tags": [
      "pos",
      "ops"
    ]
  },
  {
    "id": "SRV_01",
    "category": "Server & Floor Ops",
    "term": "Party of [number]",
    "type": "Noun phrase",
    "vi": "Đoàn khách gồm [số lượng] người",
    "ipa": "/ˈpɑːr.t̬i əv .../",
    "phonetic_vi": "PA-tì ợp ...",
    "example_en": "Good evening! Are you a **party of four**?",
    "example_vi": "Chào buổi tối! Đoàn mình đi 4 người phải không ạ?",
    "tags": [
      "server",
      "seating"
    ]
  },
  {
    "id": "SRV_02",
    "category": "Server & Floor Ops",
    "term": "Booth vs. High-top table",
    "type": "Noun",
    "vi": "Bàn ghế sofa nệm dựa lưng (Booth) vs. Bàn bar ghế cao (High-top)",
    "ipa": "/buːð/ - /ˈhaɪ.tɑːp ˈteɪ.bəl/",
    "phonetic_vi": "BU-đờ / HAI-tóp TÂY-bồ",
    "example_en": "Would you prefer a cozy **booth** or a **high-top table** near the window?",
    "example_vi": "Quý khách thích ngồi bàn ghế nệm sofa êm ái hay bàn ghế cao cạnh cửa sổ ạ?",
    "tags": [
      "server",
      "seating"
    ]
  },
  {
    "id": "SRV_03",
    "category": "Server & Floor Ops",
    "term": "Patio / Outdoor seating",
    "type": "Noun",
    "vi": "Khu vực bàn ngoài hiên / Không gian ngoài trời",
    "ipa": "/ˈpæt̬.i.oʊ/ - /ˈaʊt.dɔːr ˈsiː.t̬ɪŋ/",
    "phonetic_vi": "PA-ti-âu / AO-đo XI-tình",
    "example_en": "Smoking is only permitted in our **outdoor patio** area.",
    "example_vi": "Quán chỉ cho phép hút thuốc ở khu vực bàn hiên ngoài trời thôi ạ.",
    "tags": [
      "server",
      "seating",
      "rules"
    ]
  },
  {
    "id": "SRV_04",
    "category": "Server & Floor Ops",
    "term": "Cutlery / Silverware / Utensils",
    "type": "Noun",
    "vi": "Bộ dụng cụ ăn uống (dao, muỗng, nĩa, đũa)",
    "ipa": "/ˈkʌt.lər.i/ - /juːˈten.səlz/",
    "phonetic_vi": "CẮT-lơ-ri / diu-TEN-xồ-s",
    "example_en": "I'll bring you some fresh **cutlery** and napkins right away.",
    "example_vi": "Em sẽ mang bộ dao nĩa mới và khăn giấy ra cho quý khách ngay ạ.",
    "tags": [
      "server",
      "tableware"
    ]
  },
  {
    "id": "SRV_05",
    "category": "Server & Floor Ops",
    "term": "Napkin / Serviette / Wet tissue",
    "type": "Noun",
    "vi": "Khăn giấy khô (Mỹ: Napkin, Anh/Úc: Serviette) / Khăn ướt",
    "ipa": "/ˈnæp.kɪn/ - /ˈwet ˌtɪʃ.uː/",
    "phonetic_vi": "NÁP-kin / WÉT TÍT-shiu",
    "example_en": "Can I get you some extra **napkins** or a chilled **wet tissue**?",
    "example_vi": "Em lấy thêm cho mình ít khăn giấy khô hay khăn lạnh nhé ạ?",
    "tags": [
      "server",
      "tableware"
    ]
  },
  {
    "id": "SRV_06",
    "category": "Server & Floor Ops",
    "term": "Condiments / Dipping sauce",
    "type": "Noun",
    "vi": "Gia vị để bàn (muối, tiêu, tương ớt) / Nước chấm đi kèm món ăn",
    "ipa": "/ˈkɑːn.də.mənts/ - /ˈdɪp.ɪŋ sɔːs/",
    "phonetic_vi": "CON-đờ-mần-s / ĐÍP-pình xo-s",
    "example_en": "Would you like chili sauce or any other **condiments**?",
    "example_vi": "Quý khách có cần thêm tương ớt hay gia vị chấm nào khác không ạ?",
    "tags": [
      "server",
      "food"
    ]
  },
  {
    "id": "SRV_07",
    "category": "Server & Floor Ops",
    "term": "Signature dish / House special",
    "type": "Noun phrase",
    "vi": "Món đặc trưng làm nên tên tuổi của quán / Món đặc biệt của nhà hàng",
    "ipa": "/ˈsɪɡ.nə.tʃər dɪʃ/ - /haʊs ˈspeʃ.əl/",
    "phonetic_vi": "XÍCH-nơ-chờ đít-sh / HAO-s S-PÉT-shồ",
    "example_en": "Lotus Seed Tea is our **house special**—you definitely shouldn't miss it!",
    "example_vi": "Trà Hạt Sen là món đặc sản của quán em—quý khách nhất định nên thử ạ!",
    "tags": [
      "server",
      "upsell"
    ]
  },
  {
    "id": "SRV_08",
    "category": "Server & Floor Ops",
    "term": "Side dish / Appetizer (Starter)",
    "type": "Noun",
    "vi": "Món ăn kèm / Món khai vị",
    "ipa": "/saɪd dɪʃ/ - /ˈæp.ə.taɪ.zər/",
    "phonetic_vi": "XAI đít-sh / ÁP-pờ-tai-dờ",
    "example_en": "Would you like to order some **appetizers** to share while waiting for the main course?",
    "example_vi": "Quý khách có muốn gọi vài món khai vị dùng chung trong lúc đợi món chính không ạ?",
    "tags": [
      "server",
      "order",
      "upsell"
    ]
  },
  {
    "id": "SRV_09",
    "category": "Server & Floor Ops",
    "term": "On the side",
    "type": "Prepositional phrase",
    "vi": "Để riêng ra chén nhỏ (dành cho nước sốt, sữa, đường, đá để khách tự gia giảm)",
    "ipa": "/ɑːn ðə saɪd/",
    "phonetic_vi": "on đờ XAI",
    "example_en": "I'll bring your dressing and sugar syrup **on the side**.",
    "example_vi": "Em sẽ để riêng phần nước sốt salad và nước đường ra ngoài cho mình tự pha nhé ạ.",
    "tags": [
      "server",
      "custom"
    ]
  },
  {
    "id": "SRV_10",
    "category": "Server & Floor Ops",
    "term": "Dietary restriction / Intolerance",
    "type": "Noun phrase",
    "vi": "Chế độ ăn kiêng bắt buộc / Chứng bất dung nạp thực phẩm (như bất dung nạp đường sữa lactose)",
    "ipa": "/ˈdaɪ.ə.ter.i rɪˈstrɪk.ʃən/ - /ɪnˈtɑː.lər.əns/",
    "phonetic_vi": "ĐAI-ờ-te-ri rì-S-TRÍCH-shần / in-TO-lơ-rần-s",
    "example_en": "If you have **lactose intolerance**, our fruit teas and oat milk lattes are completely safe.",
    "example_vi": "Nếu quý khách bị bất dung nạp lactose trong sữa bò, các dòng trà trái cây và latte sữa yến mạch bên em hoàn toàn an toàn ạ.",
    "tags": [
      "server",
      "allergy"
    ]
  },
  {
    "id": "SRV_11",
    "category": "Server & Floor Ops",
    "term": "Gluten-free / Nut allergy",
    "type": "Adjective / Noun",
    "vi": "Không chứa gluten (lúa mì) / Dị ứng các loại hạt (đậu phộng, hạnh nhân, hạt điều)",
    "ipa": "/ˈɡluː.tən.friː/ - /nʌt ˈæl.ɚ.dʒi/",
    "phonetic_vi": "GLU-tần-phri / NẮT A-lờ-chi",
    "example_en": "Please be careful, this cake is not suitable for guests with a **nut allergy**.",
    "example_vi": "Quý khách lưu ý giúp em, loại bánh này có chứa hạt nên không phù hợp nếu mình bị dị ứng các loại hạt ạ.",
    "tags": [
      "server",
      "allergy"
    ]
  },
  {
    "id": "SRV_12",
    "category": "Server & Floor Ops",
    "term": "Cilantro (Coriander)",
    "type": "Noun",
    "vi": "Rau mùi / Ngò rí (loại rau rất nhiều khách phương Tây không ăn được vì thấy mùi giống xà phòng)",
    "ipa": "/sɪˈlæn.troʊ/ - /ˌkɔːr.iˈæn.dər/",
    "phonetic_vi": "xi-LAN-trâu (Mỹ) / co-ri-AN-đờ (Anh/Úc)",
    "example_en": "Does this soup have **cilantro**? Could you ask the kitchen for no cilantro, please?",
    "example_vi": "Món súp này có bỏ rau mùi (ngò) không? Bạn dặn bếp đừng bỏ rau mùi giúp tôi nhé.",
    "tags": [
      "server",
      "allergy",
      "custom"
    ]
  },
  {
    "id": "SRV_13",
    "category": "Server & Floor Ops",
    "term": "Refill / Top up",
    "type": "Noun / Verb phrase",
    "vi": "Châm thêm nước (trà đá, nước lọc miễn phí)",
    "ipa": "/ˈriː.fɪl/ - /tɑːp ʌp/",
    "phonetic_vi": "RI-phiu / TÓP‿pắp",
    "example_en": "May I **top up** your iced tea or water for you?",
    "example_vi": "Em xin phép châm thêm trà đá hoặc nước lọc cho mình nhé ạ?",
    "tags": [
      "server",
      "service"
    ]
  },
  {
    "id": "SRV_14",
    "category": "Server & Floor Ops",
    "term": "Clear the plates / Bus the table",
    "type": "Verb phrase",
    "vi": "Thu dọn đĩa/ly rỗng trên bàn khách đang ngồi / Dọn sạch bàn sau khi khách về",
    "ipa": "/klɪər ðə pleɪts/ - /bʌs ðə ˈteɪ.bəl/",
    "phonetic_vi": "CLIA đờ plây-s / BỚT-s đờ TÂY-bồ",
    "example_en": "Excuse me, may I **clear these empty plates** and cups out of your way?",
    "example_vi": "Xin phép quý khách, em có thể thu dọn những chiếc đĩa và ly đã dùng xong này cho bàn mình gọn gàng nhé ạ?",
    "tags": [
      "server",
      "service"
    ]
  },
  {
    "id": "SRV_15",
    "category": "Server & Floor Ops",
    "term": "To-go box / Doggy bag",
    "type": "Noun phrase",
    "vi": "Hộp đóng gói thức ăn thừa mang về",
    "ipa": "/təˈɡoʊ bɑːks/",
    "phonetic_vi": "tờ-GÂU bóc-s",
    "example_en": "Would you like me to pack the rest of your pastry in a **to-go box**?",
    "example_vi": "Quý khách có muốn em đóng gói phần bánh còn lại vào hộp để mình mang về không ạ?",
    "tags": [
      "server",
      "takeaway"
    ]
  },
  {
    "id": "SRV_16",
    "category": "Server & Floor Ops",
    "term": "High chair / Booster seat",
    "type": "Noun phrase",
    "vi": "Ghế ăn dặm cao cho em bé / Đệm nâng ghế cho trẻ nhỏ",
    "ipa": "/ˈhaɪ ˌtʃeər/ - /ˈbuː.stər siːt/",
    "phonetic_vi": "HAI che / BU-s-tờ xít",
    "example_en": "Let me grab a **high chair** for your little one right away.",
    "example_vi": "Để em lấy ngay một chiếc ghế trẻ em cho bé nhà mình ngồi nhé ạ.",
    "tags": [
      "server",
      "seating",
      "family"
    ]
  },
  {
    "id": "SRV_17",
    "category": "Server & Floor Ops",
    "term": "Power outlet / Socket",
    "type": "Noun phrase",
    "vi": "Ổ cắm điện (khách làm việc bằng laptop tại quán cafe hỏi rất nhiều)",
    "ipa": "/ˈpaʊ.ər ˈaʊt.let/ - /ˈsɑː.kɪt/",
    "phonetic_vi": "PAO-ờ AO-lẹt / XÓC-kịt",
    "example_en": "The tables along the wall all have **power outlets** under the seat.",
    "example_vi": "Các dãy bàn dọc sát tường đều có ổ cắm điện ngay dưới gầm ghế đấy ạ.",
    "tags": [
      "server",
      "seating",
      "wifi_wc"
    ]
  },
  {
    "id": "SRV_18",
    "category": "Server & Floor Ops",
    "term": "Drafty / Air-con breeze",
    "type": "Adjective / Noun",
    "vi": "Bị gió lùa / Luồng gió điều hòa thổi trực tiếp vào người",
    "ipa": "/ˈdræf.ti/ - /ˈeər.kɑːn briːz/",
    "phonetic_vi": "ĐRÁP-ti / E-con briz",
    "example_en": "Let me move you to another table if this spot feels too **drafty** from the air-con.",
    "example_vi": "Để em chuyển mình sang bàn khác nếu chỗ này bị gió điều hòa thổi trực tiếp vào người nhé ạ.",
    "tags": [
      "server",
      "seating",
      "recovery"
    ]
  },
  {
    "id": "SRV_19",
    "category": "Server & Floor Ops",
    "term": "Table check (Touch the table)",
    "type": "Noun phrase",
    "vi": "Bước hỏi thăm chất lượng món ăn sau khi khách dùng được 2–3 phút",
    "ipa": "/ˈteɪ.bəl tʃek/",
    "phonetic_vi": "TÂY-bồ chếc",
    "example_en": "How is everything tasting so far? Can I get you anything else?",
    "example_vi": "Món ăn và đồ uống có hợp khẩu vị của quý khách không ạ? Em có thể hỗ trợ thêm gì cho mình không?",
    "tags": [
      "server",
      "service"
    ]
  },
  {
    "id": "SRV_20",
    "category": "Server & Floor Ops",
    "term": "Lost and found",
    "type": "Noun phrase",
    "vi": "Bộ phận / Khu vực giữ đồ khách để quên tại quán",
    "ipa": "/lɔːst ænd faʊnd/",
    "phonetic_vi": "LÓT-s-tờ èn PHAO-n-đờ",
    "example_en": "Did you leave an umbrella yesterday? Let me check our **lost and found** box at the counter.",
    "example_vi": "Hôm qua mình có để quên chiếc ô phải không ạ? Để em kiểm tra hộp giữ đồ thất lạc tại quầy thu ngân nhé.",
    "tags": [
      "server",
      "recovery",
      "ops"
    ]
  }
];
