/* ============================================================================
 * GRANDSPEAK 5★ — DỮ LIỆU TÌNH HUỐNG 3D KHÁCH SẠN & KHU NGHỈ DƯỠNG (PLACES DATA)
 * Gồm:
 *  1. 12 Khu vực 3D Khách sạn – Nhà hàng – Bar – Bếp – Suite – Spa – Du thuyền – Đại tiệc
 *  2. Đầy đủ 3 Cấp độ (Cấp 1 Sơ cấp A1–A2 · Cấp 2 Trung cấp B1 · Cấp 3 Nâng cao B2–C1)
 *  3. Hỗ trợ Tiếng Anh Chuẩn 5 Sao (en) + 5 Ngoại ngữ đón khách Quốc tế (zh, ja, ko, fr, ru)
 *  4. Dữ liệu Khám phá Đồ vật 3D (PLACE_VOC + PLACE_EXPLORE cho cả 12 khu vực)
 *  5. Dữ liệu Cách nói khác & Cấu trúc 5 Sao (PLACE_MORE) + Lời chào tạm biệt (FAREWELL)
 * ============================================================================ */
(function () {
  'use strict';

  function sc(vi, en, turns) {
    return [vi, en, turns];
  }

  /* ── 1. TỪ VỰNG ĐỒ VẬT KHÁM PHÁ 3D (PLACE_VOC) ──
     Định dạng: [icon, nghĩa Việt, 'en|/ipa/', 'zh|pinyin', 'ja|romaji', 'ko|romaja', 'fr|/ipa/', 'ru|translit'] */
  window.PLACE_VOC = {
    reception: ['🛎️', 'quầy lễ tân chính', 'reception desk|/rɪˈsep.ʃən desk/', '前台|qiántái', 'フロント|furonto', '프런트 데스크|peureonteu deseukeu', 'la réception|/ʁe.sɛp.sjɔ̃/', 'стойка ресепшен|stoyka resepshen'],
    bell: ['🔔', 'chuông gọi lễ tân', 'service bell|/ˈsɜːr.vɪs bel/', '服务铃|fúwùlíng', '呼び鈴|yobirin', '호출 벨|hochul bel', 'la sonnette|/sɔ.nɛt/', 'звонок|zvonok'],
    keyrack: ['🗝️', 'tủ thẻ phòng & chìa khoá', 'keycard rack|/ˈkiː.kɑːrd ræk/', '房卡架|fángkǎjià', 'ルームキー棚|rūmukī-dana', '객실 키 보관함|gaeksil ki bogwanham', 'le râtelier à clés|/ʁɑ.tə.lje/', 'ключница|klyuchnitsa'],
    chandelier: ['✨', 'đèn chùm pha lê sảnh', 'crystal chandelier|/ˈkrɪs.təl ˌʃæn.dəˈlɪr/', '水晶吊灯|shuǐjīng diàodēng', 'シャンデリア|shanderia', '샹들리에|syangdeullie', 'le lustre|/lystʁ/', 'хрустальная люстра|khrustal’naya lyustra'],
    sofa: ['🛋️', 'ghế sofa sảnh chờ VIP', 'lounge sofa|/laʊndʒ ˈsoʊ.fə/', '休息区沙发|xiūxīqū shāfā', 'ロビーソファ|robī sofa', '라운지 소파|raunji sopa', 'le canapé|/ka.na.pe/', 'диван в лобби|divan v lobbi'],
    luggagecart: ['🧳', 'xe đẩy hành lý mạ vàng', 'luggage trolley|/ˈlʌɡ.ɪdʒ ˈtrɑː.li/', '行李车|xínglǐchē', 'ラゲッジカート|ragejji kāto', '수하물 카트|suhamul kateu', 'le chariot à bagages|/ʃa.ʁjo/', 'багажная тележка|bagazhnaya telezhka'],
    conciergedesk: ['⚜️', 'bàn Chìa Khoá Vàng Concierge', 'concierge desk|/kɒnˈsjerʒ desk/', '礼宾台|lǐbīntái', 'コンシェルジュデスク|konsheruju desuku', '컨시어지 데스크|keonsieoji deseukeu', 'la conciergerie|/kɔ̃.sjɛʁ.ʒə.ʁi/', 'стойка консьержа|stoyka kons’yerzha'],
    globe: ['🌍', 'quả địa cầu du lịch', 'world globe|/wɜːrld ɡloʊb/', '地球仪|dìqiúyí', '地球儀|chikyūgi', '지구본|jigubon', 'le globe|/ɡlɔb/', 'глобус|globus'],
    limo: ['🚘', 'xe Limousine đưa đón VIP', 'hotel limousine|/hoʊˈtel ˈlɪm.ə.ziːn/', '酒店礼宾车|jiǔdiàn lǐbīnchē', 'ホテルリムジン|hoteru rimujin', '호텔 리무진|hotel rimujin', 'la limousine|/li.mu.zin/', 'лимузин отеля|limuzin otelya'],
    shuttle: ['🚐', 'xe điện đưa đón nội khu', 'resort shuttle|/rɪˈzɔːrt ˈʃʌt.əl/', '度假村班车|dùjiàcūn bānchē', 'リゾートシャトル|rizōto shatoru', '리조트 셔틀버스|rijoteu syeoteulbeoseu', 'la navette|/na.vɛt/', 'шаттл курорта|shattl kurorta'],
    valetstand: ['🅿️', 'bục đón xe Valet Parking', 'valet podium|/ˈvæl.eɪ ˈpoʊ.di.əm/', '代客泊车台|dàikè bóchētái', 'バレー受付|barē uketsuke', '발레파킹 부스|ballepaking buseu', 'le kiosque voiturier|/vwɑ.ty.ʁje/', 'стойка парковщика|stoyka parkovshchika'],
    hoststand: ['📖', 'bục đón khách nhà hàng', 'hostess stand|/ˈhoʊ.stəs stænd/', '迎宾台|yíngbīntái', '案内デスク|annai desuku', '호스트 스탠드|hoseuteu seutaendeu', 'le pupitre d’accueil|/py.pitʁ/', 'стойка хостес|stoyka khostes'],
    diningtable: ['🍽️', 'bàn tiệc Fine Dining khăn trắng', 'fine dining table|/faɪn ˈdaɪ.nɪŋ ˈteɪ.bəl/', '精致餐桌|jīngzhì cānzhuō', 'ダイニングテーブル|dainingu tēburu', '파인다이닝 테이블|paindaining teibeul', 'la table dressée|/tabl dʁɛ.se/', 'обеденный стол|obedennyy stol'],
    wineglass: ['🍷', 'ly pha lê rượu vang', 'crystal wine glass|/ˈkrɪs.təl waɪn ɡlæs/', '水晶酒杯|shuǐjīng jiǔbēi', 'ワイングラス|wain gurasu', '와인잔|wainjan', 'le verre à vin|/vɛʁ a vɛ̃/', 'бокал для вина|bokal dlya vina'],
    cloche: ['🛎️', 'nắp chụp đĩa bạc VIP', 'silver cloche|/ˈsɪl.vɚ kloʊʃ/', '银质餐盖|yínzhì cāngài', 'シルバークローシュ|shirubā kurōshu', '실버 클로슈|silbeo keullosyu', 'la cloche en argent|/klɔʃ/', 'серебряный клош|serebryanyy klosh'],
    cashier: ['💳', 'quầy thu ngân & máy POS', 'cashier counter|/kæˈʃɪr ˈkaʊn.t̬ɚ/', '收银台|shōuyíntái', 'レジカウンター|reji kauntā', '캐셔 카운터|kaesyeo kaunteo', 'la caisse|/kɛs/', 'касса|kassa'],
    barcounter: ['🍸', 'quầy Bar đá cẩm thạch', 'marble bar counter|/ˈmɑːr.bəl bɑːr/', '吧台|bātái', 'バーカウンター|bā kauntā', '바 카운터|ba kaunteo', 'le comptoir du bar|/kɔ̃.twaʁ/', 'барная стойка|barnaya stoyka'],
    winerack: ['🍾', 'tủ rượu vang Sommelier', 'wine cellar rack|/waɪn ˈsel.ɚ ræk/', '酒架|jiǔjià', 'ワインラック|wain rakku', '와인 셀러|wain selleo', 'la cave à vin|/kav a vɛ̃/', 'винный стеллаж|vinnyy stellazh'],
    espresso: ['☕', 'máy pha Espresso chuyên nghiệp', 'espresso machine|/eˈspres.oʊ məˈʃiːn/', '意式咖啡机|yìshì kāfēijī', 'エスプレッソマシン|esupuressomashin', '에스프레소 머신|eseupeureso meosin', 'la machine à expresso|/ma.ʃin/', 'кофемашина|kofemashina'],
    decanter: ['🏺', 'bình gạn thở rượu vang', 'wine decanter|/waɪn dɪˈkæn.t̬ɚ/', '醒酒器|xǐngjiǔqì', 'デキャンタ|dekyanta', '디캔터|dikaenteo', 'la carafe à décanter|/ka.ʁaf/', 'декантер|dekanter'],
    passcounter: ['🔥', 'quầy Pass ra món đèn nhiệt', 'heated pass counter|/ˈhiː.t̬ɪd pæs/', '出菜台|chūcàitái', 'パスカウンター|pasu kauntā', '패스 카운터|paeseu kaunteo', 'le passe-plat|/pɑs.pla/', 'раздаточный стол|razdatochnyy stol'],
    stove: ['🍳', 'bếp Âu áp chảo công nghiệp', 'commercial range|/kəˈmɜːr.ʃəl reɪndʒ/', '商用炉灶|shāngyòng lúzào', '業務用コンロ|gyōmuyō konro', '업소용 레인지|eopsoyong reinji', 'le fourneau|/fuʁ.no/', 'промышленная плита|promyshlennaya plita'],
    hood: ['💨', 'hệ thống chụp hút khói inox', 'exhaust hood|/ɪɡˈzɔːst hʊd/', '排烟罩|páiyānzhào', 'レンジフード|renji fūdo', '환기 후드|hwangi hudeu', 'la hotte|/ɔt/', 'вытяжка|vytyazhka'],
    prepstation: ['🔪', 'bàn sơ chế Mise en place & thớt màu', 'mise en place table|/ˌmiːz ɑːn ˈplɑːs/', '备餐台|bèicāntái', '仕込み台|shikomi-dai', '미장플라스 작업대|mijangpeullaseu jageopdae', 'la table de préparation|/pʁe.pa.ʁa.sjɔ̃/', 'разделочный стол|razdelochnyy stol'],
    oven: ['🥐', 'lò nướng đối lưu Pastry', 'convection oven|/kənˈvek.ʃən ˈʌv.ən/', '对流烤箱|duìliú kǎoxiāng', 'オーブン|ōbun', '컨벡션 오븐|keonbeksyeon obeun', 'le four|/fuʁ/', 'конвекционная печь|konvektsionnaya pech’'],
    kingbed: ['🛏️', 'giường King Suite ga cotton Ai Cập', 'king-size bed|/ˈkɪŋ.saɪz bed/', '特大号双人床|tèdàhào chuáng', 'キングベッド|kingu beddo', '킹사이즈 침대|kingsaijeu chimdae', 'le lit king-size|/li/', 'кровать кинг-сайз|krovat’ king-sayz'],
    pillowmenu: ['💤', 'bộ gối ngủ thảo mộc cao cấp', 'luxury pillows|/ˈlʌk.ʃɚ.i ˈpɪl.oʊz/', '定制枕头|dìngzhì zhěntou', 'ピローメニュー|pirō menyū', '프리미엄 베개|peurimieom begae', 'les oreillers|/ɔ.ʁɛ.je/', 'подушки люкс|podushki lyuks'],
    bathtub: ['🛁', 'bồn tắm đá cẩm thạch ngâm mình', 'marble bathtub|/ˈmɑːr.bəl ˈbæθ.tʌb/', '大理石浴缸|dàlǐshí yùgāng', '大理石バスタブ|dairiseki basutabu', '대리석 욕조|daeriseok yokjo', 'la baignoire en marbre|/bɛ.ɲwaʁ/', 'мраморная ванна|mramornaya vanna'],
    minibar: ['🥂', 'quầy Minibar & máy pha trà', 'suite minibar|/swiːt ˈmɪn.i.bɑːr/', '迷你吧|mínǐbā', 'ミニバー|minibā', '미니바|miniba', 'le minibar|/mi.ni.baʁ/', 'мини-бар|mini-bar'],
    wardrobe: ['👔', 'tủ quần áo & dịch vụ giặt khô', 'walk-in closet|/ˈwɔːk.ɪn ˈklɑː.zət/', '衣帽间|yīmàojiān', 'クローゼット|kurōzetto', '드레스룸 옷장|deureseurum otjang', 'la penderie|/pɑ̃d.ʁi/', 'гардероб|garderob'],
    massagebed: ['🌺', 'giường trị liệu tinh dầu Spa', 'treatment bed|/ˈtriːt.mənt bed/', '水疗护理床|shuǐliáo hùlǐchuáng', 'スパベッド|supa beddo', '스파 베드|seupa bedeu', 'la table de massage|/ma.saʒ/', 'массажный стол|massazhnyy stol'],
    hydropool: ['💧', 'hồ thuỷ trị liệu khoáng ấm', 'hydrotherapy pool|/ˌhaɪ.droʊˈθer.ə.pi puːl/', '水疗按摩池|shuǐliáo ànmóchí', 'ハイドロプール|haidoropūru', '하이드로테라피 풀|haideuroterapi pul', 'le bassin thermal|/ba.sɛ̃/', 'гидромассажный бассейн|gidromassazhnyy basseyn'],
    cabana: ['🏖️', 'chòi nghỉ Cabana hướng biển', 'oceanfront cabana|/ˈoʊ.ʃən.frʌnt kəˈbæn.ə/', '海景凉亭|hǎijǐng liángtíng', 'ビーチカバナ|bīchi kabana', '오션프론트 카바나|osyeonpeuronteu kabana', 'la cabana de plage|/ka.ba.na/', 'пляжная кабана|plyazhnaya kabana'],
    yacht: ['🛥️', 'du thuyền hai tầng hạng sang', 'luxury cruise yacht|/ˈlʌk.ʃɚ.i kruːz jɑːt/', '豪华游艇|háohuá yóutǐng', 'クルーズヨット|kurūzu yotto', '럭셔리 크루즈 요트|reoksyeori keurujeu yoteu', 'le yacht de croisière|/jɔt/', 'круизная яхта|kruiznaya yakhta'],
    ticketbooth: ['🎫', 'quầy vé Bến du thuyền Marina', 'marina ticket booth|/məˈriː.nə ˈtɪk.ɪt buːθ/', '码头售票亭|mǎtóu shòupiàotíng', '乗船券売り場|jōsenken uriba', '마리나 매표소|marina maepyoso', 'la billetterie|/bi.jɛ.tʁi/', 'билетная касса|biletnaya kassa'],
    lifebuoy: ['🛟', 'phao cứu sinh mạn tàu', 'lifebuoy|/ˈlaɪf.bɔɪ/', '救生圈|jiùshēngquān', '救命浮輪|kyūmei ukiwa', '구명부환|gumyeongbuhwan', 'la bouée de sauvetage|/bwe/', 'спасательный круг|spasatel’nyy krug'],
    podium: ['🎙️', 'bục phát biểu hội nghị MICE', 'keynote podium|/ˈkiː.noʊt ˈpoʊ.di.əm/', '演讲台|yǎnjiǎngtái', '演台|endai', '연단 포디움|yeondan podium', 'le pupitre de conférence|/py.pitʁ/', 'трибуна|tribuna'],
    champagne: ['🥂', 'tháp ly rượu Sâm-panh đại tiệc', 'champagne tower|/ʃæmˈpeɪn ˈtaʊ.ɚ/', '香槟塔|xiāngbīntǎ', 'シャンパンタワー|shanpan tawā', '샴페인 타워|syampein tawo', 'la pyramide de champagne|/ʃɑ̃.paɲ/', 'пирамида из шампанского|piramida iz shampanskogo'],
    coffeebreak: ['🥐', 'quầy trà bánh giải lao MICE', 'coffee break station|/ˈkɔː.fi breɪk ˈsteɪ.ʃən/', '茶歇台|cháxiētái', 'コーヒーブレイク台|kōhī bureiku-dai', '커피 브레이크 스테이션|keopi beureikeu seuteisyeon', 'le buffet pause-café|/pɔz ka.fe/', 'зона кофе-брейка|zona kofe-breyka'],
    dutydesk: ['🛡️', 'bàn Quản lý Trực ca (Duty Manager)', 'duty manager desk|/ˈduː.t̬i ˈmæn.ɪ.dʒɚ desk/', '值班经理台|zhíbān jīnglǐtái', '当直マネージャー席|tōchoku manējā-seki', '당직 지배인 데스크|dangjik jibaein deseukeu', 'le bureau du directeur de garde|/by.ʁo/', 'стойка дежурного менеджера|stoyka dezhurnogo menedzhera'],
    briefingboard: ['📋', 'bảng giao ban ca & chỉ số KPI', 'shift briefing board|/ʃɪft ˈbriː.fɪŋ bɔːrd/', '班前例会白板|bānqián lìhuì báibǎn', 'ブリーフィングボード|burīfingu bōdo', '교대 브리핑 보드|gyodae beuriping bodeu', 'le tableau de briefing|/ta.blo/', 'доска планёрки|doska planyorki'],
    plant: ['🌿', 'cây cảnh nhiệt đới trang trí sảnh', 'lobby palm plant|/ˈlɑː.bi pɑːm plænt/', '大堂绿植|dàtáng lǜzhí', '観葉植物|kan’yō shokubutsu', '로비 화분|robi hwabun', 'la plante tropicale|/plɑ̃t/', 'тропическое растение|tropicheskoye rasteniye']
  };

  /* ── 2. HỘP CHẠM KHÁM PHÁ 3D CHO TẤT CẢ 12 NƠI (PLACE_EXPLORE) ── */
  window.PLACE_EXPLORE = {
    lobby: [
      ['reception', -5, 0.7, -4.6, 7.2, 1.5, 1.4],
      ['bell', -3.2, 1.48, -4.4, 0.6, 0.5, 0.6],
      ['keyrack', -5, 3.0, -8.6, 3.2, 2.5, 0.4],
      ['chandelier', 0, 5.6, 0, 2.2, 1.2, 2.2],
      ['sofa', 8, 0.6, 5, 3.6, 1.2, 1.5],
      ['luggagecart', -9.4, 1.1, 3.6, 1.6, 2.2, 1.1],
      ['conciergedesk', 7, 0.7, -6, 2.8, 1.4, 1.2],
      ['plant', -10.5, 0.9, -7.4, 1.2, 1.8, 1.2]
    ],
    concierge: [
      ['conciergedesk', -4.5, 0.7, -4.8, 5.6, 1.5, 1.4],
      ['globe', -2.6, 1.65, -4.8, 0.9, 1.0, 0.9],
      ['sofa', 6.5, 0.6, 2.8, 3.6, 1.2, 1.6],
      ['champagne', 6.5, 1.35, -5.2, 2.4, 1.3, 1.2],
      ['chandelier', 0, 5.6, -1, 2.0, 1.2, 2.0],
      ['luggagecart', -9.2, 1.1, 3.4, 1.6, 2.2, 1.1],
      ['plant', 9.6, 0.9, -7.2, 1.2, 1.8, 1.2]
    ],
    bell: [
      ['limo', -5.4, 1.0, -1.2, 5.6, 1.9, 2.4],
      ['shuttle', 6.2, 1.3, -1.2, 5.8, 2.4, 2.4],
      ['valetstand', -7.2, 0.8, 5.0, 1.8, 1.6, 1.2],
      ['luggagecart', 0.4, 1.1, 4.8, 1.8, 2.2, 1.1],
      ['reception', 0, 0.8, -7.4, 5.0, 1.6, 1.2],
      ['plant', -11.5, 0.9, -6.8, 1.3, 1.8, 1.3]
    ],
    restaurant: [
      ['hoststand', -2.8, 0.7, 6.4, 1.9, 1.4, 0.9],
      ['diningtable', -5.5, 1.2, -3, 2.3, 0.4, 2.3],
      ['diningtable', -1, 1.2, 2, 2.3, 0.4, 2.3],
      ['wineglass', -0.6, 1.48, 1.65, 0.4, 0.4, 0.4],
      ['cloche', 5.5, 1.48, -3, 0.8, 0.5, 0.8],
      ['passcounter', 0, 0.7, -7.4, 9.0, 1.4, 1.2],
      ['cashier', 7.6, 0.7, 5, 1.2, 1.5, 3.0],
      ['plant', -9, 0.9, -8, 1.1, 1.8, 1.1]
    ],
    bar: [
      ['barcounter', -2.6, 0.7, -4.8, 9.2, 1.4, 1.4],
      ['winerack', -2.6, 2.9, -8.4, 7.6, 2.8, 0.7],
      ['espresso', -5.6, 1.75, -4.8, 1.4, 0.9, 0.9],
      ['decanter', 0.4, 1.6, -4.8, 0.7, 0.7, 0.7],
      ['sofa', 8.4, 0.55, 2.6, 1.4, 1.0, 3.2],
      ['diningtable', 6.4, 1.15, -2.0, 2.0, 0.4, 2.0],
      ['plant', -8.8, 0.9, 6.8, 1.1, 1.8, 1.1]
    ],
    kitchen: [
      ['passcounter', 0, 0.7, 1.8, 8.6, 1.4, 1.3],
      ['cloche', -1.8, 1.5, 1.8, 0.8, 0.5, 0.8],
      ['stove', -5.2, 0.7, -5.8, 5.2, 1.4, 1.4],
      ['hood', -5.2, 4.3, -5.8, 5.4, 0.9, 1.6],
      ['prepstation', 5.4, 0.65, -1.8, 4.4, 1.3, 1.4],
      ['oven', 6.2, 1.4, -6.2, 2.6, 2.6, 1.4]
    ],
    suite: [
      ['kingbed', -4.8, 0.75, -4.2, 4.2, 1.5, 4.8],
      ['pillowmenu', -4.8, 1.35, -6.0, 3.2, 0.6, 1.0],
      ['bathtub', 6.8, 0.55, -6.6, 3.4, 1.1, 1.8],
      ['wardrobe', 8.2, 1.8, 1.8, 1.0, 3.6, 3.2],
      ['minibar', -8.0, 0.9, 2.8, 1.3, 1.8, 2.2],
      ['sofa', -3.6, 0.6, 4.8, 3.6, 1.1, 1.4],
      ['plant', 8.0, 0.9, 6.4, 1.1, 1.8, 1.1]
    ],
    spa: [
      ['reception', -6.8, 0.7, 4.2, 3.8, 1.4, 1.2],
      ['massagebed', -5.6, 0.65, -4.6, 2.0, 1.1, 3.4],
      ['hydropool', 5.2, 0.3, -4.2, 6.6, 0.8, 4.8],
      ['cabana', 6.2, 1.5, 4.2, 3.8, 2.8, 3.2],
      ['plant', -10.2, 0.9, -7.2, 1.2, 1.8, 1.2]
    ],
    pier: [
      ['ticketbooth', -6, 1.4, 3.4, 3.6, 2.8, 2.2],
      ['yacht', 8, 1.4, -6, 5.2, 3.2, 14.0],
      ['barcounter', 8, 0.8, -5.2, 2.4, 1.2, 0.9],
      ['lifebuoy', 10.6, 0.7, -3.8, 0.8, 0.8, 0.4]
    ],
    banquet: [
      ['podium', 0, 1.5, -6.8, 1.8, 2.2, 1.2],
      ['champagne', -3.9, 1.5, -7.0, 1.8, 1.5, 1.2],
      ['diningtable', 7.5, 0.8, -3.0, 3.2, 1.2, 3.2],
      ['cloche', 7.5, 1.2, -3.0, 1.0, 0.5, 1.0],
      ['coffeebreak', -7.5, 0.8, 4.6, 3.4, 1.4, 1.2],
      ['chandelier', 0, 6.0, 3.0, 2.0, 1.2, 2.0]
    ],
    recovery: [
      ['dutydesk', -5, 0.7, -4.6, 6.8, 1.5, 1.4],
      ['bell', -3.4, 1.48, -4.4, 0.6, 0.5, 0.6],
      ['sofa', 7.2, 0.6, 4.6, 3.6, 1.2, 1.4],
      ['conciergedesk', 7, 0.7, -6, 2.8, 1.4, 1.2],
      ['plant', -10.4, 0.9, 6.8, 1.2, 1.8, 1.2]
    ],
    interview: [
      ['dutydesk', 6.5, 0.7, -5.6, 3.8, 1.4, 1.8],
      ['briefingboard', -6, 3.0, -8.7, 4.6, 2.2, 0.4],
      ['diningtable', -6, 0.8, -5.0, 5.2, 1.2, 2.4],
      ['coffeebreak', 10.2, 0.9, 4.6, 1.2, 1.8, 4.2],
      ['plant', 9.8, 0.9, -7.8, 1.2, 1.8, 1.2]
    ]
  };

  /* ── 3. TỪ ĐIỂN NHANH TRONG TÌNH HUỐNG (PLACE_GLOSS) ── */
  window.PLACE_GLOSS = {
    en: {
      reservation: 'đặt phòng / đặt bàn trước',
      suite: 'phòng nghỉ hạng sang Suite',
      keycard: 'thẻ từ mở cửa phòng',
      deposit: 'tiền đặt cọc chi phí phát sinh',
      complimentary: 'miễn phí tặng kèm chuẩn 5 sao',
      folio: 'bảng kê chi tiết chi phí phòng',
      concierge: 'bộ phận hỗ trợ đặc quyền khách VIP',
      itinerary: 'lịch trình tham quan cá nhân hoá',
      chauffeur: 'tài xế xe sang riêng',
      shuttle: 'xe đưa đón theo lịch trình',
      valet: 'nhân viên đỗ xe cho khách',
      luggage: 'hành lý lưu trú',
      appetizer: 'món khai vị đầu bữa',
      allergies: 'dị ứng thực phẩm',
      allergy: 'dị ứng thực phẩm',
      cutlery: 'bộ dao nĩa bàn tiệc',
      sommelier: 'chuyên gia tư vấn rượu vang',
      bouquet: 'tầng hương rượu vang ủ',
      decant: 'gạn thở rượu vang trong bình pha lê',
      mocktail: 'cocktail trái cây không cồn',
      microfoam: 'lớp bọt sữa mịn pha Latte Art',
      scallops: 'cồi sò điệp áp chảo',
      allergen: 'tác nhân gây dị ứng',
      temperature: 'nhiệt độ tâm an toàn HACCP',
      turndown: 'chỉnh trang phòng nghỉ buổi tối',
      amenities: 'bộ tiện nghi phòng tắm',
      butler: 'quản gia riêng 24/7',
      hydrotherapy: 'thuỷ trị liệu khoáng ấm',
      cabana: 'chòi nghỉ sang trọng cạnh hồ bơi / biển',
      podium: 'bục phát biểu hội nghị',
      cloche: 'nắp chụp đĩa bạc phục vụ VIP',
      apologize: 'xin lỗi chân thành chuẩn 5 sao',
      inconvenience: 'sự bất tiện ngoài ý muốn',
      upgrade: 'nâng hạng phòng miễn phí / ưu đãi',
      briefing: 'buổi họp giao ban đầu ca'
    }
  };

  /* ── 4. CÁCH NÓI KHÁC & CẤU TRÚC NGỮ PHÁP 5 SAO (PLACE_MORE) ── */
  window.PLACE_MORE = {
    en: {
      'Welcome to GrandSpeak Resort! May I have your passport and booking name, please?': {
        alt: [
          ['Good afternoon! Could I kindly see your passport to locate your reservation?', '', 'Chào buổi chiều! Xin phép cho tôi mượn hộ chiếu để tra đơn đặt phòng ạ?', 'Trang trọng · Chuẩn 5★'],
          ['Warmest welcome! Under which name was the suite reserved, please?', '', 'Nồng nhiệt chào mừng quý khách! Phòng Suite được đặt dưới tên ai ạ?', 'Thân thiện · Tinh tế']
        ],
        form: 'May I + V (nguyên mẫu) + …, please?',
        notes: [
          'Trong khách sạn 5 sao, luôn mở đầu bằng "May I…" hoặc "Could I kindly…" thay vì câu mệnh lệnh trực tiếp "Give me your passport".',
          'Khi nhận giấy tờ từ khách, kết hợp ánh mắt ấm áp và hai tay đón nhận.'
        ]
      },
      'Certainly! Breakfast is complimentary from 6:30 to 10:30 a.m. at our Ocean Restaurant.': {
        alt: [
          ['Yes, indeed! Full buffet breakfast is included daily until 10:30 a.m.', '', 'Dạ đúng vậy! Bữa sáng tự chọn đã bao gồm mỗi ngày đến 10:30 sáng ạ.', 'Ngắn gọn · Rõ ràng'],
          ['Of course! Enjoy complimentary breakfast overlooking the bay from 6:30 a.m.', '', 'Dạ tất nhiên! Mời quý khách thưởng thức bữa sáng miễn phí hướng vịnh từ 6:30 sáng.', 'Gợi cảm hứng nghỉ dưỡng']
        ],
        form: 'Service + is complimentary + from [giờ] to [giờ] + at [địa điểm]',
        notes: [
          'Dùng từ "complimentary" (tặng kèm trang trọng) thay cho từ "free" trong mọi giao tiếp 5 sao.'
        ]
      },
      'Do any guests at the table have food allergies or dietary restrictions?': {
        alt: [
          ['Before I send your order to the kitchen, may I check for any food allergies?', '', 'Trước khi chuyển đơn xuống bếp, xin phép kiểm tra bàn mình có ai dị ứng thực phẩm không ạ?', 'Chuẩn quy trình F&B'],
          ['Are there any dietary preferences or allergies our chef should be aware of?', '', 'Có chế độ ăn kiêng hay dị ứng nào cần lưu ý riêng với Bếp trưởng không ạ?', 'Chuẩn Fine Dining']
        ],
        form: 'Do any guests have + food allergies / dietary restrictions?',
        notes: [
          'Hỏi dị ứng (Allergen Check) là bước bắt buộc trong SOP Fine Dining trước khi chốt order.'
        ]
      },
      'I sincerely apologize for the inconvenience. Allow me to send our technician immediately.': {
        alt: [
          ['Please accept my deepest apologies. Our engineering team will inspect it within five minutes.', '', 'Xin quý khách nhận lời xin lỗi chân thành nhất. Đội kỹ thuật sẽ kiểm tra trong vòng 5 phút.', 'Quy trình L.A.S.T.'],
          ['I am truly sorry about that. Let me take personal ownership and arrange an immediate room upgrade.', '', 'Tôi thực sự xin lỗi. Xin để cá nhân tôi phụ trách và thu xếp nâng hạng phòng ngay cho quý khách.', 'Cứu ca VIP']
        ],
        form: 'I sincerely apologize for + [sự cố]. Allow me to + [giải pháp ngay].',
        notes: [
          'Quy trình vàng L.A.S.T.: Listen (Lắng nghe) → Apologize (Xin lỗi chân thành) → Solve (Đưa giải pháp có mốc thời gian) → Thank (Cảm ơn khách đã phản hồi).'
        ]
      }
    }
  };

  /* ── 5. LƯỢT CHÀO TẠM BIỆT CUỐI TÌNH HUỐNG (FAREWELL) ── */
  window.FAREWELL = (function () {
    var END_RX = /\b(goodbye|bye|have a wonderful|enjoy your stay|enjoy your evening|my pleasure|see you)\b|再见|さようなら|안녕히|au revoir|до свидания/i;
    var PACKS = {
      en: {
        guestThanks: [
          'Thank you so much for your wonderful assistance!||Cảm ơn bạn rất nhiều vì sự hỗ trợ tuyệt vời!',
          'My pleasure! Have a wonderful stay at GrandSpeak Resort!||Rất hân hạnh được phục vụ quý khách! Chúc quý khách kỳ nghỉ tuyệt vời tại GrandSpeak Resort!',
          'Hello! What is your room number?||(sai thời điểm) Xin chào! Số phòng của bạn là gì?',
          'I am going home to sleep now.||(thiếu chuyên nghiệp) Giờ tôi đi về ngủ đây.'
        ],
        chefPass: [
          'Great teamwork on the pass! Keep the pace sharp, Chef!||Phối hợp tại quầy Pass rất tốt! Giữ vững nhịp độ nhé!',
          'Yes, Chef! All stations are clean and ready for the next table!||Rõ thưa Bếp trưởng! Mọi quầy đã sạch sẽ và sẵn sàng cho bàn tiếp theo!',
          'Good night, see you next year!||(lạc đề) Chúc ngủ ngon, hẹn năm sau gặp lại!',
          'Where is the swimming pool?||(lạc đề) Hồ bơi ở đâu vậy?'
        ],
        hrEnd: [
          'Thank you for sharing your hospitality experience today.||Cảm ơn bạn đã chia sẻ kinh nghiệm dịch vụ ngày hôm nay.',
          'Thank you for your time and consideration. Have a great shift!||Cảm ơn anh/chị đã dành thời gian lắng nghe. Chúc anh/chị một ca làm việc hiệu quả!',
          'Give me the salary right now.||(thiếu lịch sự) Đưa lương cho tôi ngay bây giờ.',
          'I forgot where I live.||(lạc đề) Tôi quên mất nhà mình ở đâu rồi.'
        ]
      },
      zh: {
        guestThanks: [
          '非常感谢您周到的服务！|Fēicháng gǎnxiè nín zhōudào de fúwù!|Cảm ơn dịch vụ chu đáo của bạn!',
          '这是我的荣幸！祝您入住愉快！|Zhè shì wǒ de róngxìng! Zhù nín rùzhù yúkuài!|Đó là vinh hạnh của tôi! Chúc quý khách lưu trú vui vẻ!',
          '你好！你叫什么名字？|Nǐ hǎo! Nǐ jiào shénme míngzi?|(sai thời điểm) Xin chào! Bạn tên là gì?',
          '我现在很饿。|Wǒ xiànzài hěn è.|(lạc đề) Bây giờ tôi rất đói.'
        ]
      },
      ja: {
        guestThanks: [
          '丁寧なご対応ありがとうございます！|Teinei na gotaiō arigatō gozaimasu!|Cảm ơn sự phục vụ chu đáo của bạn!',
          'どういたしまして。どうぞ素敵なご滞在をお楽しみください！|Dō itashimashite. Dōzo suteki na gotaizai o otanoshimi kudasai!|Rất hân hạnh. Chúc quý khách kỳ nghỉ tuyệt vời!',
          'はじめまして！|Hajimemashite!|(sai thời điểm) Rất vui được gặp lần đầu!',
          'お腹が空きました。|Onaka ga sukimashita.|(lạc đề) Tôi đói bụng rồi.'
        ]
      },
      ko: {
        guestThanks: [
          '친절하게 도와주셔서 정말 감사합니다!|Chinjeolhage dowajusyeoseo jeongmal gamsahamnida!|Cảm ơn bạn đã hỗ trợ rất tận tình!',
          '별말씀을요! 저희 리조트에서 즐거운 시간 보내세요!|Byeolmalsseumeullyo! Jeohui rijoteueseo jeulgeoun sigan bonaeseyo!|Rất hân hạnh ạ! Chúc quý khách kỳ nghỉ thật vui vẻ!',
          '처음 뵙겠습니다!|Cheoeum boepgetseumnida!|(sai thời điểm) Lần đầu gặp mặt!',
          '저는 지금 졸려요.|Jeoneun jigeum jollyeoyo.|(lạc đề) Giờ tôi buồn ngủ quá.'
        ]
      },
      fr: {
        guestThanks: [
          'Merci infiniment pour votre accueil cinq étoiles !||Cảm ơn rất nhiều vì sự đón tiếp chuẩn 5 sao!',
          'Avec grand plaisir ! Je vous souhaite un excellent séjour parmi nous !||Rất hân hạnh! Chúc quý khách kỳ lưu trú tuyệt vời cùng chúng tôi!',
          'Bonjour, comment vous appelez-vous ?||(sai thời điểm) Xin chào, bạn tên gì?',
          'J’ai très faim maintenant.||(lạc đề) Giờ tôi đói lắm.'
        ]
      },
      ru: {
        guestThanks: [
          'Большое спасибо за прекрасное обслуживание!|Bol’shoye spasibo za prekrasnoye obsluzhivaniye!|Cảm ơn rất nhiều vì dịch vụ tuyệt vời!',
          'Всегда пожалуйста! Желаем вам чудесного отдыха!|Vsegda pozhaluysta! Zhelayem vam chudesnogo otdykha!|Rất hân hạnh! Chúc quý khách kỳ nghỉ tuyệt đẹp!',
          'Здравствуйте, как вас зовут?|Zdravstvuyte, kak vas zovut?|(sai thời điểm) Xin chào, bạn tên gì?',
          'Я хочу спать.|Ya khochu spat’.|(lạc đề) Tôi muốn đi ngủ.'
        ]
      }
    };
    return {
      done: function (turns) {
        var last = turns[turns.length - 1];
        return !last || END_RX.test(String(last[0])) || (last[1] === 'mc' && END_RX.test(String(last[2][0])));
      },
      kindOf: function (place) {
        if (place === 'kitchen') return 'chefPass';
        if (place === 'interview') return 'hrEnd';
        return 'guestThanks';
      },
      turn: function (lang, kind, spot) {
        var L = PACKS[lang] || PACKS.en;
        var row = L[kind] || L.guestThanks;
        return [row[0], 'mc', [row[1], row[2], row[3]], spot];
      }
    };
  })();

  /* ── 6. BỘ DỮ LIỆU 12 KHU VỰC 3D × CẤP ĐỘ 1 (SƠ CẤP) ──
     Lưu ý quan trọng: Trong GrandSpeak, NGƯỜI HỌC đóng vai Nhân sự Khách sạn 5★ (Bạn = Lễ tân / Phục vụ / Sommelier / Bếp / Butler / Quản lý),
     còn NPC trong cảnh đóng vai Khách Quốc tế VIP / Bếp trưởng / Nhà tuyển dụng! */

  var LANG_META = {
    en: { name: 'Tiếng Anh 5★', flag: '🇬🇧', lang: 'en-GB' },
    zh: { name: 'Tiếng Trung VIP', flag: '🇨🇳', lang: 'zh-CN' },
    ja: { name: 'Tiếng Nhật VIP', flag: '🇯🇵', lang: 'ja-JP' },
    ko: { name: 'Tiếng Hàn VIP', flag: '🇰🇷', lang: 'ko-KR' },
    fr: { name: 'Tiếng Pháp 5★', flag: '🇫🇷', lang: 'fr-FR' },
    ru: { name: 'Tiếng Nga Resort', flag: '🇷🇺', lang: 'ru-RU' }
  };

  /* Kịch bản Đa Ngôn Ngữ Quốc Tế cho các nơi đón khách (khi chọn zh/ja/ko/fr/ru) */
  function makeMultilangFallback(shopTitle, spotDefault, viTitle, enTitle) {
    return {
      zh: {
        name: LANG_META.zh.name, flag: LANG_META.zh.flag, lang: LANG_META.zh.lang, shop: shopTitle,
        scenes: [
          sc(viTitle, enTitle, [
            ['您好！请问这里可以帮忙吗？|Nín hǎo! Qǐngwèn zhèlǐ kěyǐ bāngmáng ma?|Xin chào! Cho hỏi ở đây có thể hỗ trợ tôi được không?', 'mc', [
              '您好，欢迎光临！请问有什么可以帮您？|Nín hǎo, huānyíng guānglín! Qǐngwèn yǒu shénme kěyǐ bāng nín?|Xin chào, nồng nhiệt chào mừng quý khách! Tôi có thể hỗ trợ gì cho ngài ạ?',
              '我不知道你是谁。|Wǒ bù zhīdào nǐ shì shéi.|(sai) Tôi không biết bạn là ai.',
              '今天下雨了。|Jīntiān xià yǔ le.|(lạc đề) Hôm nay trời mưa rồi.'
            ], spotDefault],
            ['我想确认一下我的预订信息。|Wǒ xiǎng quèrèn yíxià wǒ de yùdìng xìnxī.|Tôi muốn xác nhận thông tin đặt chỗ của mình.', 'fill',
              '请出示您的{护照}，我马上为您查询。|Qǐng chūshì nín de hùzhào, wǒ mǎshàng wèi nín cháxún.|Xin quý khách xuất trình hộ chiếu, tôi kiểm tra ngay cho ngài ạ.',
              ['苹果', '天气', '运动'], spotDefault],
            ['太好了，服务真周到！|Tài hǎo le, fúwù zhēn zhōudào!|Tuyệt quá, dịch vụ thật chu đáo!', 'mc', [
              '谢谢您的夸奖！请这边走。|Xièxie nín de kuājiǎng! Qǐng zhèbiān zǒu.|Cảm ơn lời khen của quý khách! Xin mời đi lối này ạ.',
              '我要回家睡觉。|Wǒ yào huí jiā shuìjiào.|(sai) Tôi muốn về nhà ngủ.',
              '这个太贵了。|Zhège tài guì le.|(lạc đề) Cái này đắt quá.'
            ], spotDefault]
          ])
        ]
      },
      ja: {
        name: LANG_META.ja.name, flag: LANG_META.ja.flag, lang: LANG_META.ja.lang, shop: shopTitle,
        scenes: [
          sc(viTitle, enTitle, [
            ['すみません、少しお願いできますか。|Sumimasen, sukoshi onegai dekimasu ka.|Xin lỗi, tôi có thể nhờ hỗ trợ một chút được không?', 'mc', [
              'いらっしゃいませ！どのようなご用件でしょうか。|Irasshaimase! Dono yō na goyōken deshō ka.|Xin chào mừng quý khách! Tôi có thể hỗ trợ điều gì cho ngài ạ?',
              'わかりません、さようなら。|Wakarimasen, sayōnara.|(sai) Tôi không biết, tạm biệt.',
              '今日は暑いです。|Kyō wa atsui desu.|(lạc đề) Hôm nay trời nóng.'
            ], spotDefault],
            ['予約を確認したいのですが。|Yoyaku o kakunin shitai no desu ga.|Tôi muốn kiểm tra thông tin đặt chỗ.', 'fill',
              'かしこまりました。{パスポート}を拝見できますか。|Kashikomarimashita. Pasupōto o haiken dekimasu ka.|Dạ vâng. Xin phép cho tôi kiểm tra hộ chiếu của quý khách ạ.',
              ['りんご', '傘', '電車'], spotDefault],
            ['ありがとうございます、とても助かります。|Arigatō gozaimasu, totemo tasukarimasu.|Cảm ơn bạn, thật sự rất hữu ích.', 'mc', [
              '恐れ入ります。こちらへどうぞご案内いたします。|Osoreirimasu. Kochira e dōzo goannai itashimasu.|Rất hân hạnh ạ. Xin phép hướng dẫn quý khách đi lối này.',
              '私は学生です。|Watashi wa gakusei desu.|(lạc đề) Tôi là học sinh.',
              'まだ食べていません。|Mada tabete imasen.|(lạc đề) Tôi chưa ăn.'
            ], spotDefault]
          ])
        ]
      },
      ko: {
        name: LANG_META.ko.name, flag: LANG_META.ko.flag, lang: LANG_META.ko.lang, shop: shopTitle,
        scenes: [
          sc(viTitle, enTitle, [
            ['실례합니다, 잠시 도와주실 수 있나요?|Sillyehamnida, jamsi dowajusil su innayo?|Xin lỗi, bạn hỗ trợ tôi một lát được không?', 'mc', [
              '어서 오십시오! 무엇을 도와드릴까요?|Eoseo osipsio! Mueoseul dowadeurilkkayo?|Chào mừng quý khách! Tôi có thể giúp gì cho quý khách ạ?',
              '잘 모르겠어요. 안녕히 가세요.|Jal moreugesseoyo. Annyeonghi gaseyo.|(sai) Tôi không biết. Tạm biệt.',
              '오늘 날씨가 추워요.|Oneul nalssiga chuwoyo.|(lạc đề) Hôm nay trời lạnh.'
            ], spotDefault],
            ['예약 내역을 확인하고 싶어요.|Yeyak naeyeogeul hwaginhago sipeoyo.|Tôi muốn kiểm tra thông tin đặt trước.', 'fill',
              '네, 고객님. {여권}을 보여 주시겠어요?|Ne, gogaengnim. Yeogwoneul boyeo jusigesseoyo?|Dạ vâng thưa quý khách. Xin vui lòng cho tôi xem hộ chiếu ạ?',
              ['사과', '우산', '지하철'], spotDefault],
            ['정말 친절하시네요, 감사합니다!|Jeongmal chinjeolhasineyo, gamsahamnida!|Bạn thật thân thiện, cảm ơn nhé!', 'mc', [
              '감사합니다! 이쪽으로 안내해 드리겠습니다.|Gamsahamnida! Ijjogeuro annaehae deurigetseumnida.|Xin cảm ơn quý khách! Tôi xin hướng dẫn quý khách đi lối này ạ.',
              '저는 배가 고파요.|Jeoneun baega gopayo.|(lạc đề) Tôi đói bụng.',
              '어제 영화를 봤어요.|Eoje yeonghwareul bwasseoyo.|(lạc đề) Hôm qua tôi xem phim.'
            ], spotDefault]
          ])
        ]
      },
      fr: {
        name: LANG_META.fr.name, flag: LANG_META.fr.flag, lang: LANG_META.fr.lang, shop: shopTitle,
        scenes: [
          sc(viTitle, enTitle, [
            ['Bonjour ! Pourriez-vous m’aider, s’il vous plaît ?||Xin chào! Bạn có thể hỗ trợ tôi được không?', 'mc', [
              'Bienvenue au GrandSpeak ! Comment puis-je vous assister ?||Chào mừng đến GrandSpeak! Tôi có thể hỗ trợ ngài như thế nào ạ?',
              'Je ne sais pas qui vous êtes.||(sai) Tôi không biết ngài là ai.',
              'Il pleut beaucoup aujourd’hui.||(lạc đề) Hôm nay mưa to quá.'
            ], spotDefault],
            ['Je voudrais confirmer ma réservation.||Tôi muốn xác nhận đơn đặt chỗ của mình.', 'fill',
              'Certainement ! Puis-je voir votre {passeport}, s’il vous plaît ?||Dạ chắc chắn rồi! Xin phép cho tôi xem hộ chiếu của ngài ạ?',
              ['pomme', 'parapluie', 'vélo'], spotDefault],
            ['Parfait, votre service est remarquable !||Tuyệt hảo, dịch vụ của các bạn thật xuất sắc!', 'mc', [
              'Merci infiniment ! Permettez-moi de vous accompagner par ici.||Xin chân thành cảm ơn! Xin phép để tôi dẫn ngài đi lối này.',
              'Je vais dormir maintenant.||(sai) Giờ tôi đi ngủ đây.',
              'Mon train est parti.||(lạc đề) Tàu của tôi chạy mất rồi.'
            ], spotDefault]
          ])
        ]
      },
      ru: {
        name: LANG_META.ru.name, flag: LANG_META.ru.flag, lang: LANG_META.ru.lang, shop: shopTitle,
        scenes: [
          sc(viTitle, enTitle, [
            ['Здравствуйте! Вы можете мне помочь?|Zdravstvuyte! Vy mozhete mne pomoch’?|Xin chào! Bạn có thể hỗ trợ tôi không?', 'mc', [
              'Добро пожаловать в GrandSpeak! Чем могу вам помочь?|Dobro pozhalovat’ v GrandSpeak! Chem mogu vam pomoch’?|Chào mừng đến GrandSpeak! Tôi có thể phục vụ gì cho quý khách ạ?',
              'Я ничего не знаю.|Ya nichego ne znayu.|(sai) Tôi chẳng biết gì cả.',
              'Сегодня идёт дождь.|Segodnya idyot dozhd’.|(lạc đề) Hôm nay trời mưa.'
            ], spotDefault],
            ['Я хочу подтвердить своё бронирование.|Ya khochu podtverdit’ svoyo bronirovaniye.|Tôi muốn xác nhận đặt chỗ của mình.', 'fill',
              'Конечно! Покажите, пожалуйста, ваш {паспорт}.|Konechno! Pokazhite, pozhaluysta, vash pasport.|Dạ chắc chắn rồi! Xin vui lòng cho xem hộ chiếu của quý khách ạ.',
              ['яблоко', 'зонтик', 'поезд'], spotDefault],
            ['Отлично, у вас прекрасный сервис!|Otlichno, u vas prekrasnyy servis!|Tuyệt vời, dịch vụ của các bạn rất xuất sắc!', 'mc', [
              'Большое спасибо! Прошу вас пройти сюда.|Bol’shoye spasibo! Proshu vas proyti syuda.|Xin cảm ơn rất nhiều! Mời quý khách đi lối này ạ.',
              'Я очень устал.|Ya ochen’ ustal.|(sai) Tôi mệt lắm rồi.',
              'Где автобус?|Gde avtobus?|(lạc đề) Xe buýt đâu?'
            ], spotDefault]
          ])
        ]
      }
    };
  }

  function registerPlace(globalName, shopTitle, spotDefault, enScenes, firstSceneVi, firstSceneEn) {
    var ml = makeMultilangFallback(shopTitle, spotDefault, firstSceneVi, firstSceneEn);
    window[globalName] = {
      en: { name: LANG_META.en.name, flag: LANG_META.en.flag, lang: LANG_META.en.lang, shop: shopTitle, scenes: enScenes },
      zh: ml.zh,
      ja: ml.ja,
      ko: ml.ko,
      fr: ml.fr,
      ru: ml.ru
    };
  }

  /* 1) SẢNH LỄ TÂN & CHECK-IN 5★ (LOBBY) — spots: front, lounge, sofa */
  registerPlace('GS_LOBBY', 'Grand Lobby 5★', 'front', [
    sc('Thủ tục nhận phòng Suite', 'Checking in to an Ocean Suite', [
      ['Good afternoon! I have a reservation under the name Anderson.||Chào buổi chiều! Tôi có đặt phòng dưới tên Anderson.', 'mc', [
        'Welcome to GrandSpeak Resort! May I have your passport and booking name, please?||Chào mừng đến GrandSpeak Resort! Xin phép cho tôi mượn hộ chiếu và tên đặt phòng ạ?',
        'Give me your passport fast.||(thiếu lịch sự) Đưa hộ chiếu đây nhanh lên.',
        'We have no rooms, go away.||(sai) Hết phòng rồi, đi chỗ khác đi.'
      ], 'front'],
      ['Here is my passport. Is breakfast included in my suite rate?||Hộ chiếu của tôi đây. Giá phòng Suite đã bao gồm bữa sáng chưa?', 'fill',
        'Certainly! Breakfast is {complimentary} from 6:30 to 10:30 a.m. at our Ocean Restaurant.||Dạ chắc chắn rồi! Bữa sáng được phục vụ miễn phí từ 6:30 đến 10:30 sáng tại Nhà hàng Ocean ạ.',
        ['expensive', 'cancelled', 'forbidden'], 'front'],
      ['Wonderful! Do I need to leave a deposit?||Tuyệt quá! Tôi có cần đặt cọc phát sinh không?', 'mc', [
        'May I take a credit card pre-authorization for incidental charges, please?||Xin phép quý khách cho tôi giữ hạn mức thẻ tín dụng cho các chi phí phát sinh nhé ạ?',
        'Pay cash only or no key.||(thiếu chuẩn 5★) Chỉ trả tiền mặt không thì khỏi nhận chìa.',
        'I forgot my calculator at home.||(lạc đề) Tôi để quên máy tính ở nhà rồi.'
      ], 'front'],
      ['Sure, here is my Visa card. Which floor is my suite on?||Được chứ, thẻ Visa của tôi đây. Phòng Suite của tôi ở tầng mấy?', 'fill',
        'Here is your {keycard}; your Ocean Suite 1208 is on the twelfth floor.||Đây là thẻ từ phòng của quý khách; phòng Ocean Suite 1208 nằm trên tầng 12 ạ.',
        ['pillow', 'umbrella', 'menu'], 'front']
    ]),
    sc('Khách đến sớm & Gửi hành lý', 'Early arrival & Luggage storage', [
      ['Hello, I arrived two hours early. Can I check in to my room now?||Xin chào, tôi đến sớm hai tiếng. Tôi nhận phòng ngay bây giờ được không?', 'mc', [
        'Welcome! Housekeeping is doing a final inspection; may I offer you a welcome drink in our lounge?||Chào mừng quý khách! Bộ phận Buồng phòng đang kiểm tra lần cuối; xin phép mời quý khách dùng nước chào mừng tại Lounge ạ?',
        'No, come back at two o’clock.||(cộc lốc) Không được, 2 giờ chiều quay lại.',
        'The hotel is closed in the morning.||(sai) Khách sạn đóng cửa buổi sáng.'
      ], 'front'],
      ['A welcome drink sounds lovely! Where can I leave my suitcases?||Nước chào mừng nghe tuyệt đấy! Tôi để vali ở đâu được nhỉ?', 'fill',
        'Our bellman will tag your {luggage} and deliver it straight to your room once ready.||Nhân viên hành lý sẽ gắn thẻ hành lý và chuyển thẳng lên phòng quý khách ngay khi sẵn sàng ạ.',
        ['passport', 'breakfast', 'balcony'], 'sofa'],
      ['Could you call me when the suite is ready?||Khi nào phòng xong bạn gọi báo tôi được không?', 'mc', [
        'Of course! I will personally notify you at the lounge within thirty minutes.||Dạ tất nhiên! Đích thân tôi sẽ ra thông báo cho quý khách tại khu Lounge trong vòng 30 phút ạ.',
        'You have to come and ask me every ten minutes.||(sai) Khách phải tự ra hỏi mỗi 10 phút.',
        'My phone has no battery.||(lạc đề) Điện thoại tôi hết pin rồi.'
      ], 'sofa']
    ]),
    sc('Trả phòng & Kiểm tra bảng kê Folio', 'Express check-out & Guest folio', [
      ['Good morning, I would like to check out of Suite 1208, please.||Chào buổi sáng, tôi muốn làm thủ tục trả phòng Suite 1208.', 'mc', [
        'Good morning! How was your stay with us? Here is your itemized guest folio for review.||Chào buổi sáng quý khách! Kỳ nghỉ của mình có tuyệt vời không ạ? Đây là bảng kê chi tiết để quý khách kiểm tra.',
        'Give me the key and pay quickly.||(thiếu lịch sự) Đưa chìa khoá và trả tiền lẹ đi.',
        'Checking in starts at 2 p.m.||(nhầm quy trình) Nhận phòng bắt đầu lúc 2 giờ chiều.'
      ], 'lounge'],
      ['Everything looks accurate. Can I settle the bill with the same card?||Mọi khoản đều chuẩn xác. Tôi thanh toán bằng chiếc thẻ hôm trước được không?', 'fill',
        'Certainly! Would you like a printed {receipt} or an email copy?||Dạ chắc chắn rồi! Quý khách muốn nhận hoá đơn in giấy hay bản gửi qua email ạ?',
        ['pillow', 'dessert', 'cabana'], 'lounge'],
      ['An email copy is fine. Could you also arrange a taxi to the airport?||Bản qua email là được rồi. Bạn gọi giúp tôi một chiếc taxi ra sân bay nhé?', 'mc', [
        'Right away! Our concierge has a car waiting at the main entrance for you.||Ngay lập tức ạ! Bộ phận Concierge đã có xe chờ sẵn tại sảnh chính cho quý khách.',
        'Walk to the street and wave your hand.||(thiếu chuẩn 5★) Tự ra đường vẫy tay bắt xe đi.',
        'The airport is very big.||(lạc đề) Sân bay rất to.'
      ], 'lounge']
    ])
  ], 'Thủ tục nhận phòng Suite', 'Checking in to an Ocean Suite');

  /* 2) VIP CONCIERGE & EXECUTIVE LOUNGE — spots: desk, tea, tour */
  registerPlace('GS_CONCIERGE', 'Les Clefs d’Or Lounge', 'desk', [
    sc('Thiết kế lịch trình du thuyền hoàng hôn', 'Curating a bespoke sunset cruise', [
      ['Excuse me, we are celebrating our anniversary tonight. What do you recommend?||Xin lỗi, tối nay vợ chồng tôi kỷ niệm ngày cưới. Bạn có gợi ý trải nghiệm nào đặc biệt không?', 'mc', [
        'Happy anniversary! May I recommend a private sunset yacht cruise followed by beachfront dining?||Chúc mừng kỷ niệm ngày cưới! Xin phép gợi ý chuyến du thuyền ngắm hoàng hôn riêng kèm bữa tối sát biển ạ?',
        'Just stay in your room and watch TV.||(thiếu tinh tế) Cứ ở trong phòng xem tivi thôi.',
        'I do not live in this city.||(thiếu chuyên nghiệp) Tôi không sống ở thành phố này.'
      ], 'desk'],
      ['That sounds unforgettable! What time does the cruise depart?||Nghe thật đáng nhớ! Mấy giờ du thuyền khởi hành vậy?', 'fill',
        'I have prepared a tailored {itinerary}; our chauffeur will escort you to the pier at 4:45 p.m.||Tôi đã chuẩn bị lịch trình riêng; tài xế sẽ đưa hai vị ra bến du thuyền lúc 16:45 ạ.',
        ['laundry', 'complaint', 'invoice'], 'desk'],
      ['Can we request a bouquet of white roses on board?||Chúng tôi đặt thêm một bó hồng trắng trên tàu được không?', 'mc', [
        'With pleasure! Our florist will arrange fresh white roses and chilled champagne on deck.||Rất hân hạnh ạ! Nghệ nhân hoa của resort sẽ chuẩn bị hồng trắng tươi và sâm-panh ướp lạnh trên boong tàu.',
        'Roses are too thorny to carry.||(từ chối thô) Hoa hồng nhiều gai lắm không mang đâu.',
        'I prefer yellow bananas.||(lạc đề) Tôi thích chuối vàng hơn.'
      ], 'tour']
    ]),
    sc('Đón tiếp đặc quyền tại Executive Lounge', 'Welcoming VIPs to the Executive Lounge', [
      ['Hello, does our Presidential Suite include access to the Executive Lounge?||Xin chào, hạng phòng Presidential Suite có bao gồm quyền vào Executive Lounge không?', 'mc', [
        'Welcome! Yes, you enjoy all-day refreshments, afternoon tea, and evening cocktails here.||Chào mừng quý khách! Dạ có, quý khách được tận hưởng đồ uống cả ngày, trà chiều và cocktail tối tại đây ạ.',
        'Only if you pay fifty dollars extra.||(sai chính sách VIP) Phải trả thêm 50 đô mới được vào.',
        'This is the staff canteen.||(sai) Đây là nhà ăn nhân viên.'
      ], 'tea'],
      ['Lovely! Are evening canapés served right now?||Tuyệt quá! Hiện giờ đang phục vụ món ăn nhẹ buổi tối chứ?', 'fill',
        'Yes! May I escort you to a window seat and pour a glass of {sparkling} wine?||Dạ vâng! Xin phép dẫn quý khách ra bàn cạnh cửa sổ và rót mời một ly vang sủi nhé ạ?',
        ['boiling', 'frozen', 'salty'], 'tea']
    ]),
    sc('Đặt xe Limousine tiễn sân bay VIP', 'Booking private airport chauffeur transfer', [
      ['Hi Concierge, my flight tomorrow is at 11:00 a.m. When should I leave the resort?||Chào Concierge, chuyến bay ngày mai của tôi lúc 11:00 sáng. Tôi nên rời resort lúc mấy giờ?', 'mc', [
        'For international flights, we recommend departing at 8:00 a.m. Shall I reserve our private limousine?||Với chuyến bay quốc tế, chúng tôi khuyên nên xuất phát lúc 8:00 sáng. Tôi đặt sẵn xe Limousine riêng cho ngài nhé?',
        'Leave whenever you wake up.||(thiếu trách nhiệm) Thức dậy lúc nào đi lúc đó.',
        'Airplanes fly very high.||(lạc đề) Máy bay bay rất cao.'
      ], 'desk'],
      ['Yes, please book the limousine for 8:00 a.m.||Vâng, đặt giúp tôi xe Limousine lúc 8:00 sáng nhé.', 'fill',
        'Confirmed! Your private {chauffeur} will be waiting at the main porte-cochere at 7:50 a.m.||Đã xác nhận! Tài xế riêng sẽ chờ sẵn tại sảnh đón chính từ 7:50 sáng ạ.',
        ['lifeguard', 'bartender', 'gardener'], 'desk']
    ])
  ], 'Thiết kế lịch trình du thuyền hoàng hôn', 'Curating a bespoke sunset cruise');

  /* 3) CỔNG ĐÓN XE SANG & HÀNH LÝ (BELL & VALET) — spots: limo, valet, shuttle */
  registerPlace('GS_BELL', 'Porte-Cochère & Valet 5★', 'limo', [
    sc('Đón khách VIP xuống xe & Nhận hành lý', 'VIP curbside arrival & Luggage tagging', [
      ['Good afternoon! We just arrived from the airport.||Chào buổi chiều! Chúng tôi vừa từ sân bay tới.', 'mc', [
        'Welcome to GrandSpeak Resort! Watch your head stepping out; allow me to assist with your luggage.||Chào mừng đến GrandSpeak Resort! Xin cẩn thận khi bước xuống xe; để tôi hỗ trợ hành lý cho quý khách ạ.',
        'Carry your own bags inside.||(sai) Tự xách túi vào trong đi.',
        'Why do you have so many suitcases?||(kém duyên) Sao mang nhiều vali thế?'
      ], 'limo'],
      ['Thank you! We have three large suitcases and a golf bag.||Cảm ơn nhé! Chúng tôi có ba vali lớn và một túi gậy golf.', 'fill',
        'Here is your luggage {claim} tag; we will deliver all four pieces straight to your villa.||Đây là phiếu nhận hành lý của quý khách; chúng tôi sẽ chuyển cả 4 kiện thẳng tới biệt thự ạ.',
        ['price', 'parking', 'recipe'], 'limo']
    ]),
    sc('Dịch vụ đỗ xe Valet Parking', 'Valet parking assistance', [
      ['Hi, can I leave my rental car with valet parking?||Xin chào, tôi gửi xe thuê qua dịch vụ đỗ xe Valet được không?', 'mc', [
        'Certainly, sir! Valet parking is complimentary for in-house guests. May I give you a valet ticket?||Dạ chắc chắn rồi thưa ngài! Đỗ xe Valet hoàn toàn miễn phí cho khách lưu trú. Xin gửi ngài thẻ xe Valet ạ.',
        'Park it on the sidewalk yourself.||(sai) Tự đỗ lên vỉa hè đi.',
        'I do not know how to drive.||(thiếu chuyên nghiệp) Tôi không biết lái xe.'
      ], 'valet'],
      ['How fast can I get my car back tomorrow morning?||Sáng mai gọi lấy xe thì mất bao lâu?', 'fill',
        'Simply call the Bell Desk ten minutes in {advance}, and your car will be cooled and waiting out front.||Quý khách chỉ cần báo Quầy Hành lý trước 10 phút, xe sẽ được bật mát sẵn ngay sảnh trước ạ.',
        ['reverse', 'kitchen', 'mistake'], 'valet']
    ]),
    sc('Hướng dẫn xe điện & Shuttle Bus nội khu', 'Resort buggy & Shuttle bus schedule', [
      ['Excuse me, how do we get to the Beach Club from here?||Xin lỗi, từ đây ra Câu lạc bộ Biển đi bằng cách nào?', 'mc', [
        'Our electric buggy can take you right now, or the resort shuttle departs every fifteen minutes.||Xe điện buggy có thể đưa quý khách đi ngay bây giờ, hoặc xe buýt nội khu khởi hành mỗi 15 phút ạ.',
        'It is five kilometers, just run there.||(thiếu lịch sự) Xa 5 cây số, tự chạy bộ ra đó đi.',
        'The ocean is salty.||(lạc đề) Nước biển mặn lắm.'
      ], 'shuttle'],
      ['Taking the electric buggy now would be great!||Đi xe điện ngay bây giờ thì tuyệt quá!', 'fill',
        'Right this way! Please fasten your {seatbelt} while we drive through the palm gardens.||Xin mời lối này! Quý khách vui lòng cài dây an toàn khi xe đi qua vườn cọ nhé ạ.',
        ['shoelace', 'necktie', 'napkin'], 'shuttle']
    ])
  ], 'Đón khách VIP xuống xe & Nhận hành lý', 'VIP curbside arrival & Luggage tagging');

  /* 4) NHÀ HÀNG FINE DINING 5★ — spots: host, table, cashier */
  registerPlace('GS_RESTAURANT', 'L’Océan Fine Dining 5★', 'host', [
    sc('Đón khách dẫn bàn & Trải khăn ăn', 'Greeting guests & Seating etiquette', [
      ['Good evening! A table for two under the name Laurent, please.||Chào buổi tối! Tôi đặt bàn hai người dưới tên Laurent.', 'mc', [
        'Good evening, Mr. Laurent! Your ocean-view table is ready. Right this way, please.||Chào buổi tối ngài Laurent! Bàn hướng biển của ngài đã sẵn sàng. Xin mời đi lối này ạ.',
        'Sit wherever you see an empty chair.||(thiếu chuẩn 5★) Thấy ghế nào trống thì tự ngồi đi.',
        'We only serve breakfast at night.||(sai) Buổi tối chúng tôi chỉ bán ăn sáng.'
      ], 'host'],
      ['Thank you, what a lovely view!||Cảm ơn, tầm nhìn đẹp quá!', 'fill',
        'Allow me to place your {napkin} on your lap, and here is our a la carte menu.||Xin phép được trải khăn ăn cho quý khách, và đây là thực đơn gọi món lẻ của nhà hàng ạ.',
        ['blanket', 'apron', 'carpet'], 'table'],
      ['Could we start with some water while looking at the menu?||Cho chúng tôi dùng nước trước trong lúc xem thực đơn nhé?', 'mc', [
        'Certainly! Would you prefer chilled still water or imported sparkling mineral water?||Dạ chắc chắn rồi! Quý khách muốn dùng nước suối mát không ga hay nước khoáng có ga nhập khẩu ạ?',
        'Tap water is in the washroom.||(thô lỗ) Nước máy ở trong nhà vệ sinh kìa.',
        'Water is too wet today.||(lạc đề) Hôm nay nước ướt quá.'
      ], 'table']
    ]),
    sc('Tư vấn độ chín Steak & Kiểm tra dị ứng', 'Taking steak orders & Allergen check', [
      ['We are ready to order. I would like the Australian Wagyu ribeye steak.||Chúng tôi sẵn sàng gọi món. Cho tôi phần thăn lưng bò Wagyu Úc.', 'mc', [
        'Excellent choice! How would you like your Wagyu ribeye cooked — medium-rare or medium?||Lựa chọn tuyệt hảo ạ! Quý khách muốn bò Wagyu nướng độ chín tái vừa (medium-rare) hay chín vừa (medium) ạ?',
        'We boil all our steaks in water.||(sai nghiệp vụ) Bít-tết nhà hàng luộc hết trong nước.',
        'Beef comes from chickens.||(sai) Thịt bò lấy từ con gà.'
      ], 'table'],
      ['Medium-rare, please. My wife is allergic to shellfish.||Cho tôi chín tái vừa nhé. Vợ tôi bị dị ứng động vật có vỏ (tôm cua sò).', 'fill',
        'Thank you for letting me know! I will alert our Executive Chef to prevent any {allergy} cross-contact.||Cảm ơn ngài đã báo trước! Tôi sẽ lưu ý đặc biệt với Bếp trưởng để ngăn tuyệt đối nhiễm chéo dị ứng ạ.',
        ['music', 'weather', 'luggage'], 'table'],
      ['What side dish pairs best with the pan-seared sea bass for her?||Món ăn kèm nào hợp nhất với cá chẽm áp chảo cho cô ấy nhỉ?', 'mc', [
        'Roasted asparagus and truffle mashed potatoes make a wonderful accompaniment, completely shellfish-free.||Măng tây nướng và khoai tây nghiền nấm truffle kết hợp rất tuyệt hảo và hoàn toàn không chứa hải sản có vỏ ạ.',
        'Shrimp paste soup is our only side.||(nguy hiểm dị ứng!) Canh mắm tôm là món kèm duy nhất.',
        'I never eat vegetables.||(thiếu chuyên nghiệp) Tôi chẳng bao giờ ăn rau.'
      ], 'table']
    ]),
    sc('Phục vụ Amuse-bouche & Thanh toán tại bàn', 'Serving chef’s compliments & Settling the bill', [
      ['Oh, we didn’t order this small dish. What is this?||Ồ, chúng tôi đâu có gọi món nhỏ này. Đây là món gì vậy?', 'mc', [
        'Please enjoy this amuse-bouche with our Executive Chef’s compliments to awaken your palate.||Xin mời quý khách thưởng thức món khai vị nhỏ do Bếp trưởng gửi tặng để đánh thức vị giác ạ.',
        'Oops, wrong table, give it back.||(thiếu chuyên nghiệp) Ôi nhầm bàn rồi, trả đây.',
        'You still have to pay double for it.||(sai) Món này vẫn tính tiền gấp đôi đấy.'
      ], 'table'],
      ['Everything was delicious! Could we charge the bill to Suite 1208?||Mọi món đều tuyệt ngon! Cho chúng tôi ký bill về phòng Suite 1208 được không?', 'fill',
        'Certainly! May I kindly ask for your room number and {signature} on the check, please?||Dạ chắc chắn rồi! Xin phép quý khách ghi số phòng và chữ ký xác nhận trên phiếu thanh toán ạ.',
        ['passport', 'luggage', 'pillow'], 'cashier']
    ])
  ], 'Đón khách dẫn bàn & Trải khăn ăn', 'Greeting guests & Seating etiquette');

  /* 5) SOMMELIER, ROOFTOP BAR & BARISTA — spots: bar, seat */
  registerPlace('GS_BAR', 'Skyline Bar & Sommelier 5★', 'bar', [
    sc('Tư vấn rượu vang kết hợp bò Wagyu', 'Wine pairing & Decanting service', [
      ['Hello Sommelier, which red wine pairs well with grilled Wagyu beef tonight?||Chào Sommelier, tối nay dòng vang đỏ nào kết hợp hợp nhất với bò Wagyu nướng?', 'mc', [
        'I highly recommend this vintage Bordeaux Cabernet; its velvety tannins balance the rich marbling beautifully.||Tôi đặc biệt gợi ý chai Bordeaux Cabernet lâu năm này; vị chát mượt mà cân bằng hoàn hảo với vân mỡ bò Wagyu ạ.',
        'Any cheap bottle tastes the same in the dark.||(sai) Chai rẻ nào uống trong tối chẳng giống nhau.',
        'Drink hot milk with steak instead.||(lạc đề) Ăn bít-tết uống sữa nóng đi.'
      ], 'bar'],
      ['Let’s go with that bottle! Does it need time to breathe?||Vậy lấy chai đó nhé! Rượu có cần thời gian thở không?', 'fill',
        'Yes, sir. Allow me to pour a tasting first and {decant} the wine in a crystal carafe for twenty minutes.||Dạ có thưa ngài. Xin phép rót một chút để ngài thử hương trước rồi gạn thở rượu trong bình pha lê 20 phút ạ.',
        ['freeze', 'boil', 'shake'], 'bar']
    ]),
    sc('Pha chế Signature Cocktail & Mocktail không cồn', 'Crafting bespoke cocktails & mocktails', [
      ['Hi Bartender! My friend doesn’t drink alcohol, and I love smoky whiskey cocktails.||Chào Bartender! Bạn tôi không uống cồn, còn tôi thích cocktail whiskey hương khói.', 'mc', [
        'Wonderful! I can craft a smoked Rosemary Old Fashioned for you, and a passion-fruit lemongrass mocktail for your friend.||Tuyệt vời ạ! Tôi xin pha ly Old Fashioned hương thảo xông khói cho quý khách, và ly mocktail chanh dây sả không cồn cho bạn mình nhé.',
        'People who don’t drink alcohol cannot sit at the bar.||(sai) Không uống rượu thì không được ngồi quầy bar.',
        'We only have warm tap water.||(sai) Quầy chỉ có nước lọc ấm thôi.'
      ], 'bar'],
      ['How do you garnish the Old Fashioned?||Bạn trang trí ly Old Fashioned như thế nào?', 'fill',
        'We finish it over crystal-clear ice on the rocks with a flamed orange peel {garnish}.||Chúng tôi phục vụ kèm viên đá pha lê trong suốt và trang trí bằng vỏ cam hơ lửa dậy hương tinh dầu ạ.',
        ['ketchup', 'lettuce', 'garlic'], 'seat']
    ]),
    sc('Nghệ thuật Cà phê Specialty & Latte Art', 'Barista specialty coffee & Dairy-free milk', [
      ['Good morning! Could I get a flat white, please? Do you have oat milk?||Chào buổi sáng! Cho tôi một ly Flat White nhé? Quầy mình có sữa yến mạch không?', 'mc', [
        'Good morning! Yes, we steam organic barista oat milk into silky microfoam for a naturally sweet flat white.||Chào buổi sáng quý khách! Dạ có, chúng tôi đánh mịn sữa yến mạch hữu cơ tạo lớp microfoam mượt mà, ngọt dịu tự nhiên ạ.',
        'Oat milk is for horses, not coffee.||(thô lỗ) Sữa yến mạch cho ngựa uống chứ ai pha cà phê.',
        'Our coffee machine is sleeping.||(thiếu chuyên nghiệp) Máy cà phê đang ngủ rồi.'
      ], 'bar'],
      ['Would a single or double espresso shot be better?||Nên pha một hay hai shot espresso thì ngon hơn nhỉ?', 'fill',
        'Our signature flat white uses a double ristretto {espresso} shot for rich aroma without bitterness.||Ly Flat White đặc trưng của chúng tôi dùng shot đôi ristretto espresso giúp dậy hương đậm đà mà không hề gắt đắng ạ.',
        ['vinegar', 'mustard', 'shampoo'], 'bar']
    ])
  ], 'Tư vấn rượu vang kết hợp bò Wagyu', 'Wine pairing & Decanting service');

  /* 6) BẾP NÓNG, QUẦY PASS & AN TOÀN HACCP — spots: pass, stove, prep */
  registerPlace('GS_KITCHEN', '5★ Culinary Brigade & Pass', 'pass', [
    sc('Kiểm tra Mise en place trước giờ mở ca tối', 'Pre-service Mise en place inspection', [
      ['Chef de Partie, dinner service starts in fifteen minutes. How is your station?||Tổ trưởng bếp, 15 phút nữa mở ca tối rồi. Quầy của bạn chuẩn bị tới đâu rồi?', 'mc', [
        'Yes, Chef! All sauces, garnishes, and portioned proteins are labeled and Mise en place is 100% complete.||Rõ thưa Bếp trưởng! Mọi loại xốt, rau trang trí và phần đạm chia sẵn đã dán nhãn ngày giờ, hoàn tất 100% Mise en place.',
        'I haven’t washed the pots from yesterday yet.||(vi phạm HACCP) Nồi từ hôm qua em còn chưa rửa.',
        'Let’s order pizza from outside.||(lạc đề) Mình đặt pizza ngoài tiệm ăn đi.'
      ], 'prep'],
      ['Good! Are all chiller temperatures logged on the HACCP sheet?||Tốt lắm! Nhiệt độ tủ mát đã ghi đầy đủ vào biểu mẫu HACCP chưa?', 'fill',
        'Yes, Chef! Walk-in chillers are steady at 3 degrees Celsius and logged on the {HACCP} chart.||Dạ rồi thưa Bếp trưởng! Tủ mát giữ ổn định ở 3 độ C và đã ký sổ theo dõi HACCP đầy đủ.',
        ['karaoke', 'cinema', 'parking'], 'prep']
    ]),
    sc('Xử lý Order VIP dị ứng đậu phộng nghiêm trọng', 'VIP severe peanut allergy ticket on the Pass', [
      ['Order fire Table 8 VIP! Sea bass and lamb rack — SEVERE PEANUT ALLERGY on the sea bass!||Vào lửa bàn 8 VIP! Cá chẽm và sườn cừu — KHÁCH DỊ ỨNG ĐẬU PHỘNG NẶNG ở món cá chẽm!', 'mc', [
        'Heard, Chef! Switching to sanitized purple allergen utensils, fresh pan, and pure olive oil immediately!||Nghe rõ thưa Bếp trưởng! Đổi ngay sang bộ dụng cụ tím chống dị ứng đã tiệt trùng, chảo mới và dầu ô-liu nguyên chất!',
        'Just wipe the peanut pan with a towel.||(cực kỳ nguy hiểm!) Lấy khăn lau sơ cái chảo dính đậu phộng là được.',
        'A little peanut oil won’t hurt anyone.||(vi phạm nghiêm trọng) Chút dầu phộng không sao đâu.'
      ], 'stove'],
      ['How long on the Hokkaido scallops and pan-seared sea bass?||Bao lâu nữa có sò điệp Hokkaido và cá chẽm áp chảo lên Pass?', 'fill',
        'Ninety seconds to crisp the skin, Chef! Preventing any allergen {cross-contact} on the plating pass!||90 giây nữa da cá giòn chuẩn thưa Bếp trưởng! Cách ly tuyệt đối không để nhiễm chéo dị ứng trên khay ra món!',
        ['decoration', 'discount', 'holiday'], 'pass']
    ]),
    sc('Kiểm tra nhiệt độ tâm thực phẩm & Trình bày đĩa nóng', 'Core temperature check & Hot-plate pass', [
      ['Hold Table 12! Did you probe the roasted duck breast and poultry core temperature?||Giữ bàn 12 lại! Đã đo nhiệt kế tâm cho phần gia cầm nướng chưa?', 'mc', [
        'Probed and verified, Chef! Internal core temperature reached 75 degrees Celsius — safe and juicy.||Đã đo kiểm chuẩn xác thưa Bếp trưởng! Nhiệt độ tâm đạt 75 độ C — an toàn chuẩn HACCP và giữ trọn độ mọng.',
        'I touched it with my finger, feels warm.||(vi phạm VSATTP) Em lấy ngón tay sờ thử thấy ấm ấm rồi.',
        'It is still frozen in the middle.||(sự cố sống món) Bên trong vẫn còn đông đá.'
      ], 'pass'],
      ['Wipe the rim clean and cover with heated silver cloches!||Lau sạch viền đĩa sứ và đậy nắp chụp bạc giữ nhiệt!', 'fill',
        'Rims polished spotless, Chef! Service, {table} twelve is hot and ready on the pass!||Viền đĩa đã lau sáng bóng thưa Bếp trưởng! Bộ phận bàn ơi, bàn số 12 nóng hổi sẵn sàng tại quầy Pass!',
        ['pillow', 'laundry', 'suitcase'], 'pass']
    ])
  ], 'Kiểm tra Mise en place trước giờ mở ca tối', 'Pre-service Mise en place inspection');

  /* 7) PHÒNG PRESIDENTIAL SUITE & QUẢN GIA BUTLER — spots: bed, bath, wardrobe */
  registerPlace('GS_SUITE', 'Presidential Suite & Butler', 'bed', [
    sc('Dịch vụ chỉnh trang phòng tối (Evening Turndown)', 'Evening turndown service & Pillow menu', [
      ['Come in! Oh, good evening — are you here for housekeeping?||Mời vào! Ồ chào buổi tối — bạn đến dọn phòng phải không?', 'mc', [
        'Good evening, madam! May I perform our evening turndown service and refresh your bath towels?||Chào buổi tối phu nhân! Xin phép thực hiện dịch vụ chỉnh trang giường tối và thay khăn tắm sạch mới cho phòng mình nhé ạ?',
        'Get out of the bed so I can sweep.||(thô lỗ) Bước xuống giường để tôi quét nhà nào.',
        'I came to watch your television.||(sai) Tôi vào xem nhờ tivi.'
      ], 'bed'],
      ['Yes, please! My neck feels a bit stiff after the long flight.||Vâng, làm ơn nhé! Cổ tôi hơi mỏi sau chuyến bay dài.', 'fill',
        'Would you like to select an orthopedic memory-foam or calming lavender pillow from our {pillow} menu?||Phu nhân có muốn chọn gối cao su non nâng đỡ cổ hoặc gối hương oải hương thư giãn từ thực đơn gối ngủ miễn phí không ạ?',
        ['breakfast', 'laundry', 'parking'], 'bed']
    ]),
    sc('Nhận trang phục Dạ tiệc Giặt khô & Là hơi tốc hành', 'Express dry cleaning & Garment pressing', [
      ['Butler, my silk dress and my husband’s tuxedo got wrinkled in the suitcase, and the gala is at 7 p.m.!||Quản gia ơi, váy lụa của tôi và bộ vest tuxedo của chồng tôi bị nhăn trong vali, mà 7 giờ tối dự tiệc Gala rồi!', 'mc', [
        'Please don’t worry, madam! Our express valet laundry will hand-press both garments and return them by 5:30 p.m.||Xin phu nhân hoàn toàn yên tâm! Bộ phận giặt là cao cấp sẽ là hơi thủ công cả hai bộ và hoàn trả tận phòng trước 17:30 ạ.',
        'Wash them in the sink with hand soap.||(sai) Đem ra bồn rửa tay giặt với xà bông đi.',
        'Silk shrinks, good luck!||(thiếu trách nhiệm) Lụa dễ co lắm, chúc may mắn nhé!'
      ], 'wardrobe'],
      ['Should I fill out the laundry form in the closet?||Tôi có cần điền phiếu giặt ủi trong tủ áo không?', 'fill',
        'I have noted delicate {dry} cleaning and steam pressing on the form for you; please sign right here.||Tôi đã ghi sẵn chế độ giặt khô cao cấp và là hơi nhẹ trên phiếu giúp phu nhân; xin ký xác nhận tại đây ạ.',
        ['wet', 'muddy', 'noisy'], 'wardrobe']
    ]),
    sc('Bổ sung tiện nghi phòng tắm thảo mộc & Chuẩn bị bồn ngâm', 'Replenishing bath amenities & Drawing a floral bath', [
      ['Excuse me, could we have extra bath amenities and bottled water?||Xin lỗi, cho chúng tôi xin thêm bộ đồ dùng phòng tắm và nước suối được không?', 'mc', [
        'Right away! I have brought extra botanical amenities, plush bathrobes, and four bottles of spring water.||Có ngay ạ! Tôi đã mang thêm bộ tiện nghi thảo mộc, áo choàng tắm bông mềm và 4 chai nước khoáng cho quý khách.',
        'One tiny soap bar must last five days.||(sai chuẩn 5★) Một cục xà bông nhỏ phải xài đủ 5 ngày.',
        'Buy shampoo at the supermarket outside.||(sai) Ra siêu thị ngoài phố mà mua dầu gội.'
      ], 'bath'],
      ['Could you also prepare the aromatherapy bath we booked?||Bạn chuẩn bị giúp bồn tắm tinh dầu mà chúng tôi đã đặt nhé?', 'fill',
        'Certainly! I am drawing a warm {bath} at 38 degrees with rose petals and lemongrass essential oil.||Dạ chắc chắn rồi! Tôi đang pha bồn ngâm ấm 38 độ C điểm cánh hoa hồng và tinh dầu sả chanh thư giãn ạ.',
        ['soup', 'coffee', 'fountain'], 'bath']
    ])
  ], 'Dịch vụ chỉnh trang phòng tối (Evening Turndown)', 'Evening turndown service & Pillow menu');

  /* 8) KHU SPA TRỊ LIỆU & HỒ BƠI VÔ CỰC — spots: spaDesk, treatment, cabana */
  registerPlace('GS_SPA', 'Serenity Spa & Infinity Pool', 'spaDesk', [
    sc('Đón khách tại Spa & Khảo sát sức khoẻ trước trị liệu', 'Spa consultation & Aromatherapy selection', [
      ['Hello, I have a 3:00 p.m. appointment for the 90-minute hot stone massage.||Xin chào, tôi có lịch hẹn lúc 3:00 chiều cho gói massage đá nóng 90 phút.', 'mc', [
        'Welcome to Serenity Spa! Please enjoy this warm ginger tea while we confirm any pressure preferences or health notes.||Chào mừng đến Serenity Spa! Mời quý khách thưởng thức trà gừng ấm trong lúc mình chọn lực ấn và lưu ý sức khoẻ ạ.',
        'Hurry up and lie down on the floor.||(sai) Nhanh lên nằm đại xuống sàn đi.',
        'Hot stones are literally boiling lava.||(hù khách) Đá nóng là nham thạch sôi đấy.'
      ], 'spaDesk'],
      ['I prefer medium pressure, especially around my shoulders.||Tôi thích lực ấn vừa phải, tập trung vùng vai gáy nhé.', 'fill',
        'Noted! Please arrive fifteen minutes early to enjoy our herbal steam room and {hydrotherapy} vitality pool.||Dạ đã ghi nhận! Mời quý khách trải nghiệm phòng xông thảo dược và hồ thuỷ trị liệu khoáng ấm trước giờ massage ạ.',
        ['motorcycle', 'elevator', 'parking'], 'treatment']
    ]),
    sc('Phục vụ Cabana riêng bên Hồ Bơi Vô Cực', 'Oceanfront Cabana & Poolside service', [
      ['Excuse me, are any shaded cabanas available by the infinity pool?||Xin lỗi, cạnh hồ bơi vô cực còn chòi nghỉ có mái che nào trống không?', 'mc', [
        'Good afternoon! Cabana Number 3 facing the ocean is ready with fresh chilled towels and sunblock.||Chào buổi chiều quý khách! Chòi nghỉ Cabana số 3 hướng biển đã sẵn sàng kèm khăn lạnh thơm và kem chống nắng ạ.',
        'All cabanas are for staff naps only.||(sai) Chòi nghỉ chỉ dành cho nhân viên ngủ trưa.',
        'The pool has no water today.||(sai) Hồ bơi hôm nay cạn nước rồi.'
      ], 'cabana'],
      ['Awesome! Can we order fresh coconut water here?||Tuyệt quá! Chúng tôi gọi nước dừa tươi ngay tại đây được không?', 'fill',
        'With pleasure! I will bring two chilled young coconuts and a complimentary fruit {platter} right over.||Rất hân hạnh ạ! Tôi sẽ mang hai trái dừa xiêm ướp lạnh cùng đĩa trái cây tươi mời quý khách ngay lập tức.',
        ['hammer', 'blanket', 'helmet'], 'cabana']
    ])
  ], 'Đón khách tại Spa & Khảo sát sức khoẻ trước trị liệu', 'Spa consultation & Aromatherapy selection');

  /* 9) BẾN DU THUYỀN RESORT & SUNSET CRUISE — spots: booth, gang, onbar, deck */
  registerPlace('GS_PIER', 'Grand Marina & Yacht 5★', 'booth', [
    sc('Đón khách tại Bến Du thuyền & Hỗ trợ lên tàu an toàn', 'Marina check-in & Safe yacht boarding', [
      ['Good afternoon! We booked the VIP Sunset Bay Cruise for two.||Chào buổi chiều! Chúng tôi có đặt vé Du thuyền Hoàng hôn VIP cho 2 người.', 'mc', [
        'Welcome aboard Grand Marina! Your boarding passes are confirmed; allow me to escort you to the yacht.||Chào mừng quý khách đến Bến Du thuyền Grand Marina! Thẻ lên tàu đã xác nhận; xin phép dẫn hai vị ra du thuyền ạ.',
        'Swim behind the boat to save money.||(lạc đề) Bơi theo sau tàu cho tiết kiệm tiền.',
        'The captain forgot the map.||(thiếu chuyên nghiệp) Thuyền trưởng quên bản đồ rồi.'
      ], 'booth'],
      ['The waves are gentle today! Where do we step aboard?||Hôm nay sóng êm quá! Chúng tôi bước lên tàu lối nào?', 'fill',
        'Please hold the handrail and watch your {step} as you cross the wooden gangway onto the main deck.||Xin quý khách vịn tay nắm và cẩn thận bước chân khi đi qua cầu ván gỗ lên boong chính ạ.',
        ['wallet', 'pillow', 'receipt'], 'gang']
    ]),
    sc('Phục vụ Sâm-panh & Thuyết minh Vịnh biển trên boong', 'Champagne service & Bay sightseeing on deck', [
      ['What a breathtaking view from the upper deck! What island is that ahead?||Khung cảnh từ boong trên đẹp ngoạn mục quá! Hòn đảo phía trước là đảo gì vậy?', 'mc', [
        'That is Emerald Coral Island, famous for limestone cliffs and golden sunsets over the bay.||Đó là Đảo San Hô Ngọc Lục Bảo, nổi tiếng với vách đá vôi kỳ vĩ và ánh hoàng hôn vàng rực trên vịnh ạ.',
        'I never look outside the boat.||(thiếu nhiệt tình) Tôi chẳng bao giờ nhìn ra ngoài tàu.',
        'That is an iceberg with penguins.||(sai thực tế) Đó là tảng băng trôi có chim cánh cụt.'
      ], 'deck'],
      ['Could we celebrate with two glasses of champagne at the deck bar?||Cho chúng tôi hai ly sâm-panh tại quầy bar trên boong để chúc mừng nhé?', 'fill',
        'Cheers to a magical evening! Here is your chilled French {champagne} and smoked salmon canapés.||Chúc mừng buổi tối tuyệt diệu! Đây là rượu Sâm-panh Pháp ướp lạnh và bánh canapé cá hồi xông khói của hai vị ạ.',
        ['vinegar', 'gasoline', 'detergent'], 'onbar']
    ])
  ], 'Đón khách tại Bến Du thuyền & Hỗ trợ lên tàu an toàn', 'Marina check-in & Safe yacht boarding');

  /* 10) KHÁN PHÒNG ĐẠI TIỆC GALA & HỘI NGHỊ MICE — spots: wdesk, bride, wwaiter, wguest */
  registerPlace('GS_BANQUET', 'Grand Ballroom & MICE 5★', 'wdesk', [
    sc('Đón nhà tổ chức Hội nghị MICE & Kiểm tra BEO', 'MICE event organizer walkthrough & AV check', [
      ['Good morning, Banquet Manager! Are the Ballroom and AV equipment ready for our 300 delegates?||Chào buổi sáng Quản lý Yến tiệc! Khán phòng và thiết bị âm thanh ánh sáng đã sẵn sàng cho 300 đại biểu chưa?', 'mc', [
        'Good morning! Everything is aligned with the Banquet Event Order; seating, LED wall, and translation headsets are tested.||Chào buổi sáng! Mọi hạng mục đã khớp 100% theo lệnh tiệc BEO; bàn ghế, màn hình LED và tai nghe dịch đều đã chạy thử chuẩn xác.',
        'We forgot there was a conference today.||(thảm hoạ vận hành) Chúng tôi quên mất hôm nay có hội nghị.',
        'Delegates can sit on the carpet.||(sai) Đại biểu ngồi tạm xuống thảm nhé.'
      ], 'wdesk'],
      ['Great! Did the technician test the wireless microphone at the keynote stage?||Tuyệt lắm! Kỹ thuật viên đã thử micro không dây trên sân khấu phát biểu chưa?', 'fill',
        'Yes! Both the lapel mic and the gooseneck microphone on the {podium} have crystal-clear sound and backup batteries.||Dạ rồi! Cả micro cài áo lẫn micro cổ ngỗng trên bục phát biểu đều cho âm thanh trong trẻo và lắp sẵn pin dự phòng ạ.',
        ['bathtub', 'treadmill', 'pillow'], 'bride']
    ]),
    sc('Phục vụ tiệc Gala VIP mở nắp chụp bạc đồng loạt & Coffee Break', 'Synchronized VIP Cloche service & Coffee break', [
      ['When our CEO finishes the toast, how will the main course be served to the VIP table?||Khi Tổng giám đốc nâng ly phát biểu xong, món chính tại bàn VIP sẽ được phục vụ thế nào?', 'mc', [
        'Twelve banquet servers will stand in position and lift the silver cloches in synchronized unison on cue.||Mười hai nhân viên yến tiệc sẽ đứng sẵn vị trí và mở nắp chụp bạc đồng loạt đúng một nhịp hiệu lệnh sang trọng nhất.',
        'We will stack ten plates on one arm and toss them down.||(sai chuẩn 5★) Tụi em chồng 10 đĩa lên tay rồi thả đại xuống.',
        'Guests serve themselves from a plastic bucket.||(sai) Khách tự múc từ xô nhựa.'
      ], 'wguest'],
      ['And where is the mid-morning coffee break set up?||Còn khu tiệc trà giải lao giữa giờ sáng được bố trí ở đâu?', 'fill',
        'Artisan pastries, fresh fruit, and espresso are ready in the foyer for your 10:15 a.m. {coffee} break.||Bánh ngọt thủ công, trái cây tươi và cà phê pha máy đã bày sẵn tại sảnh chờ cho giờ giải lao 10:15 sáng ạ.',
        ['midnight', 'laundry', 'swimming'], 'wwaiter']
    ])
  ], 'Đón nhà tổ chức Hội nghị MICE & Kiểm tra BEO', 'MICE event organizer walkthrough & AV check');

  /* 11) TRUNG TÂM XỬ LÝ SỰ CỐ DỊCH VỤ (L.A.S.T.) — spots: front, room, lounge */
  registerPlace('GS_RECOVERY', 'Service Recovery L.A.S.T.', 'front', [
    sc('Khách phàn nàn điều hoà hỏng giữa đêm (Quy trình L.A.S.T.)', 'Handling an air-conditioning breakdown with L.A.S.T.', [
      ['Excuse me! The air conditioner in Room 304 is blowing warm air and we cannot sleep!||Xin lỗi! Điều hoà phòng 304 chỉ thổi gió nóng khiến chúng tôi không tài nào ngủ được!', 'mc', [
        'I sincerely apologize for the inconvenience. Allow me to send our technician immediately.||Tôi chân thành xin lỗi quý khách vì sự bất tiện này. Xin phép cử kỹ thuật viên lên kiểm tra ngay lập tức ạ.',
        'Open the window and fan yourself with a magazine.||(đổ lỗi / thiếu chuyên nghiệp) Mở cửa sổ lấy tạp chí quạt tạm đi.',
        'It feels cool enough at my desk.||(tranh cãi với khách) Ngồi ở quầy tôi thấy mát mà.'
      ], 'room'],
      ['What if the technician cannot fix it quickly?||Lỡ kỹ thuật viên không sửa nhanh được thì sao?', 'fill',
        'Let me take personal {ownership}: if it isn’t resolved in ten minutes, I have a Deluxe Suite ready for your immediate move.||Xin để cá nhân tôi trực tiếp phụ trách: nếu sau 10 phút chưa khắc phục xong, tôi đã chuẩn bị sẵn phòng Deluxe Suite nâng hạng để chuyển ngay cho quý khách.',
        ['vacation', 'argument', 'silence'], 'room'],
      ['Thank you for acting so quickly and professionally.||Cảm ơn bạn đã xử lý rất nhanh chóng và chuyên nghiệp.', 'mc', [
        'Thank you for bringing this to our attention, and please enjoy breakfast tomorrow with our compliments.||Cảm ơn quý khách đã phản hồi để chúng tôi kịp thời khắc phục, và xin trân trọng gửi tặng bữa sáng ngày mai cho gia đình mình ạ.',
        'Do not complain again tonight.||(thô lỗ) Đêm nay đừng phàn nàn nữa nhé.',
        'Technicians are very sleepy.||(lạc đề) Thợ kỹ thuật buồn ngủ lắm.'
      ], 'lounge']
    ]),
    sc('Giải quyết sự cố đặt trùng phòng (Overbooking) & Sai phí Minibar', 'Resolving double-booking & Disputed minibar charge', [
      ['What do you mean our deluxe room is overbooked? I confirmed this three weeks ago!||Phòng Deluxe bị kín chỗ trùng đơn là sao? Tôi đã xác nhận đặt phòng từ 3 tuần trước rồi mà!', 'mc', [
        'Please accept my deepest apologies. To make this right, we have upgraded you to our Oceanfront Executive Suite at no extra charge.||Xin quý khách nhận lời xin lỗi sâu sắc nhất. Để đền bù xứng đáng, khách sạn xin nâng hạng miễn phí quý khách lên phòng Oceanfront Executive Suite cao cấp.',
        'System error, not my fault!||(đổ lỗi cho hệ thống) Lỗi máy tính chứ đâu phải lỗi của tôi!',
        'Try sleeping on the lobby sofa tonight.||(sai nghiêm trọng) Tối nay ngủ tạm ghế sofa ngoài sảnh đi.'
      ], 'front'],
      ['Also, during my last stay there was an incorrect minibar charge on my bill.||Nhân tiện, kỳ nghỉ lần trước hoá đơn của tôi từng bị tính nhầm một khoản phí Minibar.', 'fill',
        'I completely understand; I have noted VIP priority on your profile and waived any {minibar} deposit today.||Tôi hoàn toàn thấu hiểu ạ; tôi đã gắn thẻ ưu tiên VIP trên hồ sơ của ngài và miễn hoàn toàn khoản cọc Minibar hôm nay.',
        ['airplane', 'umbrella', 'stadium'], 'front']
    ])
  ], 'Khách phàn nàn điều hoà hỏng giữa đêm (Quy trình L.A.S.T.)', 'Handling an air-conditioning breakdown with L.A.S.T.');

  /* 12) PHỎNG VẤN TUYỂN DỤNG 5★ & HỌP GIAO BAN CA — spots: interview, meeting, boss */
  registerPlace('GS_INTERVIEW', '5★ Talent & Shift Briefing', 'interview', [
    sc('Phỏng vấn ứng viên Khách sạn Quốc tế 5 Sao', '5-Star Hospitality job interview', [
      ['Welcome! Tell me briefly about your hospitality experience and why you chose GrandSpeak Resort.||Chào mừng bạn! Hãy giới thiệu ngắn gọn kinh nghiệm ngành dịch vụ và lý do bạn chọn GrandSpeak Resort.', 'mc', [
        'Good morning! I have two years of five-star front office experience and a passion for creating memorable guest journeys.||Chào buổi sáng! Tôi có 2 năm kinh nghiệm Lễ tân 5 sao cùng niềm đam mê kiến tạo trải nghiệm đáng nhớ cho khách hàng.',
        'I just needed any job near my house.||(thiếu nhiệt huyết) Nhà gần đây nên xin đại thôi.',
        'I hate talking to strangers.||(trái ngược ngành dịch vụ) Tôi rất ghét nói chuyện với người lạ.'
      ], 'interview'],
      ['How do you stay calm when handling an upset guest during peak hours?||Bạn giữ bình tĩnh bằng cách nào khi xử lý khách đang bức xúc vào giờ cao điểm?', 'fill',
        'I practice empathetic listening, maintain warm eye contact, and apply the {L.A.S.T.} recovery framework.||Tôi lắng nghe bằng sự thấu cảm, giữ ánh mắt điềm tĩnh và áp dụng chuẩn quy trình khôi phục dịch vụ L.A.S.T. ạ.',
        ['R.U.D.E.', 'S.L.O.W.', 'L.O.U.D.'], 'interview']
    ]),
    sc('Họp giao ban đầu ca (Daily Shift Briefing) & VIP Arrivals', 'Daily shift briefing & VIP arrivals alignment', [
      ['Team, let’s align for the evening shift! What are our key VIP priorities tonight?||Cả đội chú ý họp giao ban ca tối nào! Đâu là các ưu tiên khách VIP trọng tâm tối nay?', 'mc', [
        'We have 94% occupancy, three VIP suites arriving at 6 p.m., and a severe shellfish allergy at Table 8.||Công suất phòng đạt 94%, có 3 đoàn khách VIP Suite đến lúc 18:00 và lưu ý dị ứng hải sản có vỏ ở Bàn số 8 ạ.',
        'Nothing matters, just wait until clock-out.||(thiếu tinh thần trách nhiệm) Chẳng có gì quan trọng, chờ hết giờ về thôi.',
        'Let’s hide in the storage room.||(sai) Mình trốn vào kho nghỉ đi.'
      ], 'meeting'],
      ['Excellent awareness! Let’s also do a quick uniform and grooming check.||Nắm thông tin rất chắc! Giờ chúng ta kiểm tra nhanh đồng phục và tác phong diện mạo nhé.', 'fill',
        'Name badges polished, pressed uniforms, neat hair, and a genuine five-star {smile} ready for every guest!||Bảng tên sáng bóng, đồng phục phẳng phiu, đầu tóc gọn gàng và nụ cười 5 sao chân thành sẵn sàng đón mọi vị khách!',
        ['frown', 'yawn', 'shrug'], 'boss']
    ])
  ], 'Phỏng vấn ứng viên Khách sạn Quốc tế 5 Sao', '5-Star Hospitality job interview');

  /* ── 7. CẤP ĐỘ 2 (TRUNG CẤP B1) & CẤP ĐỘ 3 (NÂNG CAO B2–C1) CHO TẤT CẢ 12 NƠI ── */
  window.PLACE_LEVELS = {};

  var LEVEL_SPECS = [
    ['lobby', ['front', 'sofa', 'lounge'],
      [
        ['Nâng hạng phòng hướng biển (Upselling)', 'Upselling to an Oceanfront Suite',
          'Good afternoon! Checking in for a Deluxe Garden Room.||Chào buổi chiều! Tôi nhận phòng hạng Deluxe Vườn.',
          'Welcome! For a small supplement, may I offer an upgrade to our panoramic Oceanfront Suite with Lounge access?||Chào mừng quý khách! Với khoản phụ thu ưu đãi nhỏ, xin phép gợi ý nâng hạng lên Oceanfront Suite toàn cảnh biển kèm đặc quyền Lounge ạ?',
          'Garden rooms have no windows at all.||(chê phòng sai cách) Phòng vườn tối om chẳng có cửa sổ đâu.',
          'What privileges come with the Oceanfront Suite?||Hạng Oceanfront Suite có thêm những đặc quyền gì?',
          'It includes private check-in, sunset cocktails, and complimentary late {check-out} until 2:00 p.m.||Hạng này bao gồm check-in riêng, cocktail hoàng hôn và trả phòng muộn miễn phí đến 14:00 chiều ạ.',
          ['parking', 'homework', 'traffic'],
          'That sounds fantastic! Let’s upgrade for all three nights.||Nghe hấp dẫn quá! Nâng hạng cho tôi cả 3 đêm luôn nhé.',
          'Wonderful choice! I have updated your reservation and prepared two suite keycards.||Lựa chọn tuyệt vời ạ! Tôi đã cập nhật đơn đặt phòng và chuẩn bị hai thẻ từ phòng Suite cho quý khách.',
          'Actually we sold that suite already.||(tiền hậu bất nhất) Thật ra phòng đó bán mất rồi.'],
        ['Đổi ngoại tệ & Tạm ứng chi phí phòng', 'Currency exchange & Credit limit inquiry',
          'Excuse me, can I exchange US dollars into Vietnamese Dong at the front desk?||Xin lỗi, tôi đổi đô-la Mỹ sang tiền Việt ngay tại quầy lễ tân được không?',
          'Certainly! Today’s official resort exchange rate is displayed on this screen; how much would you like to exchange?||Dạ chắc chắn rồi! Tỷ giá niêm yết hôm nay hiển thị ngay trên màn hình này; quý khách muốn đổi bao nhiêu ạ?',
          'Go find a black market on the street.||(vi phạm pháp luật & SOP) Tự ra chợ đen ngoài phố mà đổi.',
          'Two hundred dollars, please. Do I need my passport?||Đổi cho tôi 200 đô nhé. Có cần xuất trình hộ chiếu không?',
          'Yes, regulations require your passport number on the official exchange {voucher}.||Dạ có, theo quy định cần ghi số hộ chiếu lên biên lai đổi ngoại tệ chính thức ạ.',
          ['napkin', 'pillow', 'menu'],
          'Here you go. Could I have smaller denominations for tips and taxis?||Đây nhé. Cho tôi xin tiền mệnh giá nhỏ để tiện đi taxi nhé?',
          'Of course! I have arranged crisp notes in mixed denominations for your convenience.||Dạ tất nhiên! Tôi đã chuẩn bị các tờ tiền mới đủ mệnh giá nhỏ để quý khách tiện sử dụng ạ.',
          'Take coins in a heavy sack.||(sai) Cầm bao xu nặng này đi.']
      ],
      [
        ['Đón tiếp Khách Ngoại giao / VIP Khuyết danh (Incognito)', 'Discreet VIP & Incognito check-in protocol',
          'Good evening. My assistant requested strict privacy for my stay under an incognito profile.||Chào buổi tối. Trợ lý của tôi đã yêu cầu bảo mật danh tính tuyệt đối cho kỳ lưu trú này.',
          'Good evening! Your profile is flagged strictly confidential; let me escort you directly to your suite for in-room registration.||Chào buổi tối ngài! Hồ sơ của ngài đã bật chế độ bảo mật tuyệt đối; xin phép dẫn ngài lên thẳng phòng Suite để làm thủ tục riêng tư tại phòng.',
          'Hey everyone, look who just walked into our lobby!||(vi phạm bảo mật nghiêm trọng) Mọi người ơi nhìn xem ai vừa vào sảnh kìa!',
          'Will incoming phone calls or inquiries be screened?||Nếu có người bên ngoài gọi điện hỏi tên tôi thì khách sạn xử lý sao?',
          'Under our {discretion} protocol, no staff will confirm your presence without your prior authorization.||Theo quy chuẩn bảo mật danh tính, không nhân viên nào xác nhận sự hiện diện của ngài khi chưa có sự cho phép trước ạ.',
          ['gossip', 'loudspeaker', 'discount'],
          'Impeccable professionalism. Thank you.||Phong thái chuyên nghiệp hoàn hảo. Cảm ơn bạn.',
          'It is our privilege to ensure your complete peace of mind throughout your stay.||Đảm bảo sự an tâm trọn vẹn cho ngài suốt kỳ lưu trú là niềm vinh hạnh của chúng tôi ạ.',
          'Can I take a selfie with you first?||(cấm kỵ 5★) Cho em chụp kiểu ảnh tự sướng trước được không?']
      ]
    ],
    ['concierge', ['desk', 'tea', 'tour'],
      [
        ['Thu xếp bàn nhà hàng Michelin giờ chót & Yêu cầu y tế', 'Last-minute fine dining & Pharmacy assistance',
          'Concierge, every restaurant in town is fully booked tonight, and it’s my wife’s birthday!||Concierge ơi, tối nay mọi nhà hàng lớn đều kín bàn mà nay là sinh nhật vợ tôi!',
          'Leave it with me, sir! Through our Les Clefs d’Or network, I can secure a chef’s table or set up a private lantern beach dinner.||Xin hãy giao cho tôi thưa ngài! Qua mạng lưới Chìa Khoá Vàng, tôi có thể giữ bàn Chef’s Table hoặc dựng bàn tiệc đèn lồng riêng trên bãi biển.',
          'Buy instant noodles from the vending machine.||(thiếu tinh tế) Mua mì gói ở máy tự động ăn đỡ đi.',
          'A private lantern beach dinner sounds magical! Can the bakery write her name on a cake?||Tiệc tối đèn lồng trên biển nghe kỳ diệu quá! Bếp bánh viết tên cô ấy lên bánh kem kịp không?',
          'Absolutely! Our pastry chef will craft a {bespoke} berry mousse cake inscribed with “Happy Birthday”.||Hoàn toàn kịp ạ! Bếp trưởng bánh ngọt sẽ làm riêng chiếc bánh mousse dâu tươi đề dòng chữ chúc mừng sinh nhật phu nhân.',
          ['frozen', 'leftover', 'plastic'],
          'You just saved my evening!||Bạn vừa cứu nguy cả buổi tối của tôi đấy!',
          'Turning special moments into lifelong memories is what we love most!||Biến những khoảnh khắc đặc biệt thành kỷ niệm trọn đời chính là niềm vui lớn nhất của chúng tôi ạ!',
          'Remember to tip me a hundred dollars.||(cấm kỵ vòi tiền tip) Nhớ thưởng tôi 100 đô nhé.']
      ],
      [
        ['Điều phối trực thăng & Đổi lịch bay khẩn cấp khi bão về', 'Private charter rebooking during typhoon alert',
          'Concierge, the domestic flight was just cancelled due to tropical storm winds, and I chair a board summit tomorrow!||Concierge ơi, chuyến bay nội địa vừa huỷ do ảnh hưởng áp thấp, mà sáng mai tôi chủ trì hội đồng quản trị rồi!',
          'I have already monitored the aviation bulletin and placed a priority hold on two seats aboard the 6:00 p.m. express sleeper train and luxury MPV transfer.||Tôi đã theo dõi sát bản tin hàng không và giữ chỗ ưu tiên trên chuyến tàu tốc hành 18:00 kèm xe MPV hạng sang đưa đón tận ga cho ngài.',
          'Nothing we can do about the sky.||(thụ động) Trời mưa bão thì tụi em bó tay.',
          'Incredible foresight! What about my non-refundable airport hotel tonight?||Sự chủ động đáng kinh ngạc! Thế còn khách sạn gần sân bay không hoàn tiền tối nay của tôi thì sao?',
          'I contacted their Duty Manager directly and negotiated a full {waiver} of the cancellation fee due to force majeure.||Tôi đã liên hệ trực tiếp Quản lý trực ca bên đó và thương lượng miễn 100% phí huỷ phòng do điều kiện bất khả kháng thời tiết ạ.',
          ['penalty', 'double', 'argument'],
          'World-class concierge service indeed!||Đúng là đẳng cấp dịch vụ Concierge tầm cỡ thế giới!',
          'Safe travels, sir! Our chauffeur is standing by with umbrellas and a travel supper box.||Chúc ngài thượng lộ bình an! Tài xế riêng đã chờ sẵn cùng ô che mưa và hộp bữa tối mang theo chu đáo ạ.',
          'Don’t come back in rainy season.||(sai) Mùa mưa đừng tới nữa nhé.']
      ]
    ],
    ['bell', ['limo', 'valet', 'shuttle'],
      [
        ['Hỗ trợ khách khuyết tật xe lăn & Chuyển hành lý đoàn MICE', 'Wheelchair accessibility & Group luggage logistics',
          'Hello, my grandfather uses a wheelchair. Is there step-free access to the lobby?||Xin chào, ông tôi dùng xe lăn. Lối lên sảnh có đường dốc không bậc thang không?',
          'Welcome! Yes, our gentle marble ramp is right beside the entrance; allow me to steady the doors and escort your family.||Chào mừng gia đình mình! Dạ đường dốc đá thoai thoải nằm ngay cạnh sảnh chính; xin phép giữ cửa và hộ tống gia đình mình vào ạ.',
          'Carry the wheelchair up twenty stairs.||(nguy hiểm) Khiêng xe lăn leo 20 bậc thang đi.',
          'Can our suitcases be sanitized and sent straight to two connecting rooms?||Vali của gia đình có thể gửi thẳng lên hai phòng thông nhau được không?',
          'Certainly! I have marked rooms 402 and 404 on the {connecting} room tags for priority delivery.||Dạ chắc chắn rồi! Tôi đã đánh dấu rõ số phòng thông nhau 402 và 404 trên thẻ hành lý để chuyển lên ưu tiên ngay ạ.',
          ['missing', 'broken', 'random'],
          'Thank you for being so attentive to my grandfather.||Cảm ơn bạn đã chăm sóc ông tôi thật chu đáo.',
          'Our pleasure! Every area of our resort is step-free, and our buggy team is on call 24/7.||Rất hân hạnh ạ! Mọi khu vực trong resort đều có lối đi xe lăn thuận tiện và đội xe điện luôn trực 24/7.',
          'Wheelchairs scratch our marble floor.||(vô cảm) Xe lăn làm trầy sàn đá hết.']
      ],
      [
        ['Truy tìm hành lý thất lạc tại sân bay phối hợp hãng bay', 'Tracing delayed airline baggage with Lost & Found',
          'Bell Captain, the airline left my golf clubs in Singapore! My tournament tee-off is tomorrow morning!||Tổ trưởng Hành lý ơi, hãng bay bỏ quên bộ gậy golf của tôi ở Singapore rồi! Mà sáng mai tôi phát bóng giải đấu rồi!',
          'Please stay assured, sir! Give me your Property Irregularity Report number; I will liaise with Airport Baggage Tracing right now.||Xin ngài yên tâm! Cho tôi xin mã biên bản thất lạc PIR; tôi sẽ làm việc trực tiếp với bộ phận Hành lý sân bay ngay bây giờ.',
          'Play golf with a broomstick tomorrow.||(cợt nhả) Mai lấy cán chổi đánh golf tạm đi.',
          'Here is the PIR slip. The next flight from Singapore lands at 9:30 p.m. tonight.||Phiếu PIR đây. Chuyến bay kế tiếp từ Singapore hạ cánh lúc 21:30 tối nay.',
          'Once customs clears the bag, our resort {courier} will collect it at the terminal and place it in your suite before midnight.||Ngay khi hải quan thông quan kiện hàng, nhân viên giao nhận riêng của resort sẽ đón tại nhà ga và đặt tại phòng ngài trước nửa đêm ạ.',
          ['gardener', 'swimmer', 'singer'],
          'Meanwhile, can I rent a set for the practice range this afternoon?||Trong lúc chờ, chiều nay tôi mượn tạm một bộ tập ở sân tập được không?',
          'Already arranged! Our Pro Shop has reserved a complimentary right-handed Callaway set for your afternoon warm-up.||Đã thu xếp sẵn sàng ạ! Cửa hàng Pro Shop đã giữ miễn phí một bộ gậy Callaway thuận tay phải để ngài khởi động chiều nay.',
          'Golf is too tiring anyway.||(lạc đề) Đánh golf mệt lắm nghỉ đi.']
      ]
    ],
    ['restaurant', ['host', 'table', 'cashier'],
      [
        ['Giới thiệu Thực đơn Thưởng thức 7 món (Degustation Menu)', 'Presenting the 7-course Chef’s Degustation Menu',
          'Good evening! Could you tell us the difference between a la carte and the Chef’s Tasting Menu?||Chào buổi tối! Bạn giải thích giúp sự khác biệt giữa gọi món lẻ và Thực đơn Thưởng thức của Bếp trưởng nhé?',
          'Our seven-course degustation menu takes you on a coastal culinary journey, featuring local lobster, Hokkaido scallops, and Wagyu.||Thực đơn thưởng thức 7 món đưa quý khách qua hành trình ẩm thực miền biển tinh tuyển với tôm hùm bản địa, sò điệp Hokkaido và bò Wagyu ạ.',
          'Tasting menu means tiny crumbs on huge plates.||(mô tả kém sang) Thực đơn thưởng thức toàn miếng bé tí trên đĩa to đùng.',
          'Can we add wine pairing, and is there a palate cleanser before the main course?||Chúng tôi chọn thêm gói rượu vang đi kèm được chứ, và trước món chính có món thanh lọc vị giác không?',
          'Yes! Between seafood and beef, we serve a chilled passion-fruit sorbet as a refreshing {palate} cleanser.||Dạ có ạ! Giữa món hải sản và thịt đỏ, nhà hàng phục vụ kem tuyết chanh dây mát lạnh giúp thanh lọc vị giác tinh tế.',
          ['window', 'carpet', 'table'],
          'Sounds exquisite! Two degustation menus with sommelier wine pairing, please.||Nghe tuyệt mỹ quá! Cho chúng tôi 2 suất thực đơn thưởng thức kèm gói rượu vang Sommelier nhé.',
          'Thank you! Allow me to adjust your silverware for the first seafood course.||Xin cảm ơn quý khách! Xin phép được bố trí lại bộ dao nĩa bạc phù hợp cho món hải sản mở màn ạ.',
          'Keep the same dirty fork for all seven courses.||(sai chuẩn Fine Dining) Dùng chung 1 cái nĩa cho cả 7 món nhé.']
      ],
      [
        ['Xử lý tinh tế khi khách chê độ chín Steak & Tách hoá đơn nhóm', 'Graceful steak refire & Seamless split-check handling',
          'Excuse me, I ordered my tenderloin medium-rare, but this center looks closer to medium-well.||Xin lỗi, tôi gọi thăn nội bò chín tái vừa (medium-rare), nhưng phần tâm miếng thịt này chín kỹ gần medium-well rồi.',
          'Please accept my sincere apologies, sir! Allow me to whisk this away and have our chef fire a fresh medium-rare cut on priority.||Xin ngài thứ lỗi chân thành! Để tôi thu đĩa ngay và báo Bếp trưởng nướng ưu tiên một phần thăn nội mới chuẩn độ chín tái vừa cho ngài.',
          'The kitchen light is dim, eat it anyway.||(tranh cãi với khách) Đèn bếp mờ nhìn vậy thôi cứ ăn đi.',
          'My wife’s sea bass is already on the table — I don’t want hers to get cold while waiting.||Món cá chẽm của vợ tôi đã lên bàn rồi — tôi không muốn món của cô ấy bị nguội trong lúc chờ.',
          'If madam prefers, we can keep her dish warm or plate a fresh hot {entree} together with your steak in four minutes.||Nếu phu nhân đồng ý, bếp sẽ giữ ấm hoặc lên mới phần món chính nóng hổi cùng một nhịp với bít-tết của ngài trong 4 phút tới ạ.',
          ['napkin', 'invoice', 'umbrella'],
          'Impressive! Also, at the end could we split the bill evenly between two cards?||Rất ấn tượng! Cuối bữa bạn chia đôi hoá đơn thanh toán qua hai thẻ giúp nhé?',
          'Certainly, sir! The replacement steak is on the house, and I will prepare two split folios at your convenience.||Dạ chắc chắn rồi thưa ngài! Nhà hàng xin miễn phí phần steak thay mới, và tôi sẽ tách sẵn hai biên lai thanh toán thuận tiện nhất cho ngài.',
          'Splitting bills is too much math for me.||(thiếu chuyên nghiệp) Chia bill tính toán đau đầu lắm không làm đâu.']
      ]
    ],
    ['bar', ['bar', 'seat', 'bar'],
      [
        ['Kiểm tra nút bần & Quy trình phục vụ Rượu vang Cổ điển', 'Vintage wine presentation & Cork inspection ritual',
          ['Sommelier, we ordered the 2016 Margaux. Could we inspect the bottle first?||Sommelier ơi, chúng tôi gọi chai Margaux niên vụ 2016. Cho chúng tôi kiểm tra nhãn chai trước nhé?'][0],
          'Certainly! Allow me to present the label: Château Margaux 2016, stored at 13 degrees in our cellar.||Dạ chắc chắn rồi! Xin phép trình nhãn chai: Château Margaux niên vụ 2016, bảo quản chuẩn 13 độ C tại hầm rượu của nhà hàng.',
          'I already opened it in the kitchen!||(sai chuẩn Sommelier) Em khui sẵn dưới bếp mất rồi!',
          'Please go ahead and open it.||Mời bạn mở rượu nhé.',
          'Here is the cork, and may I pour a small tasting so you can evaluate the wine’s {bouquet}?||Đây là nút bần để ngài kiểm tra, và xin phép rót một lượng nhỏ để ngài thẩm định tầng hương rượu ạ.',
          ['receipt', 'iceberg', 'caffeine'],
          'Rich blackberry and cedar notes — please pour for the table!||Hương quả mâm xôi chín và gỗ tuyết tùng rất sâu — mời rót cho cả bàn nhé!',
          'Wonderful! I will serve the ladies first, moving clockwise, and finish with you as the host.||Tuyệt vời ạ! Tôi xin phép rót phục vụ các quý bà trước theo chiều kim đồng hồ và kết thúc tại ly của ngài chủ tiệc.',
          'Fill every wine glass to the very brim!||(sai kỹ thuật rót vang) Rót tràn đầy tới miệng ly luôn nhé!']
      ],
      [
        ['Gợi ý Rượu tiêu thực Digestif & Phục vụ có trách nhiệm', 'Post-dinner Digestif & Responsible beverage service',
          'That dinner was phenomenal! What digestif would round off a dark chocolate dessert?||Bữa tối thật xuất sắc! Loại rượu tiêu thực (digestif) nào hợp nhất để khép lại món tráng miệng sô-cô-la đắng?',
          'An aged XO Cognac or a tawny Port pairs sublimely with dark chocolate’s bittersweet finish.||Một ly Cognac XO ủ lâu năm hoặc rượu vang cường hoá Tawny Port kết hợp cực kỳ thăng hoa với hậu vị đắng ngọt của sô-cô-la đen ạ.',
          'Drink three energy drinks before bed.||(lạc đề) Uống 3 lon bò húc trước khi ngủ đi.',
          'One XO Cognac in a snifter glass, and sparkling water for my friend driving tonight.||Cho tôi một ly XO Cognac trong ly bầu snifter, và nước khoáng có ga cho người bạn cầm lái tối nay.',
          'Right away! For your comfort, we also offer complimentary chauffeur {valet} if anyone prefers not to drive.||Có ngay ạ! Để an toàn trọn vẹn, khách sạn luôn sẵn sàng hỗ trợ tài xế đưa về miễn phí nếu quý khách không muốn tự cầm lái.',
          ['karaoke', 'laundry', 'barbell'],
          'Very thoughtful hospitality!||Sự chu đáo thật đáng trân trọng!',
          'Your safety and enjoyment are always our highest priority!||Sự an toàn và trải nghiệm trọn vẹn của quý khách luôn là ưu tiên cao nhất của chúng tôi ạ!',
          'Last call was two hours ago, leave now.||(đuổi khách) Hết giờ gọi đồ từ 2 tiếng trước rồi, về đi.']
      ]
    ],
    ['kitchen', ['prep', 'stove', 'pass'],
      [
        ['Kiểm soát FIFO, Nhãn ngày giờ & Hầm nước dùng Pháp', 'FIFO stock rotation & Clarified butter emulsion',
          'Sous Chef, the health auditor is checking our cold room and sauce station in ten minutes!||Bếp phó ơi, 10 phút nữa thanh tra VSATTP kiểm tra kho lạnh và quầy xốt của mình đấy!',
          'All containers follow strict FIFO rotation with clear prep-date and expiry labels, Chef!||Tất cả khay chứa đều tuân thủ nghiêm ngặt nguyên tắc Nhập trước – Xuất trước (FIFO) kèm tem ngày sơ chế và hạn dùng rõ ràng thưa Bếp trưởng!',
          'Hide the expired cream behind the lettuce.||(vi phạm nghiêm trọng) Giấu hộp kem hết hạn ra sau rổ xà lách đi.',
          'Careful with the Hollandaise on low heat — don’t let the eggs scramble!||Chú ý nồi xốt Hollandaise lửa nhỏ — đừng để lòng đỏ trứng bị vón cục tách dầu nhé!',
          'Whisking steadily at 62 degrees to keep a silky butter {emulsion}, Chef!||Đang đánh đều tay ở 62 độ C để giữ kết cấu nhũ tương bơ mịn mượt hoàn hảo thưa Bếp trưởng!',
          ['explosion', 'skeleton', 'laundry'],
          'Spotless stainless steel and textbook sauce consistency. Keep it up!||Mặt bàn inox sáng bóng và độ sánh xốt chuẩn sách giáo khoa. Phát huy nhé!',
          'Thank you, Chef! Ready for first seating orders!||Cảm ơn Bếp trưởng! Đã sẵn sàng đón loạt order ca đầu!',
          'I dropped the ladle on the floor and put it back.||(vi phạm HACCP) Em làm rơi muôi xuống đất rồi bỏ vô nồi lại.']
      ],
      [
        ['Điều phối Bếp cao điểm 200 khách Gala & Xử lý thiếu hụt nguyên liệu 86', 'Peak Gala expediting & 86 menu substitution',
          'Brigade listen up! Sea urchin just went 86 — only two portions left while VIP Table 1 orders four!||Toàn bếp chú ý! Nhum biển vừa chạm ngưỡng hết hàng (86) — chỉ còn 2 phần mà bàn VIP số 1 gọi 4 phần!',
          'Chef, I immediately alerted Front-of-House on the 86 count and prepped Oscietra caviar tartlets as an upgraded VIP substitute!||Thưa Bếp trưởng, tôi đã báo ngay bộ phận Bàn khoá món 86 và chuẩn bị bánh tart trứng cá tầm Oscietra nâng cấp thay thế cho bàn VIP!',
          'Stretch two portions with water so nobody notices.||(gian dối chất lượng) Pha thêm nước chia làm 4 đĩa khách không biết đâu.',
          'Smart thinking! Now synchronize twenty Wagyu plates for Ballroom Table A — timing is everything!||Xử lý nhạy bén lắm! Giờ đồng bộ 20 đĩa Wagyu cho Bàn A Đại tiệc — canh chuẩn từng giây nhé!',
          'Proteins rested five minutes, jus glossy, micro-herbs placed — {service} up in thirty seconds, Chef!||Thịt đã nghỉ đủ 5 phút giữ nước ngọt, xốt vang bóng mượt, rau mầm điểm xong — ra món sau 30 giây thưa Bếp trưởng!',
          ['garbage', 'bedtime', 'suitcase'],
          'Flawless execution under pressure, team!||Bản lĩnh điều phối dưới áp lực hoàn hảo lắm cả đội!',
          'Yes, Chef! Sanitizing all cutting boards before dessert plating!||Rõ thưa Bếp trưởng! Tổng vệ sinh khử khuẩn toàn bộ mặt thớt trước khi chuyển sang khâu tráng miệng!',
          'Leave the dirty pans for morning shift.||(đùn đẩy ca sau) Để chảo bẩn cho ca sáng mai rửa.']
      ]
    ],
    ['suite', ['bed', 'wardrobe', 'bath'],
      [
        ['Sắp xếp hành lý Unpacking & Chuẩn bị trang phục công tác', 'Bespoke butler unpacking & Shoe-shine service',
          'Good afternoon, Butler. I have back-to-back meetings and barely time to unpack my suitcase.||Chào buổi chiều Quản gia. Tôi có lịch họp nối tiếp nhau nên chưa kịp dỡ vali hành lý.',
          'Allow me to assist, sir! With your permission, I can hang your suits on cedar hangers and organize your shirts neatly.||Xin phép để tôi hỗ trợ thưa ngài! Nếu ngài đồng ý, tôi xin treo vest lên móc gỗ tuyết tùng và xếp sơ mi ngay ngắn vào tủ.',
          'Dump everything onto the sofa!||(sai) Đổ hết quần áo ra ghế sofa là xong!',
          'My leather Oxford shoes got scuffed in transit as well.||Đôi giày da Oxford của tôi cũng bị xước mờ lúc di chuyển.',
          'Please place them in the butler box; our complimentary shoe-shine service will polish them to a mirror {finish} before 7:00 a.m.||Xin ngài đặt vào ngăn hộp Butler; dịch vụ đánh giày miễn phí sẽ đánh bóng sáng như gương và trả trước 7:00 sáng mai ạ.',
          ['scratch', 'puddle', 'omelette'],
          'What a lifesaver! Could you also set a gentle wake-up call at 6:30 a.m.?||Cứu tinh đây rồi! Bạn đặt giúp cuộc gọi báo thức nhẹ nhàng lúc 6:30 sáng nhé?',
          'Scheduled for 6:30 a.m. accompanied by freshly brewed Arabica coffee at your door, sir.||Đã hẹn chuẩn 6:30 sáng kèm bình cà phê Arabica mới pha phục vụ tận cửa phòng thưa ngài.',
          'Set your own phone alarm!||(thiếu chuẩn Butler) Tự lấy điện thoại mà cài báo thức!']
      ],
      [
        ['Xử lý khách để quên đồng hồ xa xỉ sau khi trả phòng (Lost & Found)', 'Securing a high-value forgotten timepiece (Lost & Found)',
          'Housekeeping Supervisor! The guest from Suite 1208 just called from the airport — he left a Swiss watch in the bedside safe!||Giám sát Buồng phòng ơi! Khách phòng Suite 1208 vừa gọi từ sân bay báo để quên đồng hồ Thuỵ Sĩ trong két sắt đầu giường!',
          'I am entering Suite 1208 right now with Security as a dual witness to inspect the safe under camera protocol.||Tôi đang vào phòng 1208 cùng nhân viên An ninh làm người chứng kiến kép để mở kiểm tra két sắt đúng quy trình minh bạch.',
          'Put the watch in my pocket first.||(vi phạm quy trình an ninh) Cứ bỏ tạm đồng hồ vô túi quần mình trước đã.',
          'Did you locate the watch inside the safe?||Hai bộ phận đã tìm thấy chiếc đồng hồ trong két chưa?',
          'Located and sealed in a tamper-proof {Lost} and Found pouch! Dispatching our express courier to Terminal 2 Gate 6 immediately!||Đã tìm thấy và niêm phong trong túi bảo mật Đồ thất lạc! Đang điều xe tốc hành giao tận Cổng số 6 Nhà ga T2 trước giờ khách lên máy bay!',
          ['Trash', 'Kitchen', 'Secret'],
          'The guest just confirmed receipt before boarding and praised our integrity!||Khách vừa xác nhận đã nhận lại đồng hồ kịp trước khi lên máy bay và hết lời khen sự trung thực của khách sạn!',
          'Integrity and dual-witness logging protect both our guests and our five-star reputation!||Sự liêm chính và biên bản đồng kiểm hai bộ phận luôn bảo vệ trọn vẹn tài sản khách hàng và uy tín 5 sao!',
          'Ask him for a reward fee!||(cấm kỵ) Đòi khách tiền chuộc đồng hồ đi!']
      ]
    ],
    ['spa', ['spaDesk', 'treatment', 'cabana'],
      [
        ['Điều chỉnh liệu trình an toàn cho khách mang thai & Da nhạy cảm', 'Adapting spa therapy for prenatal & sensitive skin',
          'Hello, I booked an essential oil massage, and I wanted to mention I am five months pregnant.||Xin chào, tôi có đặt massage tinh dầu, và tôi muốn báo trước là mình đang mang thai tháng thứ năm.',
          'Congratulations, madam! For your safety, we recommend our gentle prenatal cushion massage using unscented organic almond oil.||Xin chúc mừng phu nhân! Để an toàn tuyệt đối, chúng tôi xin chuyển sang bài massage bầu êm dịu cùng gối nâng chuyên dụng và dầu hạnh nhân hữu cơ không mùi.',
          'Strong rosemary oil and hot sauna are fine.||(chống chỉ định nguy hiểm) Xông hơi thật nóng với tinh dầu đậm đặc vẫn được.',
          'Is the heated sauna safe for me beforehand?||Vậy trước đó tôi có nên vào phòng xông hơi nóng không?',
          'We advise avoiding high-heat saunas; instead, enjoy a soothing lukewarm foot {ritual} with chamomile flowers.||Chúng tôi khuyên tránh nhiệt độ cao ở phòng xông; thay vào đó mời phu nhân ngâm chân nước ấm dịu với hoa cúc La Mã thư thái ạ.',
          ['marathon', 'sunburn', 'iceberg'],
          'Thank you for knowing the exact prenatal safety guidelines!||Cảm ơn bạn vì nắm rất vững quy chuẩn an toàn cho mẹ bầu!',
          'Your well-being is always our top priority at Serenity Spa!||Sức khoẻ và sự an tâm của quý khách luôn là ưu tiên hàng đầu tại Serenity Spa ạ!',
          'Sign here saying it is not our fault.||(lạnh lùng) Ký giấy miễn trừ trách nhiệm này đi.']
      ],
      [
        ['Chăm sóc phục hồi cháy nắng & Thiết kế gói Wellness Retreat 3 ngày', 'Sunburn soothing care & Bespoke 3-day wellness program',
          'Spa Director, I fell asleep on the beach and my shoulders are badly sunburned! Can I still have a scrub?||Giám đốc Spa ơi, tôi ngủ quên ngoài biển nên hai vai bị cháy nắng đỏ rát! Tôi có tẩy tế bào chết được không?',
          'We should postpone exfoliation to protect your skin; instead, let’s apply a cooling chilled aloe vera and cucumber wrap.||Chúng ta nên tạm hoãn tẩy tế bào chết để bảo vệ da; thay vào đó Spa xin đắp mặt nạ lô hội tươi ướp lạnh và dưa leo làm dịu vết bỏng nắng ngay ạ.',
          'Salt scrub will rub the red skin right off!||(gây tổn thương da!) Tẩy muối biển chà mạnh cho bay lớp da đỏ đi!',
          'That cooling wrap feels heavenly! Could we customize my remaining two days into a gentle wellness plan?||Lớp ủ mát dịu dễ chịu quá! Hai ngày còn lại bạn thiết kế giúp tôi lịch trình dưỡng sinh nhẹ nhàng được không?',
          'With pleasure! Sunrise breathwork, herbal {hydration} facials, and evening sound-bowl meditation are tailored for you.||Rất hân hạnh ạ! Thiền thở đón bình minh, chăm sóc da cấp ẩm thảo mộc và trị liệu chuông xoay buổi tối đã được thiết kế riêng cho quý khách.',
          ['sunburn', 'frying', 'shouting'],
          'Truly restorative five-star care!||Sự chăm sóc phục hồi đúng chuẩn 5 sao đích thực!',
          'We will also send chilled aloe mist to your suite for tonight!||Chúng tôi cũng xin gửi tặng thêm bình xịt khoáng lô hội mát lạnh lên phòng Suite cho quý khách tối nay ạ!',
          'Stay indoors forever next time.||(kém duyên) Lần sau ở lì trong phòng đừng ra nắng nữa.']
      ]
    ],
    ['pier', ['booth', 'gang', 'deck'],
      [
        ['Điều chỉnh hải trình êm sóng cho khách say sóng', 'Calming seasickness & Sheltered bay routing',
          'Excuse me, Crew! My daughter is feeling a bit dizzy from the ocean swell.||Xin lỗi Thuyền viên! Con gái tôi hơi chóng mặt vì sóng biển lắc lư.',
          'Please have a seat in the fresh breeze at mid-ship, where motion is minimal; here is iced ginger tea and acupressure wristbands.||Mời hai mẹ con ngồi khu thoáng gió giữa thân tàu nơi ít chao lắc nhất; đây là trà gừng mát và vòng bấm huyệt chống say sóng ạ.',
          'Look down at your phone in the dark cabin!||(làm say sóng nặng hơn) Xuống khoang tối cúi đầu nhìn điện thoại đi!',
          'Will the water get rougher ahead?||Đoạn phía trước sóng có to hơn không bạn?',
          'Our captain is steering into the sheltered {lagoon} behind Pearl Island, where the water is calm like glass.||Thuyền trưởng đang chuyển hướng vào đầm vịnh kín gió sau Đảo Ngọc, nơi mặt nước phẳng lặng như gương ạ.',
          ['typhoon', 'waterfall', 'highway'],
          'She feels much better already! Thank you for taking such good care of her.||Cháu đỡ hẳn rồi! Cảm ơn thuỷ thủ đoàn đã chăm sóc cháu tận tình quá.',
          'We are so glad! Look to the port side — dolphins often swim beside us in this lagoon!||Mừng quá ạ! Mời gia đình nhìn sang mạn trái — cá heo thường bơi dọc mạn thuyền trong vịnh êm này đấy ạ!',
          'Jump into the water to cool off.||(nguy hiểm) Nhảy đại xuống biển cho tỉnh táo.']
      ],
      [
        ['Tổ chức Cầu hôn bất ngờ trên Du thuyền lúc Hoàng hôn', 'Orchestrating a surprise sunset proposal on deck',
          'Cruise Director, *whispering* I have the ring in my pocket! What is our cue at sunset?||Quản lý Du thuyền ơi, *nói nhỏ* tôi để nhẫn trong túi áo rồi! Đâu là tín hiệu phối hợp lúc hoàng hôn?',
          '*Quietly* In five minutes we anchor at Golden Cape; when the violinist begins her favorite song, the bow deck is exclusively yours.||*Khẽ đáp* 5 phút nữa tàu thả neo tại Mũi Vàng; ngay khi nghệ sĩ violin dạo bản nhạc cô ấy yêu thích, mũi tàu sẽ dành riêng trọn vẹn cho hai vị.',
          '*Shouting* HEY LADY, HE HAS A RING IN HIS POCKET!||(phá hỏng bí mật!) NÀY CÔ GÁI ƠI ANH ẤY GIẤU NHẪN TRONG TÚI KÌA!',
          'And someone can discreetly capture photos of the moment?||Và có người chụp lại khoảnh khắc đó một cách tự nhiên chứ?',
          'Our photographer is positioned on the upper bridge with a telephoto lens to capture every {candid} emotion unobtrusively.||Nhiếp ảnh gia của tàu đã đứng sẵn trên đài chỉ huy với ống kính tele để bắt trọn từng khoảnh khắc cảm xúc tự nhiên nhất ạ.',
          ['blurry', 'accidental', 'noisy'],
          'She said YES! Thank you to the entire crew!||Cô ấy đồng ý rồi!! Cảm ơn toàn thể thuỷ thủ đoàn nhé!',
          'Warmest congratulations on your engagement! Vintage champagne and strawberries are ready to celebrate!||Nồng nhiệt chúc mừng lễ đính hôn của hai vị! Sâm-panh cổ điển và dâu tây tươi đã sẵn sàng để chúc mừng ạ!',
          'Time is up, pay overtime dock fees!||(phá bầu không khí) Hết giờ rồi trả thêm phí neo tàu đi!']
      ]
    ],
    ['banquet', ['wdesk', 'bride', 'wguest'],
      [
        ['Xử lý phát sinh tăng thêm 20 khách VIP & Suất ăn Chay Thuần ngay trước giờ khai tiệc', 'Last-minute VIP table expansion & Vegan gala plates',
          'Banquet Captain! Two extra embassy delegations just arrived — we need 16 additional seats and 4 strict vegan menus in twenty minutes!||Tổ trưởng Yến tiệc ơi! Có thêm hai phái đoàn đại sứ quán vừa tới — mình cần kê thêm 16 ghế và 4 suất thực đơn Thuần Chay (Vegan) trong 20 phút nữa!',
          'On it right away! My team is setting two reserve round tables with crisp white linen while I brief the Executive Chef on four 4-course vegan menus.||Triển khai ngay lập tức ạ! Đội ngũ đang mở 2 bàn tròn dự phòng khăn trắng phẳng phiu, đồng thời tôi báo thẳng Bếp trưởng lên 4 thực đơn Thuần Chay 4 món.',
          'Tell the diplomats to share chairs!||(sai chuẩn ngoại giao) Bảo khách ngoại giao ngồi ghép chung ghế đi!',
          'Will the vegan courses come out at the same time as the regular VIP table?||Các món thuần chay có lên kịp cùng nhịp với bàn VIP thường không?',
          'Synchronized to the second! Each vegan plate has a discreet green {marker} so servers place it seamlessly without interrupting conversation.||Đồng bộ chính xác từng giây ạ! Mỗi suất thuần chay đều có ký hiệu nhận diện tinh tế để phục vụ đặt chuẩn xác mà không làm gián đoạn cuộc trò chuyện của khách.',
          ['whistle', 'sticker', 'receipt'],
          'Remarkable agility from your banquet brigade!||Sự linh hoạt đáng nể của đội ngũ yến tiệc!',
          'Always prepared with 10% reserve capacity for seamless grand events!||Chúng tôi luôn chuẩn bị sẵn 10% công suất dự phòng để mọi đại tiệc diễn ra suôn sẻ nhất ạ!',
          'We ran out of forks, use spoons.||(thiếu chuẩn bị) Hết nĩa rồi lấy thìa ăn tạm nhé.']
      ],
      [
        ['Khắc phục tức thời sự cố mất tín hiệu trình chiếu của Diễn giả chính', 'Instant AV failover during a keynote presentation',
          'AV & Banquet Lead! The keynote speaker’s MacBook adapter just flickered out thirty seconds before his live global stream!||Quản lý Kỹ thuật & Hội nghị ơi! Cổng chuyển MacBook của diễn giả chính vừa chập chờn mất hình chỉ 30 giây trước giờ phát sóng trực tuyến toàn cầu!',
          'Switching seamlessly to our mirrored backup laptop on HDMI Channel 2 — his slide deck and clicker are already live on the LED wall!||Đã chuyển mạch mượt mà sang máy dự phòng đồng bộ sẵn trên kênh HDMI 2 — toàn bộ slide và bút điều khiển của diễn giả đã lên màn LED tức thì!',
          'Turn off all lights and cancel the speech!||(hoảng loạn) Tắt hết đèn huỷ bài phát biểu đi!',
          'Phew, zero downtime! Can we bring warm honey-lemon water to the podium discreetly between sessions?||Phù, không gián đoạn một giây nào! Giữa phiên chuyển tiếp mình mang ly nước chanh mật ong ấm lên bục phát biểu một cách tinh tế được chứ?',
          'Certainly! Our stage attendant will place warm honey-lemon water on the side shelf during the applause {transition}.||Dạ chắc chắn rồi! Nhân viên hậu đài sẽ đặt ly nước ấm tại ngăn phụ bục phát biểu ngay nhịp vỗ tay chuyển phiên thật tự nhiên ạ.',
          ['explosion', 'blackout', 'vacation'],
          'Best conference venue team we have worked with in Asia!||Đội ngũ vận hành hội nghị xuất sắc nhất châu Á mà chúng tôi từng hợp tác!',
          'Thank you! Standing by for the gala dinner transformation at 6:00 p.m.!||Xin cảm ơn! Đội ngũ đã sẵn sàng chuyển đổi khán phòng sang đại tiệc Gala lúc 18:00 tối nay ạ!',
          'Cables are tangled everywhere, watch out!||(mất an toàn) Dây điện rối tung dưới chân coi chừng vấp!']
      ]
    ],
    ['recovery', ['front', 'room', 'lounge'],
      [
        ['Khôi phục dịch vụ khi món chính bàn Kỷ niệm lên chậm 25 phút', 'Service recovery for a delayed anniversary main course',
          'Duty Manager, we have been waiting thirty-five minutes for our main courses, and we have theater tickets at 8:30!||Quản lý trực ca ơi, chúng tôi chờ món chính 35 phút rồi, mà 8:30 tối còn có vé xem biểu diễn nữa!',
          'Please accept my sincere apologies for the delay. I just checked the pass — your dishes are being plated right now and will be on your table within two minutes.||Xin quý khách nhận lời xin lỗi chân thành nhất của tôi. Tôi vừa kiểm tra trực tiếp tại quầy Pass — món chính đang lên đĩa và sẽ đặt lên bàn mình trong đúng 2 phút tới ạ.',
          'The chef is busy cooking for more important tables.||(xúc phạm khách) Bếp đang bận nấu cho bàn quan trọng hơn rồi.',
          'We won’t have time for dessert before the show now.||Vậy lát nữa chúng tôi chẳng kịp ăn tráng miệng trước giờ diễn rồi.',
          'We have waived your main courses tonight, and our pastry team will deliver {complimentary} desserts and champagne to your suite after the show!||Nhà hàng xin phép miễn phí món chính tối nay, đồng thời đội bếp bánh sẽ gửi tặng phần tráng miệng và sâm-panh tận phòng Suite sau khi hai vị xem diễn về ạ!',
          ['expensive', 'leftover', 'cancelled'],
          'That completely turned our evening around — thank you so much!||Cách xử lý đã cứu trọn vẹn buổi tối của chúng tôi — cảm ơn bạn rất nhiều!',
          'Have a wonderful evening at the theater; our resort car is waiting outside so you arrive right on time!||Chúc hai vị buổi tối thưởng thức nghệ thuật tuyệt vời; xe riêng của resort đã chờ sẵn ngoài sảnh để đưa hai vị đi kịp giờ ạ!',
          'Eat fast in three minutes then!||(thúc giục thô lỗ) Vậy ráng nuốt lẹ trong 3 phút đi!']
      ],
      [
        ['Hạ nhiệt khủng hoảng khách VIP bức xúc tại sảnh (De-escalation)', 'Empathetic de-escalation of a distressed VIP guest',
          'This is unacceptable! My airport pickup wasn’t at Gate A, I had to take a cab in the rain, and I want to speak to the General Manager!||Không thể chấp nhận được! Xe đón sân bay không thấy ở Cổng A, tôi phải tự bắt taxi dưới mưa, cho tôi gặp Tổng Giám đốc ngay!',
          'Mr. Sterling, I am the Duty Manager on shift, and I am truly sorry for this frustrating arrival. May I invite you to our quiet VIP lounge with warm tea while I resolve everything personally?||Thưa ngài Sterling, tôi là Quản lý trực ca và thực sự xin lỗi ngài vì trải nghiệm đón tiếp đáng tiếc này. Xin phép mời ngài vào phòng chờ VIP yên tĩnh dùng trà ấm để đích thân tôi giải quyết trọn vẹn ngay lập tức ạ.',
          'Calm down, stop shouting in my lobby!||(đổ thêm dầu vào lửa) Bình tĩnh đi đừng la lối ở sảnh của tôi!',
          'Our flight landed early and exited Gate C instead of Gate A, so we missed the driver.||Chuyến bay hạ cánh sớm và đổi sang Cổng C thay vì Cổng A nên chúng tôi không gặp tài xế.',
          'That failure to track the gate change is entirely on us; I have {reimbursed} your taxi fare in full and arranged complimentary limousine return transfer plus a 60-minute spa recovery.||Việc chưa cập nhật kịp cổng ra mới hoàn toàn thuộc trách nhiệm của chúng tôi; khách sạn xin hoàn trả 100% cước taxi, tặng chiều xe Limousine tiễn sân bay và gói Spa thư giãn 60 phút cho ngài ạ.',
          ['doubled', 'ignored', 'refused'],
          'Thank you for owning the mistake without excuses. I appreciate your professionalism.||Cảm ơn bạn đã nhận trách nhiệm thẳng thắn không đổ lỗi. Tôi trân trọng sự chuyên nghiệp này.',
          'Thank you for giving us the opportunity to restore your trust, Mr. Sterling.||Xin chân thành cảm ơn ngài đã trao cơ hội để chúng tôi khôi phục niềm tin nơi ngài ạ.',
          'Next time text the driver yourself.||(đổ lỗi cho khách) Lần sau tự nhắn tin cho tài xế nhé.']
      ]
    ],
    ['interview', ['interview', 'meeting', 'boss'],
      [
        ['Tình huống nhập vai tuyển dụng Giám sát Nhà hàng (F&B Supervisor)', 'F&B Supervisor situational leadership interview',
          'As a newly promoted Supervisor, what would you do if two servers disagree in front of guests?||Trên cương vị Giám sát mới bổ nhiệm, bạn xử lý thế nào nếu hai nhân viên tranh luận ngay gần khu vực khách ngồi?',
          'First, I calmly step in to serve the guests seamlessly, invite both team members backstage privately, and coach them constructively after listening to both sides.||Đầu tiên tôi bình tĩnh bước vào tiếp quản phục vụ bàn khách thật êm thấm, mời hai bạn vào khu hậu sảnh riêng tư và lắng nghe cả hai phía để huấn luyện tích cực.',
          'Scold both of them loudly in the dining room!||(mất hình ảnh 5★) Mắng to cả hai ngay giữa phòng ăn cho chừa!',
          'How do you motivate tired staff during a 100% occupancy holiday weekend?||Bạn truyền lửa bằng cách nào khi nhân viên mệt mỏi trong dịp lễ kín 100% công suất?',
          'Lead from the front on the floor, rotate breaks fairly, and celebrate specific wins during post-shift {debrief}.||Trực tiếp xắn tay hỗ trợ anh em ngoài sảnh, chia ca nghỉ hợp lý và tuyên dương cụ thể từng nỗ lực trong buổi họp rút kinh nghiệm cuối ca ạ.',
          ['punishment', 'silence', 'rumor'],
          'Strong people-first leadership mindset!||Tư duy lãnh đạo lấy con người làm trọng tâm rất vững vàng!',
          'Thank you! Happy team members create genuinely happy guests!||Xin cảm ơn! Nhân viên hạnh phúc sẽ lan toả nụ cười chân thành nhất tới khách hàng ạ!',
          'Bosses only sit in air-conditioned offices.||(sai tư duy dịch vụ) Làm sếp chỉ ngồi phòng máy lạnh chỉ tay thôi.']
      ],
      [
        ['Báo cáo Chỉ số Hài lòng Khách hàng (GSS) & Đề xuất Cải tiến lên Tổng Giám đốc GM', 'Presenting Guest Satisfaction Scores (GSS) to the General Manager',
          'Department Head, our overall Guest Satisfaction Score hit 94%, yet breakfast wait-time dipped on Sundays. What is your action plan?||Trưởng bộ phận ơi, điểm hài lòng chung GSS đạt 94%, nhưng thời gian chờ ăn sáng Chủ nhật hơi giảm điểm. Kế hoạch cải tiến của bạn là gì?',
          'GM, we analyzed peak Sunday 8:30–9:30 traffic and are launching a lobby coffee-and-pastry welcome cart plus digital table paging to cut wait times by 60%.||Thưa Tổng Giám đốc, chúng tôi đã phân tích khung cao điểm 8:30–9:30 Chủ nhật và triển khai quầy cà phê bánh sừng bò chào đón kèm thiết bị báo bàn thông minh giúp giảm 60% thời gian chờ.',
          'Tell guests to wake up at 5:00 a.m. instead.||(thiếu thực tế) Bảo khách dậy từ 5 giờ sáng mà ăn cho vắng.',
          'Does this require additional payroll budget?||Giải pháp này có làm tăng quỹ lương nhân sự không?',
          'Zero extra payroll — we {cross-trained} two Lounge ambassadors to support the breakfast host stand during that 60-minute peak window.||Không phát sinh quỹ lương ạ — chúng tôi đã đào tạo chéo hai nhân sự Lounge sang hỗ trợ bục đón khách ăn sáng đúng 60 phút cao điểm đó.',
          ['terminated', 'ignored', 'complained'],
          'Data-driven, guest-centric, and budget-smart. Approved for this Sunday!||Dựa trên dữ liệu, hướng về khách hàng và tối ưu ngân sách. Duyệt triển khai ngay Chủ nhật này!',
          'Thank you, GM! We will track next week’s GSS and report the measurable uplift!||Xin cảm ơn Tổng Giám đốc! Chúng tôi sẽ đo lường điểm GSS tuần tới và báo cáo kết quả tăng trưởng cụ thể ạ!',
          'Numbers are boring anyway.||(thiếu chuyên nghiệp) Số liệu chán lắm đừng xem.']
      ]
    ]
  ];

  LEVEL_SPECS.forEach(function (spec) {
    var place = spec[0], spotsArr = spec[1], lv2List = spec[2], lv3List = spec[3];
    window.PLACE_LEVELS[place] = { 2: { en: { scenes: [] } }, 3: { en: { scenes: [] } } };
    lv2List.forEach(function (s, idx) {
      var sp = spotsArr[idx % spotsArr.length];
      window.PLACE_LEVELS[place][2].en.scenes.push(sc(s[0], s[1], [
        [s[2], 'mc', [s[3], s[4], 'My phone battery is almost dead.||(lạc đề) Điện thoại tôi sắp hết pin rồi.'], sp],
        [s[5], 'fill', s[6], s[7], sp],
        [s[8], 'mc', [s[9], s[10], 'I usually go jogging on Sundays.||(lạc đề) Chủ nhật tôi thường đi chạy bộ.'], sp]
      ]));
    });
    lv3List.forEach(function (s, idx) {
      var sp = spotsArr[idx % spotsArr.length];
      window.PLACE_LEVELS[place][3].en.scenes.push(sc(s[0], s[1], [
        [s[2], 'mc', [s[3], s[4], 'My sister is studying chemistry.||(lạc đề) Chị tôi đang học môn hoá học.'], sp],
        [s[5], 'fill', s[6], s[7], sp],
        [s[8], 'mc', [s[9], s[10], 'The train leaves from platform four.||(lạc đề) Tàu rời ga từ sân ga số 4.'], sp]
      ]));
    });
  });
})();
