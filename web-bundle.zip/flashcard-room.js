// ============================================================================
// GRANDSPEAK 5-STAR · 3D INTERACTIVE HOSPITALITY FLASHCARD STUDY ROOM BRIDGE
// Powers both embedded In-App view (state.view === 'room3d') AND standalone
// direct URL (/flashcard/room/ or /room) with 8 Hospitality Departments,
// 4 CEFR/Skill Levels + Topics, Click-Any-Word Lexicon Popover, Neural TTS,
// SRS/XP Progress Sync, and Live Multiplayer Classroom Presence (/api/room-ping).
// ============================================================================
(function () {
  'use strict';

  const esc = (x) =>
    String(x ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[c]));

  const cleanPipe = (s) => String(s ?? '').replace(/\|/g, '/').replace(/\s+/g, ' ').trim();

  function getClientId() {
    const KEY = 'gs_room3d_cid';
    try {
      let id = localStorage.getItem(KEY);
      if (!id || id.length < 8) {
        id = 'gs_' + Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
        localStorage.setItem(KEY, id);
      }
      return id;
    } catch {
      return 'gs_mem_' + Math.random().toString(36).slice(2, 10);
    }
  }

  // Curated 5-Star Hospitality Seed Cards per Room (ensures every Room & Level
  // always has rich, domain-authentic cards + merges dynamically with 1,088+ app words)
  const SEED_BY_ZONE = {
    fo: [
      ['check-in', '/ˈtʃek.ɪn/', 'thủ tục nhận phòng', 'Welcome to GrandSpeak Resort! May I assist you with your check-in?', 'Chào mừng quý khách đến GrandSpeak Resort! Tôi có thể hỗ trợ thủ tục nhận phòng cho quý khách không ạ?', 'A1', 'Đón tiếp & Check-in'],
      ['reservation', '/ˌrez.ɚˈveɪ.ʃən/', 'đặt phòng / đặt chỗ trước', 'I found your reservation for an oceanfront deluxe suite for three nights.', 'Tôi đã tìm thấy đơn đặt phòng Suite hướng biển trong 3 đêm của quý khách.', 'A1', 'Đón tiếp & Check-in'],
      ['keycard', '/ˈkiː.kɑːrd/', 'thẻ từ mở cửa phòng', 'Here is your room keycard; your suite is on the twelfth floor.', 'Đây là thẻ phòng của quý khách; phòng Suite nằm trên tầng 12 ạ.', 'A1', 'Đón tiếp & Check-in'],
      ['passport', '/ˈpæs.pɔːrt/', 'hộ chiếu tùy thân', 'May I kindly see your passport and booking confirmation, please?', 'Xin phép cho tôi kiểm tra hộ chiếu và xác nhận đặt phòng của quý khách được không ạ?', 'A1', 'Đón tiếp & Check-in'],
      ['deposit', '/dɪˈpɑː.zɪt/', 'tiền đặt cọc chi phí phát sinh', 'May I take a credit card pre-authorization as an incidental deposit?', 'Xin phép quý khách cho tôi giữ hạn mức thẻ tín dụng làm khoản cọc chi phí phát sinh nhé?', 'B1', 'Thanh toán & Tiền cọc'],
      ['complimentary', '/ˌkɑːm.pləˈmen.t̬ɚ.i/', 'miễn phí tặng kèm chuẩn 5 sao', 'Breakfast buffet and spa access are complimentary during your stay.', 'Bữa sáng tự chọn và khu Spa được phục vụ miễn phí trong suốt kỳ lưu trú của quý khách.', 'B1', 'Dịch vụ & Đặc quyền'],
      ['guest folio', '/ɡest ˈfoʊ.li.oʊ/', 'bảng kê chi tiết chi phí phòng', 'Here is your itemized guest folio for your review before check-out.', 'Đây là bảng kê chi phí chi tiết để quý khách kiểm tra trước khi trả phòng ạ.', 'B2', 'Thanh toán & Tiền cọc'],
      ['late check-out', '/leɪt ˈtʃek.aʊt/', 'trả phòng muộn', 'We are pleased to extend a complimentary late check-out until 2:00 PM.', 'Chúng tôi rất hân hạnh hỗ trợ quý khách trả phòng muộn miễn phí đến 14:00 ạ.', 'B1', 'Dịch vụ & Đặc quyền'],
      ['early arrival', '/ˈɜːr.li əˈraɪ.vəl/', 'khách đến nhận phòng sớm', 'Since you are an early arrival, may I offer a welcome drink while we inspect your suite?', 'Do quý khách đến sớm, xin phép mời quý khách dùng thức uống chào mừng trong lúc chúng tôi kiểm tra phòng lần cuối ạ?', 'B2', 'Đón tiếp & Check-in'],
      ['incidental charges', '/ˌɪn.sɪˈden.təl ˈtʃɑːr.dʒɪz/', 'chi phí phát sinh ngoài tiền phòng', 'Were there any minibar or laundry incidental charges this morning?', 'Sáng nay quý khách có sử dụng thêm minibar hay dịch vụ giặt ủi phát sinh nào không ạ?', 'B2', 'Thanh toán & Tiền cọc'],
      ['pre-authorization', '/ˌpriː.ɔː.θər.əˈzeɪ.ʃən/', 'tạm khóa hạn mức thẻ tín dụng', 'The pre-authorization hold will be automatically released upon check-out.', 'Khoản tạm giữ hạn mức trên thẻ sẽ được giải tỏa tự động ngay khi làm thủ tục trả phòng.', 'C1', 'Thanh toán & Tiền cọc'],
      ['occupancy', '/ˈɑː.kjə.pən.si/', 'công suất buồng phòng', 'Our resort is at full occupancy this holiday weekend.', 'Khu nghỉ dưỡng của chúng tôi đạt tối đa công suất phòng vào dịp cuối tuần lễ này.', 'C1', 'Vận hành Tiền sảnh'],
    ],
    fnb: [
      ['appetizer', '/ˈæp.ə.taɪ.zɚ/', 'món khai vị đầu bữa', 'Would you like to begin with a warm seafood appetizer?', 'Quý khách có muốn mở đầu bữa tối bằng một món hải sản khai vị nóng không ạ?', 'A1', 'Thực đơn & Gọi món'],
      ['main course', '/meɪn kɔːrs/', 'món chính', 'For your main course, our chef recommends the pan-seared sea bass.', 'Cho món chính, Bếp trưởng chúng tôi gợi ý món cá chẽm áp chảo bơ thảo mộc ạ.', 'A1', 'Thực đơn & Gọi món'],
      ['cutlery', '/ˈkʌt.lɚ.i/', 'bộ dao nĩa phục vụ bàn', 'Allow me to reset your table with fresh silver cutlery for the steak.', 'Xin phép quý khách cho tôi thay bộ dao nĩa mới chuyên dụng cho món bít-tết ạ.', 'A2', 'Bàn tiệc & Phục vụ'],
      ['a la carte', '/ˌɑː.ləˈkɑːrt/', 'gọi món lẻ theo thực đơn', 'You may order from our a la carte menu or choose the seven-course tasting menu.', 'Quý khách có thể gọi món lẻ hoặc chọn thực đơn thưởng thức 7 món của nhà hàng ạ.', 'B1', 'Thực đơn & Gọi món'],
      ['medium-rare', '/ˌmiː.di.əmˈrer/', 'độ chín tái vừa (ấm đỏ hồng)', 'Our ribeye steak is most tender and juicy when grilled medium-rare.', 'Thăn lưng bò của nhà hàng mềm mọng nhất khi được nướng ở độ chín tái vừa ạ.', 'B1', 'Thực đơn & Gọi món'],
      ['allergy', '/ˈæl.ɚ.dʒi/', 'dị ứng thực phẩm', 'Do any guests at the table have food allergies or dietary restrictions?', 'Trên bàn mình có quý khách nào bị dị ứng thực phẩm hay ăn kiêng đặc biệt không ạ?', 'B1', 'Dị ứng & Chăm sóc bàn'],
      ['palate cleanser', '/ˈpæl.ət ˈklen.zɚ/', 'món tráng vị làm sạch vị giác', 'Please enjoy this passion fruit sorbet as a refreshing palate cleanser.', 'Xin mời quý khách thưởng thức kem tuyết chanh dây giúp thanh lọc vị giác trước món chính ạ.', 'B2', 'Bàn tiệc & Phục vụ'],
      ['accompaniment', '/əˈkʌm.pə.ni.mənt/', 'món ăn kèm hài hòa', 'Truffle mashed potatoes make a wonderful accompaniment to the lamb rack.', 'Khoai tây nghiền nấm truffle là món ăn kèm tuyệt hảo cho sườn cừu nướng ạ.', 'B2', 'Thực đơn & Gọi món'],
      ['degustation', '/ˌdeɪ.ɡʊsˈteɪ.ʃən/', 'thực đơn thưởng thức nghệ thuật cao cấp', 'Our chef’s degustation menu showcases seasonal coastal ingredients.', 'Thực đơn thưởng thức của Bếp trưởng tôn vinh các nguyên liệu biển tươi theo mùa.', 'C1', 'Fine Dining Cao cấp'],
      ['amuse-bouche', '/əˌmjuːzˈbuːʃ/', 'món quà khai vị nhỏ từ Bếp trưởng', 'Please enjoy this complimentary amuse-bouche with our Executive Chef’s compliments.', 'Xin mời quý khách dùng món khai vị nhỏ đặc biệt do Bếp trưởng gửi tặng ạ.', 'C1', 'Fine Dining Cao cấp'],
    ],
    bar: [
      ['espresso', '/eˈspres.oʊ/', 'cà phê chiết xuất áp suất cao', 'Would you prefer a single or double shot of Arabica espresso?', 'Quý khách muốn dùng một hay hai shot cà phê Espresso hạt Arabica ạ?', 'A1', 'Barista & Cà phê'],
      ['mocktail', '/ˈmɑːk.teɪl/', 'cocktail trái cây không cồn', 'May I craft a refreshing lemongrass and lychee mocktail for you?', 'Tôi pha cho quý khách một ly mocktail sả vải tươi mát không cồn nhé ạ?', 'A2', 'Cocktail & Pha chế'],
      ['garnish', '/ˈɡɑːr.nɪʃ/', 'trang trí ly đồ uống / món ăn', 'We finish the Negroni with a flamed orange peel garnish.', 'Chúng tôi hoàn thiện ly Negroni bằng vỏ cam hơ lửa trang trí dậy hương thơm.', 'B1', 'Cocktail & Pha chế'],
      ['on the rocks', '/ɑːn ðə rɑːks/', 'phục vụ uống cùng đá viên lớn', 'Would you like your single malt whisky neat or on the rocks?', 'Quý khách muốn thưởng thức rượu Whisky mạch nha nguyên chất hay dùng kèm đá viên ạ?', 'B1', 'Cocktail & Pha chế'],
      ['microfoam', '/ˈmaɪ.kroʊ.foʊm/', 'lớp bọt sữa mịn mượt pha Latte Art', 'Silky steamed microfoam creates a balanced sweetness in our flat white.', 'Lớp bọt sữa mịn mượt giúp tạo vị ngọt cân bằng tự nhiên cho ly Flat White.', 'B2', 'Barista & Cà phê'],
      ['aperitif', '/əˌper.əˈtiːf/', 'đồ uống khai vị trước bữa ăn', 'May I start you off with sparkling water or an aperitif while you peruse the menu?', 'Xin phép mời quý khách dùng nước khoáng có ga hoặc một ly rượu khai vị trong lúc xem thực đơn ạ?', 'B2', 'Sommelier & Rượu vang'],
      ['bouquet', '/buˈkeɪ/', 'tầng hương phức hợp của rượu vang ủ', 'May I pour a tasting so you can experience the wine’s rich berry bouquet?', 'Xin phép rót một lượng nhỏ để quý khách cảm nhận tầng hương quả mọng quyến rũ của rượu vang ạ?', 'B2', 'Sommelier & Rượu vang'],
      ['decant', '/dɪˈkænt/', 'gạn thở rượu vang trong bình pha lê', 'Allow me to decant this vintage Cabernet Sauvignon for thirty minutes.', 'Xin phép cho tôi gạn rượu Cabernet Sauvignon lâu năm này sang bình thở trong 30 phút ạ.', 'C1', 'Sommelier & Rượu vang'],
      ['tannin', '/ˈtæn.ɪn/', 'độ chát cấu trúc của rượu vang đỏ', 'Velvety tannins pair effortlessly with the marbling of Wagyu beef.', 'Độ chát mượt mà của rượu kết hợp hoàn hảo với vân mỡ mềm của bò Wagyu.', 'C1', 'Sommelier & Rượu vang'],
      ['digestif', '/diː.ʒeˈstiːf/', 'rượu dùng sau bữa tối hỗ trợ tiêu hóa', 'Would you care for an aged Cognac or herbal digestif after dessert?', 'Quý khách có muốn dùng một ly Cognac ủ lâu năm hay rượu thảo mộc sau bữa tối không ạ?', 'C1', 'Sommelier & Rượu vang'],
    ],
    hk: [
      ['fresh towels', '/freʃ ˈtaʊ.əlz/', 'khăn tắm sạch mới', 'Certainly, I will bring four fresh bath towels to your room right away.', 'Dạ vâng, tôi sẽ mang 4 chiếc khăn tắm sạch mới lên phòng quý khách ngay lập tức ạ.', 'A1', 'Chăm sóc Phòng nghỉ'],
      ['amenities', '/əˈmen.ə.t̬iz/', 'bộ đồ dùng tiện nghi trong phòng', 'May I replenish your botanical bath amenities and bottled water?', 'Xin phép cho tôi bổ sung bộ tiện nghi phòng tắm thảo mộc và nước suối cho quý khách nhé?', 'A2', 'Chăm sóc Phòng nghỉ'],
      ['linen', '/ˈlɪn.ɪn/', 'chăn ga gối vải cao cấp', 'We change the Egyptian cotton bed linen fresh upon your request.', 'Chúng tôi thay mới bộ ga trải giường cotton Ai Cập theo yêu cầu của quý khách.', 'B1', 'Chăm sóc Phòng nghỉ'],
      ['turndown service', '/ˈtɜːrn.daʊn ˈsɜːr.vɪs/', 'dịch vụ chỉnh trang phòng buổi tối', 'Good evening! May I perform our evening turndown service for your suite?', 'Chào buổi tối quý khách! Xin phép cho tôi thực hiện dịch vụ chỉnh trang giường tối cho phòng mình nhé?', 'B1', 'Butler & Turndown 5★'],
      ['pillow menu', '/ˈpɪl.oʊ ˈmen.juː/', 'thực đơn chọn gối ngủ theo sở thích', 'Would you like to select a contour memory-foam or lavender pillow from our pillow menu?', 'Quý khách có muốn chọn gối cao su non định hình hoặc gối hương oải hương trong thực đơn gối ngủ không ạ?', 'B2', 'Butler & Turndown 5★'],
      ['dry cleaning', '/ˌdraɪ ˈkliː.nɪŋ/', 'giặt khô cao cấp cho trang phục vest/lụa', 'Express dry cleaning collected before 9:00 AM is returned by 5:00 PM today.', 'Đồ giặt khô nhanh nhận trước 9:00 sáng sẽ được hoàn trả tận phòng trước 17:00 cùng ngày ạ.', 'B2', 'Giặt ủi & Kỹ thuật'],
      ['lost and found', '/lɒst ænd faʊnd/', 'bộ phận lưu giữ đồ thất lạc của khách', 'I will check our Lost and Found logbook immediately for your wristwatch.', 'Tôi sẽ kiểm tra sổ nhật ký đồ thất lạc ngay lập tức để tìm chiếc đồng hồ cho quý khách ạ.', 'B1', 'Giặt ủi & Kỹ thuật'],
      ['privacy sign', '/ˈpraɪ.və.si saɪn/', 'biển Không làm phiền (DND)', 'We noticed the privacy sign on your door and left a courtesy note for you.', 'Chúng tôi thấy biển Không làm phiền trước cửa nên đã để lại thư nhắn lịch sự cho quý khách.', 'B2', 'Butler & Turndown 5★'],
      ['bespoke butler', '/bɪˈspoʊk ˈbʌt.lɚ/', 'dịch vụ quản gia cá nhân hóa 24/7', 'Your dedicated butler is delighted to unpack your garments and press your evening attire.', 'Quản gia riêng rất hân hạnh được sắp xếp hành lý và là phẳng trang phục dạ tiệc cho ngài.', 'C1', 'Butler & Turndown 5★'],
    ],
    kitchen: [
      ['steamed', '/stiːmd/', 'được hấp chín giữ vị ngọt tự nhiên', 'The wild grouper is gently steamed with ginger and scallions.', 'Cá mú tự nhiên được hấp chín nhẹ nhàng cùng gừng tươi và hành lá.', 'A1', 'Phương pháp Chế biến'],
      ['pan-seared', '/ˈpæn.sɪrd/', 'áp chảo vàng giòn bề mặt', 'Hokkaido scallops are pan-seared in clarified butter for ninety seconds.', 'Cồi sò điệp Hokkaido được áp chảo bơ trong trong 90 giây để giữ độ ngọt mọng.', 'A2', 'Phương pháp Chế biến'],
      ['slow-braised', '/sloʊ breɪzd/', 'hầm chậm nhỏ lửa cho mềm tan', 'Beef short ribs are slow-braised in red wine jus for six hours.', 'Sườn non bò được hầm chậm trong sốt rượu vang đỏ suốt 6 giờ đến khi mềm tan.', 'B1', 'Phương pháp Chế biến'],
      ['mise en place', '/ˌmiːz ɑːn ˈplɑːs/', 'chuẩn bị sơ chế sẵn sàng trước giờ mở ca', 'All stations have completed their mise en place before dinner service.', 'Tất cả các quầy bếp đã hoàn tất khâu chuẩn bị nguyên liệu trước ca tối.', 'B1', 'Quầy Pass & Điều phối Bếp'],
      ['cross-contact', '/krɒs ˈkɒn.tækt/', 'nhiễm chéo dị ứng thực phẩm', 'We use dedicated purple utensils to prevent any allergen cross-contact.', 'Bếp sử dụng bộ dụng cụ riêng màu tím để ngăn chặn tuyệt đối nguy cơ nhiễm chéo dị ứng.', 'B2', 'An toàn Thực phẩm HACCP'],
      ['gluten-free', '/ˌɡluː.tən ˈfriː/', 'không chứa gluten (lúa mì/lúa mạch)', 'Our chef can prepare a certified gluten-free rice noodle broth for you.', 'Bếp trưởng chúng tôi có thể chuẩn bị riêng phần nước dùng phở gạo hoàn toàn không chứa gluten ạ.', 'B1', 'An toàn Thực phẩm HACCP'],
      ['core temperature', '/kɔːr ˈtem.prə.tʃɚ/', 'nhiệt độ tâm thực phẩm theo chuẩn HACCP', 'Poultry must reach a safe internal core temperature of 74 degrees Celsius.', 'Thịt gia cầm bắt buộc đạt nhiệt độ tâm an toàn từ 74 độ C trở lên.', 'B2', 'An toàn Thực phẩm HACCP'],
      ['al dente', '/ˌæl ˈden.teɪ/', 'độ chín vừa tới có độ dai chuẩn Ý', 'Fresh tagliatelle pasta is boiled for three minutes until perfectly al dente.', 'Mì Ý tươi được luộc đúng 3 phút cho tới khi đạt độ chín dai hoàn hảo.', 'B2', 'Phương pháp Chế biến'],
      ['emulsion', '/ɪˈmʌl.ʃən/', 'nhũ tương hòa quyện bơ/dầu mịn màng (xốt)', 'Hollandaise is a warm butter and egg yolk emulsion seasoned with lemon.', 'Xốt Hollandaise là hỗn hợp nhũ tương ấm mịn giữa bơ trong và lòng đỏ trứng điểm chút chanh vàng.', 'C1', 'Nước xốt & Gia vị Âu'],
    ],
    concierge: [
      ['shuttle bus', '/ˈʃʌt.əl bʌs/', 'xe đưa đón theo khung giờ của resort', 'Our complimentary resort shuttle bus departs from the main porte-cochere every thirty minutes.', 'Xe đưa đón miễn phí của khu nghỉ dưỡng khởi hành tại sảnh chính mỗi 30 phút ạ.', 'A1', 'Di chuyển & Đưa đón'],
      ['luggage tag', '/ˈlʌɡ.ɪdʒ tæɡ/', 'thẻ hành lý ký gửi tại quầy Bell', 'Here is your luggage claim tag; our bellman will deliver your bags directly to your villa.', 'Đây là phiếu nhận hành lý của quý khách; nhân viên hành lý sẽ chuyển vali thẳng tới biệt thự ạ.', 'A2', 'Di chuyển & Đưa đón'],
      ['chauffeur', '/ʃoʊˈfɜːr/', 'tài xế riêng phục vụ xe sang Limousine', 'Your private airport chauffeur will greet you at Arrival Gate B with a name board.', 'Tài xế xe riêng đón sân bay sẽ chờ đón ngài tại Cổng đến B cùng biển tên riêng ạ.', 'B1', 'Di chuyển & Đưa đón'],
      ['itinerary', '/aɪˈtɪn.ə.rer.i/', 'lịch trình tham quan cá nhân hóa', 'Our Chief Concierge has curated a sunset cruise itinerary tailored for your family.', 'Trưởng bộ phận Concierge đã thiết kế riêng lịch trình du thuyền ngắm hoàng hôn cho gia đình mình.', 'B2', 'Trải nghiệm & VIP Lounge'],
      ['executive lounge', '/ɪɡˈzek.jə.tɪv laʊndʒ/', 'phòng chờ đặc quyền dành cho khách Suite/VIP', 'Your suite includes all-day refreshments and evening cocktails at the Executive Lounge.', 'Hạng phòng Suite của ngài bao gồm trà bánh cả ngày và cocktail tối tại Executive Lounge.', 'B2', 'Trải nghiệm & VIP Lounge'],
      ['oceanfront cabana', '/ˈoʊ.ʃən.frʌnt kəˈbæn.ə/', 'lều nghỉ sang trọng sát bờ biển', 'We have reserved a shaded oceanfront cabana with chilled fruit platters for you.', 'Chúng tôi đã giữ sẵn chòi nghỉ hướng biển kèm đĩa trái cây ướp lạnh phục vụ quý khách.', 'B2', 'Trải nghiệm & VIP Lounge'],
      ['les clefs d’or', '/leɪ kleɪ dɔːr/', 'chuẩn Chìa Khóa Vàng Concierge quốc tế', 'With Les Clefs d’Or dedication, we fulfill bespoke requests with discretion and grace.', 'Với tinh thần Chìa Khóa Vàng quốc tế, chúng tôi đáp ứng mọi yêu cầu tinh tế và kín đáo nhất.', 'C1', 'Trải nghiệm & VIP Lounge'],
    ],
    banquet: [
      ['ballroom', '/ˈbɔːl.ruːm/', 'khán phòng đại tiệc không cột', 'The Grand Ballroom accommodates up to five hundred guests for gala dinners.', 'Khán phòng Đại tiệc có sức chứa lên tới 500 khách cho các đêm tiệc Gala sang trọng.', 'A2', 'Sảnh tiệc & Bố trí bàn'],
      ['coffee break', '/ˈkɔː.fi breɪk/', 'tiệc trà giải lao giữa giờ hội nghị', 'Fresh pastries and artisan coffee will be served in the foyer during the morning coffee break.', 'Bánh nướng mới ra lò và cà phê pha máy sẽ được phục vụ tại sảnh chờ trong giờ giải lao sáng.', 'A2', 'Sảnh tiệc & Bố trí bàn'],
      ['podium', '/ˈpoʊ.di.əm/', 'bục phát biểu trang bị micro cổ ngỗng', 'Our AV technician has tested the wireless lapel microphone and podium clicker.', 'Kỹ thuật viên âm thanh ánh sáng đã kiểm tra sẵn micro cài áo không dây và bút trình chiếu tại bục phát biểu.', 'B1', 'Hội nghị MICE & AV'],
      ['cloche', '/kloʊʃ/', 'nắp chụp đĩa bạc phục vụ tiệc VIP đồng loạt', 'Twenty banquet servers will lift the silver cloches in synchronized unison for the VIP table.', 'Hai mươi nhân viên yến tiệc sẽ mở nắp chụp bạc đồng loạt cùng một nhịp tại bàn khách VIP.', 'B2', 'Phục vụ Gala & Spa'],
      ['banquet event order', '/ˈbæŋ.kwɪt ɪˈvent ˈɔːr.dɚ/', 'lệnh điều phối sự kiện – yến tiệc (BEO)', 'Every department aligns setup timing, menu counts, and AV cues strictly with the BEO.', 'Mọi bộ phận phối hợp giờ dựng sảnh, số suất ăn và kịch bản âm thanh sát theo phiếu lệnh tiệc BEO.', 'B2', 'Hội nghị MICE & AV'],
      ['hydrotherapy', '/ˌhaɪ.droʊˈθer.ə.pi/', 'liệu pháp thủy trị liệu thư giãn tại Spa', 'Please arrive twenty minutes early to enjoy our herbal steam room and hydrotherapy vitality pool.', 'Xin mời quý khách đến sớm 20 phút để tận hưởng phòng xông thảo dược và hồ thủy trị liệu.', 'C1', 'Phục vụ Gala & Spa'],
    ],
    recovery: [
      ['apologize', '/əˈpɑː.lə.dʒaɪz/', 'xin lỗi chân thành theo chuẩn 5 sao', 'I sincerely apologize for the wait; allow me to check with our chef right away.', 'Tôi chân thành xin lỗi quý khách vì sự chờ đợi; xin phép cho tôi kiểm tra trực tiếp với bếp ngay ạ.', 'A2', 'Quy trình L.A.S.T.'],
      ['inconvenience', '/ˌɪn.kənˈviː.ni.əns/', 'sự bất tiện ngoài ý muốn', 'Please accept my sincere apologies for the inconvenience with your room keycard.', 'Xin quý khách lượng thứ cho sự bất tiện về thẻ từ phòng; tôi sẽ cấp lại thẻ mới ngay lập tức ạ.', 'B1', 'Quy trình L.A.S.T.'],
      ['duty manager', '/ˈduː.t̬i ˈmæn.ɪ.dʒɚ/', 'quản lý trực ca điều hành khách sạn', 'Please allow me to invite our Duty Manager right over to assist you personally.', 'Xin phép quý khách cho tôi mời Quản lý trực ca đến hỗ trợ trực tiếp cho quý khách ngay bây giờ ạ.', 'B1', 'Cứu ca & Xử lý vượt cấp'],
      ['personal ownership', '/ˈpɜːr.sən.əl ˈoʊ.nɚ.ʃɪp/', 'nhận trách nhiệm theo dõi đến cùng cho khách', 'Let me take personal ownership of this request and update you within five minutes.', 'Xin hãy để cá nhân tôi trực tiếp phụ trách yêu cầu này và cập nhật lại với ngài trong vòng 5 phút ạ.', 'B2', 'Quy trình L.A.S.T.'],
      ['service recovery', '/ˈsɜːr.vɪs rɪˈkʌv.ɚ.i/', 'khôi phục niềm tin khách hàng sau sự cố', 'Effective service recovery turns a moment of friction into lasting guest loyalty.', 'Khôi phục dịch vụ tinh tế giúp biến một sự cố nhỏ thành sự gắn bó trọn vẹn của khách hàng.', 'B2', 'Quy trình L.A.S.T.'],
      ['with our compliments', '/wɪð ˈaʊər ˈkɑːm.plə.mənts/', 'nhà hàng / khách sạn trân trọng gửi tặng miễn phí', 'Please enjoy these artisan desserts and champagne with our compliments.', 'Xin mời quý khách thưởng thức phần bánh tráng miệng thủ công và rượu sâm-panh do nhà hàng trân trọng gửi tặng ạ.', 'B2', 'Cứu ca & Xử lý vượt cấp'],
      ['de-escalate', '/ˌdiːˈes.kə.leɪt/', 'hạ nhiệt tình huống khách bức xúc bằng sự thấu cảm', 'Maintain calm eye contact and empathetic listening to de-escalate guest frustration.', 'Giữ ánh mắt điềm tĩnh và lắng nghe thấu cảm để xoa dịu cơn bức xúc của khách hàng.', 'C1', 'Cứu ca & Xử lý vượt cấp'],
    ],
  };

  const ZONE_META = {
    fo: { deptIds: ['front'], topicIds: ['checkin-front', 'billing-pos'], glossCats: ['front office', 'reception', 'reservation', 'cashier'] },
    fnb: { deptIds: ['fnb'], topicIds: ['menu-gastronomy', 'tableware-service'], glossCats: ['restaurant', 'f&b', 'service', 'dining', 'menu', 'steak'] },
    bar: { deptIds: ['bar'], topicIds: ['wine-sommelier', 'bar-barista'], glossCats: ['bar', 'wine', 'beverage', 'coffee', 'cocktail', 'sommelier'] },
    hk: { deptIds: ['house'], topicIds: ['butler-house', 'laundry-facility'], glossCats: ['housekeeping', 'room', 'laundry', 'butler'] },
    kitchen: { deptIds: ['kitchen'], topicIds: ['culinary-haccp'], glossCats: ['kitchen', 'culinary', 'cooking', 'food safety', 'pastry', 'sauce', 'ingredient'] },
    concierge: { deptIds: ['front'], topicIds: ['vip-concierge'], glossCats: ['concierge', 'vip', 'bell', 'transport', 'lounge'] },
    banquet: { deptIds: ['fnb'], topicIds: ['banquet-mice'], glossCats: ['banquet', 'mice', 'event', 'spa', 'wellness'] },
    recovery: { deptIds: ['service'], topicIds: ['service-recovery', 'complaint-last'], glossCats: ['recovery', 'complaint', 'management', 'supervisor'] },
  };

  const LEVEL_BUCKETS = [
    { code: 'A', label: 'Level 1 · Cơ bản & Đón tiếp (A1–A2)' },
    { code: 'B1', label: 'Level 2 · Giao tiếp Ca trực (B1)' },
    { code: 'B2', label: 'Level 3 · Nghiệp vụ Chuẩn 5 Sao (B2)' },
    { code: 'C1', label: 'Level 4 · VIP, Fine Dining & Quản lý (C1)' },
  ];

  function normalizeLevelBucket(lvRaw, wordText) {
    const s = String(lvRaw || '').toUpperCase();
    if (s.includes('C1') || s.includes('C2')) return 'C1';
    if (s.includes('B2')) return 'B2';
    if (s.includes('B1')) return 'B1';
    if (s.includes('A1') || s.includes('A2')) return 'A';
    const len = String(wordText || '').length;
    if (len <= 7) return 'A';
    if (len <= 10) return 'B1';
    if (len <= 14) return 'B2';
    return 'C1';
  }

  let compiledCache = null;
  let wordIndexCache = null;

  function buildCompiledZones() {
    if (compiledCache) return compiledCache;
    // In standalone mode (/flashcard/room/), hydrate WORDS from W & MORE_WORDS if app.js is not loaded
    if (typeof window.WORDS === 'undefined' && typeof W !== 'undefined' && Array.isArray(W)) {
      const map = {};
      for (const row of W) {
        if (row && row[0]) map[row[0]] = { id: row[0], ipa: row[1], meaning: row[2], context: row[3], chunk: row[4], tip: row[5] };
      }
      if (typeof MORE_WORDS !== 'undefined' && Array.isArray(MORE_WORDS)) {
        for (const row of MORE_WORDS) {
          if (row && row[0] && !map[row[0]]) map[row[0]] = { id: row[0], ipa: row[1], meaning: row[2], context: row[3], chunk: row[4], tip: row[5] };
        }
      }
      window.WORDS = map;
    }
    const WORDS_REF = typeof WORDS === 'object' ? WORDS : window.WORDS;
    const out = {};
    const wordMap = {};

    const registerWordMeta = (w, ipa, meaning, exEn, exVi, level, topic, pos) => {
      const k = String(w || '').trim().toLowerCase();
      if (!k) return;
      if (!wordMap[k]) {
        wordMap[k] = {
          head: String(w).trim(),
          ipa: ipa || '',
          pos: pos || 'Thuật ngữ 5★',
          level: level || 'B1',
          vi: [],
          ex: [],
          col: [],
          syn: [],
          ant: [],
          rel: [],
        };
      }
      const entry = wordMap[k];
      if (ipa && !entry.ipa) entry.ipa = ipa;
      if (meaning && !entry.vi.includes(meaning)) entry.vi.push(meaning);
      if (exEn && !entry.ex.some((e) => e.s === exEn) && entry.ex.length < 4) {
        entry.ex.push({ s: exEn, vi: exVi || '' });
      }
      if (topic && entry.rel.length < 5 && !entry.rel.some((r) => r.w === topic)) {
        entry.rel.push({ w: topic, vi: '' });
      }
    };

    Object.keys(SEED_BY_ZONE).forEach((zId) => {
      const bucketMap = { A: {}, B1: {}, B2: {}, C1: {} };
      const seenWords = new Set();

      const addCard = (word, ipa, meaning, exEn, exVi, lvRaw, topicName, posLabel) => {
        const w = cleanPipe(word);
        const m = cleanPipe(meaning);
        if (!w || !m || w.length > 48) return;
        const key = w.toLowerCase();
        const ex = cleanPipe(exEn || `In five-star service, "${w}" is used professionally during every shift.`);
        const vi = cleanPipe(exVi || `Trong dịch vụ 5 sao, “${w}” (${m}) được sử dụng chuẩn mực trong ca trực.`);
        const rd = cleanPipe(ipa || '/…/');
        const bCode = normalizeLevelBucket(lvRaw, w);
        const tp = cleanPipe(topicName || 'Từ vựng Trọng tâm');
        registerWordMeta(w, rd, m, ex, vi, bCode === 'A' ? 'A2' : bCode, tp, posLabel);
        if (seenWords.has(key)) return;
        seenWords.add(key);
        if (!bucketMap[bCode][tp]) bucketMap[bCode][tp] = [];
        bucketMap[bCode][tp].push(`${w}|${rd}|${m}|${ex}|${vi}`);
      };

      // 1. Curated seeds
      for (const row of SEED_BY_ZONE[zId]) {
        addCard(row[0], row[1], row[2], row[3], row[4], row[5], row[6], 'Chuẩn 5★');
      }

      const meta = ZONE_META[zId];

      // 2. Merge CURRICULUM lessons matching department
      if (typeof CURRICULUM !== 'undefined' && Array.isArray(CURRICULUM) && typeof WORDS === 'object') {
        for (const lesson of CURRICULUM) {
          if (!meta.deptIds.includes(lesson.department)) continue;
          const phraseMap = Array.isArray(lesson.phrases) ? lesson.phrases : [];
          (lesson.words || []).forEach((wId, idx) => {
            const wObj = WORDS[wId];
            if (!wObj) return;
            const matchedPhrase = phraseMap.find((p) => String(p[0] || '').toLowerCase().includes(wId.toLowerCase())) || phraseMap[idx % Math.max(1, phraseMap.length)];
            const exEn = matchedPhrase ? matchedPhrase[0] : (wObj.chunk ? `May I assist with ${wObj.chunk} right away?` : wObj.context);
            const exVi = matchedPhrase ? matchedPhrase[1] : `${wObj.meaning} · ${wObj.context || ''}`;
            addCard(wObj.id, wObj.ipa, wObj.meaning, exEn, exVi, idx < 3 ? 'A2' : 'B1', lesson.title, 'Bài học Ca trực');
          });
        }
      }

      // 3. Merge GROUPS / W bank if available
      if (typeof GROUPS === 'object' && typeof WORDS === 'object') {
        for (const dId of meta.deptIds) {
          const gList = GROUPS[dId] || [];
          gList.forEach((wId, i) => {
            const wObj = WORDS[wId];
            if (!wObj) return;
            const exEn = wObj.chunk ? `Please remember to ${wObj.chunk} according to our 5-star standard.` : `We use "${wObj.id}" in daily hotel service.`;
            const exVi = `${wObj.meaning} (${wObj.context || 'Chuẩn giao tiếp khách sạn 5 sao'})`;
            addCard(wObj.id, wObj.ipa, wObj.meaning, exEn, exVi, i % 3 === 0 ? 'A2' : i % 3 === 1 ? 'B1' : 'B2', 'Từ vựng Bộ phận', 'Từ vựng Cốt lõi');
          });
        }
      }

      // 4. Merge glossaryAll() if available
      if (typeof window.glossaryAll === 'function') {
        try {
          const allG = window.glossaryAll() || [];
          for (const g of allG) {
            const cat = String(g.category || g.department || g.role || '').toLowerCase();
            if (!meta.glossCats.some((kw) => cat.includes(kw))) continue;
            const term = g.term || g.en || g.word;
            const vi = g.vi || g.meaning_vi || g.meaning;
            if (!term || !vi) continue;
            addCard(
              term,
              g.ipa || '',
              vi,
              g.example_en || g.example || `Our team applies "${term}" with five-star precision.`,
              g.example_vi || g.pro_context || vi,
              g.level || 'B2',
              g.category || 'Thuật ngữ Chuyên ngành',
              g.category || 'Thuật ngữ F&B & Hotel'
            );
          }
        } catch {}
      }

      // Build structured levels array
      const levels = [];
      const allTopicsCombined = [];
      for (const lb of LEVEL_BUCKETS) {
        const tNames = Object.keys(bucketMap[lb.code]).filter((k) => bucketMap[lb.code][k].length > 0);
        if (!tNames.length) continue;
        const topics = tNames.map((name) => ({ name, cards: bucketMap[lb.code][name] }));
        levels.push({ name: lb.label, topics });
        topics.forEach((t) => allTopicsCombined.push(t));
      }
      if (allTopicsCombined.length > 1) {
        levels.push({
          name: '🌟 Trọn bộ Khu vực (Tất cả Level)',
          topics: allTopicsCombined,
        });
      }
      out[zId] = levels;
    });

    // Also index ALL remaining WORDS so clicking any word in any example sentence works
    if (typeof WORDS === 'object') {
      for (const k of Object.keys(WORDS)) {
        const w = WORDS[k];
        if (w && w.id && w.meaning) {
          registerWordMeta(w.id, w.ipa, w.meaning, w.chunk || '', w.context || '', 'B1', w.chunk || '', 'Từ vựng Khách sạn');
          if (w.chunk) {
            const entry = wordMap[w.id.toLowerCase()];
            if (entry && entry.col.length < 5) entry.col.push({ w: w.chunk, vi: w.meaning });
          }
        }
      }
    }

    compiledCache = out;
    wordIndexCache = wordMap;
    return out;
  }

  function stemCandidates(raw) {
    const clean = String(raw || '').toLowerCase().replace(/^[^a-z]+|[^a-z'-]+$/g, '');
    if (!clean) return [];
    const list = [clean];
    if (clean.endsWith('ies') && clean.length > 4) list.push(clean.slice(0, -3) + 'y');
    if (clean.endsWith('ing') && clean.length > 5) {
      list.push(clean.slice(0, -3), clean.slice(0, -3) + 'e');
      if (clean.length > 6 && clean.at(-4) === clean.at(-5)) list.push(clean.slice(0, -4));
    }
    if (clean.endsWith('ed') && clean.length > 4) {
      list.push(clean.slice(0, -2), clean.slice(0, -1));
      if (clean.endsWith('ied')) list.push(clean.slice(0, -3) + 'y');
      if (clean.length > 5 && clean.at(-3) === clean.at(-4)) list.push(clean.slice(0, -3));
    }
    if (clean.endsWith('es') && clean.length > 4) list.push(clean.slice(0, -2), clean.slice(0, -1));
    if (clean.endsWith('s') && clean.length > 3) list.push(clean.slice(0, -1));
    if (clean.endsWith('ly') && clean.length > 4) list.push(clean.slice(0, -2));
    return [...new Set(list)];
  }

  const COMMON_FUNCTION_WORDS = {
    welcome: { ipa: '/ˈwel.kəm/', pos: 'Động từ / Danh từ 5★', level: 'A1', vi: ['chào mừng nồng hậu quý khách đến khách sạn / khu nghỉ dưỡng'] },
    resort: { ipa: '/rɪˈzɔːrt/', pos: 'Danh từ (Noun)', level: 'A2', vi: ['khu nghỉ dưỡng cao cấp'] },
    hotel: { ipa: '/hoʊˈtel/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['khách sạn'] },
    assist: { ipa: '/əˈsɪst/', pos: 'Động từ 5★', level: 'B1', vi: ['hỗ trợ tận tình cho quý khách (lịch sự hơn "help": May I assist you?)'] },
    offer: { ipa: '/ˈɔː.fɚ/', pos: 'Động từ (Verb)', level: 'A2', vi: ['mời, dành tặng quý khách (May I offer you a welcome drink?)'] },
    enjoy: { ipa: '/ɪnˈdʒɔɪ/', pos: 'Động từ (Verb)', level: 'A1', vi: ['thưởng thức, tận hưởng (Please enjoy your stay!)'] },
    stay: { ipa: '/steɪ/', pos: 'Danh từ / Động từ', level: 'A1', vi: ['kỳ lưu trú nghỉ dưỡng; lưu trú tại khách sạn'] },
    room: { ipa: '/ruːm/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['phòng nghỉ khách sạn'] },
    table: { ipa: '/ˈteɪ.bəl/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['bàn ăn nhà hàng'] },
    menu: { ipa: '/ˈmen.juː/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['thực đơn nhà hàng / quầy bar'] },
    order: { ipa: '/ˈɔːr.dɚ/', pos: 'Động từ / Danh từ', level: 'A1', vi: ['gọi món; đơn gọi món của khách'] },
    fresh: { ipa: '/freʃ/', pos: 'Tính từ (Adjective)', level: 'A1', vi: ['tươi mới, sạch mới (fresh towels, fresh seafood)'] },
    water: { ipa: '/ˈwɔː.t̬ɚ/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['nước uống (still water: nước suối · sparkling water: nước khoáng có ga)'] },
    wine: { ipa: '/waɪn/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['rượu vang'] },
    morning: { ipa: '/ˈmɔːr.nɪŋ/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['buổi sáng (Good morning, sir/madam!)'] },
    afternoon: { ipa: '/ˌæf.tɚˈnuːn/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['buổi chiều (Good afternoon!)'] },
    evening: { ipa: '/ˈiːv.nɪŋ/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['buổi tối (Good evening!)'] },
    night: { ipa: '/naɪt/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['đêm lưu trú (three nights: 3 đêm)'] },
    floor: { ipa: '/flɔːr/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['tầng lầu của tòa nhà khách sạn'] },
    sir: { ipa: '/sɜːr/', pos: 'Danh xưng trang trọng', level: 'A1', vi: ['ngài / quý ông (cách xưng hô chuẩn 5 sao)'] },
    madam: { ipa: '/ˈmæd.əm/', pos: 'Danh xưng trang trọng', level: 'A1', vi: ['quý bà / phu nhân (cách xưng hô chuẩn 5 sao)'] },
    pleasure: { ipa: '/ˈpleʒ.ɚ/', pos: 'Danh từ 5★', level: 'B1', vi: ['niềm vinh hạnh (My pleasure: Rất hân hạnh được phục vụ quý khách)'] },
    may: { ipa: '/meɪ/', pos: 'Động từ khuyết thiếu lịch sự', level: 'A1', vi: ['xin phép, có thể (mẫu câu lịch sự 5 sao: May I…?)'] },
    would: { ipa: '/wʊd/', pos: 'Động từ khuyết thiếu lịch sự', level: 'A2', vi: ['sẽ, muốn (mời khách tinh tế: Would you like / prefer…?)'] },
    could: { ipa: '/kʊd/', pos: 'Động từ khuyết thiếu lịch sự', level: 'A2', vi: ['có thể vui lòng (Could you please…?)'] },
    please: { ipa: '/pliːz/', pos: 'Thán từ lịch sự', level: 'A1', vi: ['xin vui lòng, làm ơn'] },
    allow: { ipa: '/əˈlaʊ/', pos: 'Động từ (Verb)', level: 'B1', vi: ['cho phép (Allow me to…: Xin phép cho tôi…)'] },
    certainly: { ipa: '/ˈsɜːr.tən.li/', pos: 'Trạng từ 5★', level: 'B1', vi: ['dạ chắc chắn rồi, vâng tất nhiên ạ'] },
    sincerely: { ipa: '/sɪnˈsɪr.li/', pos: 'Trạng từ 5★', level: 'B2', vi: ['một cách chân thành (sincerely apologize)'] },
    delighted: { ipa: '/dɪˈlaɪ.t̬ɪd/', pos: 'Tính từ 5★', level: 'B2', vi: ['rất hân hạnh, vui mừng được phục vụ'] },
    prefer: { ipa: '/prɪˈfɜːr/', pos: 'Động từ (Verb)', level: 'B1', vi: ['ưu tiên, thích dùng hơn (Would you prefer A or B?)'] },
    recommend: { ipa: '/ˌrek.əˈmend/', pos: 'Động từ (Verb)', level: 'B1', vi: ['gợi ý, giới thiệu món đặc sắc'] },
    suite: { ipa: '/swiːt/', pos: 'Danh từ (Noun)', level: 'B1', vi: ['phòng nghỉ hạng sang Suite (đọc giống "sweet" /swiːt/)'] },
    guest: { ipa: '/ɡest/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['quý khách lưu trú / thực khách'] },
    chef: { ipa: '/ʃef/', pos: 'Danh từ (Noun)', level: 'A1', vi: ['đầu bếp trưởng / đầu bếp chuyên nghiệp (âm đầu /ʃ/)'] },
  };

  // Expose window.SF bridge matching VSpeak room.html & places.html contract 1:1
  const SF = (window.SF = window.SF || {});
  SF.premium = true;
  SF.isAdmin = true;

  SF.unlockAudio = function () {
    try {
      if (window.speechSynthesis) {
        const u = new SpeechSynthesisUtterance(' ');
        u.volume = 0;
        window.speechSynthesis.speak(u);
      }
    } catch {}
  };

  let sfAudio = null;
  SF.speak = function (text, opts) {
    const clean = String(text || '').trim();
    const onDone = opts && typeof opts.onDone === 'function' ? opts.onDone : null;
    if (!clean) {
      if (onDone) setTimeout(onDone, 20);
      return;
    }
    try {
      window.academyStopViSpeech?.();
      if (sfAudio) {
        sfAudio.pause();
        sfAudio = null;
      }
    } catch {}
    if (!onDone && typeof window.parrotoSpeak === 'function') {
      window.parrotoSpeak(clean, 'en-US');
      return;
    }
    if (!onDone && typeof window.academySpeak === 'function') {
      window.academySpeak(clean);
      return;
    }
    // High-clarity neural /api/tts-en with automatic speechSynthesis fallback and guaranteed onDone callback
    const accent = opts && opts.voice === 0 ? 'en-GB' : 'en-US';
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      if (onDone) onDone();
    };
    try {
      const a = new Audio(`/api/tts-en?accent=${encodeURIComponent(accent)}&text=${encodeURIComponent(clean)}`);
      sfAudio = a;
      const tmr = setTimeout(finish, Math.min(12000, 2600 + clean.length * 100));
      a.onended = () => {
        clearTimeout(tmr);
        finish();
      };
      a.onerror = () => {
        clearTimeout(tmr);
        speakFallbackBrowser(clean, accent, finish);
      };
      const p = a.play();
      if (p && p.catch) {
        p.catch(() => {
          clearTimeout(tmr);
          speakFallbackBrowser(clean, accent, finish);
        });
      }
      return;
    } catch {
      speakFallbackBrowser(clean, accent, finish);
    }
  };

  function speakFallbackBrowser(clean, accent, finish) {
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(clean);
        u.lang = accent || 'en-US';
        u.rate = 0.88;
        const vs = window.speechSynthesis.getVoices() || [];
        const pick = vs.find((v) => /en[-_]US/i.test(v.lang)) || vs.find((v) => /^en/i.test(v.lang));
        if (pick) u.voice = pick;
        const tmr = setTimeout(finish, 2000 + clean.length * 110);
        u.onend = u.onerror = () => {
          clearTimeout(tmr);
          finish();
        };
        window.speechSynthesis.speak(u);
        return;
      } catch {}
    }
    setTimeout(finish, 300);
  }

  SF.stopSpeak = function () {
    try {
      if (sfAudio) {
        sfAudio.pause();
        sfAudio = null;
      }
      window.academyStopEnglishSpeech?.();
      window.speechSynthesis?.cancel();
    } catch {}
  };

  SF.roomTree = function (zoneId) {
    return Promise.resolve().then(() => {
      // Rebuild if main app data arrived after initial load
      if (compiledCache && typeof WORDS === 'object' && Object.keys(wordIndexCache || {}).length < 120) {
        compiledCache = null;
      }
      const zones = buildCompiledZones();
      const levels = zones[zoneId] || zones.fo || [];
      return levels.map((lv) => [lv.name, lv.topics.map((t) => `${t.name} (${t.cards.length} thẻ)`)]);
    });
  };

  SF.roomCards = function (zoneId, lvIdx, tpIdx) {
    return Promise.resolve().then(() => {
      const zones = buildCompiledZones();
      const levels = zones[zoneId] || zones.fo || [];
      const lv = levels[lvIdx];
      if (!lv) return [];
      if (tpIdx !== null && tpIdx !== undefined && lv.topics[tpIdx]) {
        return lv.topics[tpIdx].cards.slice();
      }
      const seen = new Set();
      const merged = [];
      for (const t of lv.topics) {
        for (const c of t.cards) {
          const k = c.split('|')[0].toLowerCase();
          if (!seen.has(k)) {
            seen.add(k);
            merged.push(c);
          }
        }
      }
      return merged;
    });
  };

  SF.exampleHtml = function (sentence, targetWord) {
    const s = String(sentence || '');
    if (!s) return '';
    const bareTarget = String(targetWord || '').trim().toLowerCase();
    // Tokenize words while preserving spaces & punctuation
    return s
      .split(/([A-Za-zÀ-ỹ]+(?:['’-][A-Za-zÀ-ỹ]+)*)/g)
      .map((tok) => {
        if (!/^[A-Za-z]/.test(tok)) return esc(tok);
        const low = tok.toLowerCase();
        const isHl =
          bareTarget &&
          (low === bareTarget ||
            bareTarget.split(/\s+/).includes(low) ||
            (bareTarget.length >= 4 && low.startsWith(bareTarget.slice(0, -1))));
        return `<button type="button" class="sf-ex-word${isHl ? ' sf-ex-hl' : ''}" data-word="${esc(tok)}" data-sentence="${esc(s)}">${esc(tok)}</button>`;
      })
      .join('');
  };

  SF.roomExample = function () {
    return { ro: '', en: '' };
  };

  SF.roomWord = async function (zoneId, word, sentence) {
    buildCompiledZones();
    const candidates = stemCandidates(word);
    let hit = null;
    for (const c of candidates) {
      if (wordIndexCache && wordIndexCache[c]) {
        hit = wordIndexCache[c];
        break;
      }
      if (COMMON_FUNCTION_WORDS[c]) {
        const fn = COMMON_FUNCTION_WORDS[c];
        hit = { head: c, ipa: fn.ipa, pos: fn.pos, level: fn.level, vi: fn.vi, ex: sentence ? [{ s: sentence, vi: '' }] : [], col: [], syn: [], ant: [], rel: [] };
        break;
      }
    }

    if (hit) {
      return {
        head: hit.head,
        pos: hit.pos || 'Hospitality 5★',
        vi: hit.vi,
        en: [],
        entry: { ipa: hit.ipa },
        info: {
          read: hit.ipa,
          level: hit.level || 'B1',
          ex: hit.ex || [],
          col: hit.col || [],
          syn: hit.syn || [],
          ant: hit.ant || [],
          rel: hit.rel || [],
        },
        extra: '',
      };
    }

    // Fallback to live /api/dict only when authenticated inside GrandSpeak
    const isAuthed = Boolean(window.academyCurrentProfile?.()?.authenticated);
    if (isAuthed) {
      try {
        const clean = candidates[0] || String(word || '').toLowerCase();
        const r = await fetch('/api/dict?w=' + encodeURIComponent(clean));
      if (r.ok) {
        const d = await r.json();
        if (d && (d.vi || (d.entries && d.entries.length))) {
          const firstEntry = (d.entries || [])[0] || {};
          const viList = [];
          if (d.vi) viList.push(d.vi);
          (firstEntry.vi_list || []).slice(0, 4).forEach((v) => {
            if (v && !viList.includes(v)) viList.push(v);
          });
          const enDefs = (firstEntry.senses || []).slice(0, 2).map((s) => s.def).filter(Boolean);
          const syns = (firstEntry.synonyms || []).slice(0, 5).map((w2) => ({ w: w2, vi: '' }));
          return {
            head: d.word || clean,
            pos: firstEntry.pos || 'Từ vựng Tiếng Anh',
            vi: viList,
            en: enDefs,
            entry: { ipa: d.ipa || '' },
            info: {
              read: d.ipa || '',
              level: 'B1',
              ex: sentence ? [{ s: sentence, vi: '' }] : [],
              col: [],
              syn: syns,
              ant: [],
              rel: [],
            },
            extra: '',
          };
        }
        }
      } catch {}
    }

    return {
      head: word,
      pos: 'Từ trong câu mẫu',
      vi: ['Bấm biểu tượng loa để luyện nghe phát âm chuẩn của từ này trong ngữ cảnh khách sạn 5 sao.'],
      en: [],
      entry: { ipa: '' },
      info: { read: '', level: '', ex: sentence ? [{ s: sentence, vi: '' }] : [], col: [], syn: [], ant: [], rel: [] },
      extra: '',
    };
  };

  SF.markLearned = function (zoneId, word, isKnown) {
    try {
      if (typeof updateSrs === 'function' && typeof WORDS === 'object') {
        const k = String(word || '').toLowerCase();
        const matchKey = Object.keys(WORDS).find((id) => id.toLowerCase() === k);
        if (matchKey) updateSrs(matchKey, Boolean(isKnown));
      }
      if (isKnown && typeof window.trackPractice === 'function') {
        window.trackPractice();
      }
      if (isKnown && typeof earn === 'function') {
        earn(5);
      }
    } catch {}
  };

  SF.api = async function (action, payload) {
    if (action === 'room_ping') {
      let profileName = '';
      try {
        const p = window.academyCurrentProfile?.();
        if (p?.name) profileName = p.name;
      } catch {}
      const r = await fetch('/api/room-ping', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          ...(payload || {}),
          clientId: getClientId(),
          guestName: profileName,
        }),
      });
      if (!r.ok) return null;
      return await r.json();
    }
    return null;
  };

  window.GrandSpeakRoomBridge = SF;

  // ==================== IN-APP VIEW ("room3d") ====================
  let immersiveRoom = false;

  function setImmersiveRoom(on) {
    immersiveRoom = Boolean(on);
    document.body?.classList.toggle('gs-room-immersive', immersiveRoom);
    const wrap = document.getElementById('gs-room-stage-wrap');
    if (wrap) wrap.classList.toggle('is-immersive', immersiveRoom);
    const btn = document.getElementById('gs-room-immersive-btn');
    if (btn) btn.innerHTML = immersiveRoom ? '✕ Thu về khung chuẩn' : '⛶ Mở rộng toàn màn hình';
    try {
      const ifr = document.getElementById('gs-room-iframe');
      ifr?.contentWindow?.postMessage({ type: 'gs-room-immersive-state', immersive: immersiveRoom }, '*');
    } catch {}
  }

  window.leaveFlashcardRoom = function () {
    setImmersiveRoom(false);
    SF.stopSpeak();
  };

  window.flashcardRoomScreen = function () {
    try {
      window.academyStopViSpeech?.();
    } catch {}
    return `
      <section class="gs-room-screen" aria-label="Phòng Học Flashcard 3D GrandSpeak">
        <div class="gs-room-headbar">
          <div class="gs-room-head-copy">
            <span class="gs-room-kicker">✦ GRANDSPEAK 3D TRAINING CLASSROOM · 20 BÀN HỌC · 5 KHUNG CẢNH</span>
            <h1>🏫 Phòng Học Flashcard 3D — 8 Khu Nghiệp Vụ 5★</h1>
          </div>
          <div class="gs-room-head-actions">
            <button type="button" class="btn btn-secondary btn-small" data-action="nav" data-view="resort3d">🏝️ Resort 3D</button>
            <button type="button" class="btn btn-secondary btn-small" data-action="nav" data-view="places3d">🗺️ Tình Huống 3D</button>
            <button type="button" class="btn btn-primary btn-small" id="gs-room-immersive-btn" data-gs-room-action="toggle-immersive">
              ${immersiveRoom ? '✕ Thu về khung chuẩn' : '⛶ Mở rộng toàn màn hình'}
            </button>
            <a class="btn btn-secondary btn-small" href="/flashcard/room/" target="_blank" rel="noopener">↗ Mở Tab Riêng</a>
          </div>
        </div>
        <div class="gs-room-stage-wrap ${immersiveRoom ? 'is-immersive' : ''}" id="gs-room-stage-wrap">
          <button type="button" class="gs-room-immersive-exit" data-gs-room-action="exit-immersive" title="Thoát chế độ toàn màn hình">← Quay về thanh công cụ GrandSpeak</button>
          <iframe
            id="gs-room-iframe"
            class="gs-room-frame"
            src="/room/room.html?embed=1"
            title="Phòng Học Flashcard 3D — GrandSpeak 5 Sao"
            allow="fullscreen; autoplay"
            allowfullscreen
          ></iframe>
        </div>
      </section>
    `;
  };

  document.addEventListener('click', (e) => {
    const btn = e.target.closest?.('[data-gs-room-action]');
    if (!btn) return;
    const act = btn.dataset.gsRoomAction;
    if (act === 'toggle-immersive') {
      setImmersiveRoom(!immersiveRoom);
    } else if (act === 'exit-immersive') {
      setImmersiveRoom(false);
    }
  });

  window.addEventListener('message', (ev) => {
    if (ev.origin !== window.location.origin) return;
    const d = ev.data;
    if (!d || typeof d !== 'object') return;
    if (d.type === 'gs-room-immersive-toggle') {
      setImmersiveRoom(!immersiveRoom);
    } else if (d.type === 'gs-room-go-places3d') {
      setImmersiveRoom(false);
      if (typeof state !== 'undefined' && typeof render === 'function') {
        state.view = 'places3d';
        render();
      }
    } else if (d.type === 'gs-room-go-resort3d') {
      setImmersiveRoom(false);
      if (typeof window.openFlashcardResortAt === 'function') window.openFlashcardResortAt(d.at || 'school', d.lang || '');
      if (typeof state !== 'undefined' && typeof render === 'function') {
        state.view = 'resort3d';
        render();
      }
    } else if (d.type === 'gs-room-go-app') {
      setImmersiveRoom(false);
      if (typeof state !== 'undefined' && typeof render === 'function') {
        state.view = 'home';
        render();
      }
    }
  });
})();
