/* ============================================================================
 * GRANDSPEAK 5★ — DỮ LIỆU THẾ GIỚI MỞ RESORT 3D (RESORT ISLAND DATA)
 * Tương ứng và nâng cấp từ Thành phố 3D (city.html) sang Đảo Nghỉ Dưỡng 5 Sao:
 *  - 16 Toà nhà & Điểm đến 3D (12 cửa vào thẳng Tình huống 3D + Học viện Phòng học 3D
 *    + Boutique Kiến trúc Villa & Thú cưng + Biệt thự Biển của tôi + Khu Tắm tráng 5★)
 *  - 6 Ngôn ngữ quốc tế (en, zh, ja, ko, fr, ru) & 6 Cấp độ CEFR (A1 → C2)
 *  - 34 Đồ vật 3D ngoài trời bấm học từ ngay trên đảo (RESORT_VOC)
 *  - Kho câu hỏi Kim cương 💎 / Đồng xu 🪙 / Trái tim ❤️ chuyên ngành Hospitality
 *  - Hệ thống Xây dựng & Trang trí Nội thất Biệt thự Biển 4 Cấp + Thú cưng Resort
 * ============================================================================ */
(function () {
  'use strict';

  window.RESORT_LANGS = {
    en: ['🇬🇧', 'Tiếng Anh 5★', 'en-US'],
    zh: ['🇨🇳', 'Tiếng Trung VIP', 'zh-CN'],
    ja: ['🇯🇵', 'Tiếng Nhật VIP', 'ja-JP'],
    ko: ['🇰🇷', 'Tiếng Hàn VIP', 'ko-KR'],
    fr: ['🇫🇷', 'Tiếng Pháp 5★', 'fr-FR'],
    ru: ['🇷🇺', 'Tiếng Nga Resort', 'ru-RU']
  };

  window.RESORT_LEVELS = [
    [1, 'Mới bắt đầu', 'A1'],
    [2, 'Sơ cấp', 'A2'],
    [3, 'Trung cấp', 'B1'],
    [4, 'Trung cao cấp', 'B2'],
    [5, 'Cao cấp', 'C1'],
    [6, 'Thành thạo 5★', 'C2']
  ];

  /* 16 Toà nhà & Khu vực kiến trúc trên Đảo Resort 3D (-90 .. +90)
     kind: 'place' (mở places.html?city=1&place=<k>) | 'room' (mở room.html?city=1) | 'shop' | 'home' | 'wc'
     door: hướng cửa ('s' = +Z, 'n' = -Z, 'e' = +X, 'w' = -X) */
  window.RESORT_PLACES = {
    lobby: {
      ic: '🏨', vi: 'Đại sảnh Lễ tân 5★', kind: 'place',
      x: 0, z: -18, w: 18, d: 12, h: 9.5, col: 0xfbf6ec, roof: 0x143628, acc: 0xd4a94e, door: 's', dome: true,
      names: { en: 'Grand Lobby 5★', zh: '五星大堂|Wǔxīng Dàtáng', ja: 'グランドロビー|Gurando Robī', ko: '그랜드 로비|Geuraendeu Robi', fr: 'Grand Hall 5★', ru: 'Гранд-лобби|Grand-lobbi' }
    },
    concierge: {
      ic: '🛎️', vi: 'VIP Concierge & Lounge', kind: 'place',
      x: -24, z: -18, w: 13, d: 10, h: 7.4, col: 0xf8f0df, roof: 0x78350f, acc: 0xf59e0b, door: 's',
      names: { en: 'VIP Concierge', zh: '金钥匙礼宾部|Jīnyàoshi Lǐbīnbù', ja: 'VIPコンシェルジュ|VIP Konsheruju', ko: 'VIP 컨시어지|VIP Keonsieoji', fr: 'Conciergerie d’Or', ru: 'VIP-консьерж|VIP-kons’yerzh' }
    },
    bell: {
      ic: '🧳', vi: 'Cổng Đón Xe & Hành lý Bell', kind: 'place',
      x: 24, z: -18, w: 13, d: 10, h: 7.2, col: 0xf4efe6, roof: 0x1e3a5f, acc: 0xd4a94e, door: 's',
      names: { en: 'Bell & Valet Gate', zh: '礼宾迎宾门|Lǐbīn Yíngbīnmén', ja: 'ベル＆バレー|Beru & Barē', ko: '벨 & 발레파킹|Bel & Ballepaking', fr: 'Porte-Cochère', ru: 'Служба багажа|Sluzhba bagazha' }
    },
    restaurant: {
      ic: '🍽️', vi: 'Nhà hàng Fine Dining Biển', kind: 'place',
      x: -26, z: 18, w: 15, d: 11, h: 7.6, col: 0xfff8ed, roof: 0x9a3412, acc: 0xfbbf24, door: 'n', awning: true,
      names: { en: 'Ocean Fine Dining', zh: '海景精致餐厅|Hǎijǐng Cāntīng', ja: 'ファインダイニング|Fain Dainingu', ko: '오션 파인다이닝|Osyeon Paindaining', fr: 'Restaurant Gastronomique', ru: 'Ресторан у моря|Restoran u morya' }
    },
    bar: {
      ic: '🍷', vi: 'Sky Bar, Hầm Rượu & Barista', kind: 'place',
      x: 26, z: 18, w: 15, d: 11, h: 7.8, col: 0xfdf2f8, roof: 0x581c87, acc: 0xf472b6, door: 'n', awning: true,
      names: { en: 'Wine Cellar & Sky Bar', zh: '侍酒师酒吧|Shìjiǔshī Jiǔbā', ja: 'ワイン＆スカイバー|Wain & Sukai Bā', ko: '와인 & 스카이바|Wain & Seukaiba', fr: 'Cave à Vin & Bar', ru: 'Винный скай-бар|Vinnyy skay-bar' }
    },
    kitchen: {
      ic: '👨‍🍳', vi: 'Bếp Nóng & Quầy Pass HACCP', kind: 'place',
      x: -54, z: 18, w: 14, d: 11, h: 7.4, col: 0xf1f5f9, roof: 0x991b1b, acc: 0xef4444, door: 'n',
      names: { en: 'Culinary Kitchen', zh: '五星中央厨房|Zhōngyāng Chúfáng', ja: 'メインキッチン|Mein Kitchin', ko: '메인 셰프 키친|Mein Syepeu Kichin', fr: 'Grande Cuisine', ru: 'Главная кухня|Glavnaya kukhnya' }
    },
    suite: {
      ic: '🛏️', vi: 'Presidential Suite & Butler', kind: 'place',
      x: -54, z: -18, w: 15, d: 11, h: 8.6, col: 0xfef9ee, roof: 0x1e3a8a, acc: 0xd4a94e, door: 's',
      names: { en: 'Presidential Suites', zh: '总统套房别墅|Zǒngtǒng Tàofáng', ja: 'プレジデンシャルスイート|Suīto', ko: '프레지덴셜 스위트|Seuwiteu', fr: 'Suite Présidentielle', ru: 'Президентский люкс|Prezidentskiy lyuks' }
    },
    spa: {
      ic: '🧖', vi: 'Serenity Spa & Hồ Vô cực', kind: 'place',
      x: 54, z: 18, w: 15, d: 11, h: 7.2, col: 0xecfdf5, roof: 0x0f766e, acc: 0x34d399, door: 'n', awning: true,
      names: { en: 'Serenity Spa & Pool', zh: '无边泳池水疗|Shuǐliáo Zhōngxīn', ja: 'セレニティスパ|Sereniti Supa', ko: '인피니티 스파|Inpiniti Seupa', fr: 'Spa & Piscine à Débordement', ru: 'Спа и инфинити-пул|Spa i infiniti-pul' }
    },
    pier: {
      ic: '⛴️', vi: 'Bến Du thuyền Sunset Marina', kind: 'place',
      x: 0, z: 58, w: 12, d: 8, h: 5.8, col: 0xeff6ff, roof: 0x0369a1, acc: 0x38bdf8, door: 'n',
      names: { en: 'Sunset Yacht Marina', zh: '日落游艇码头|Yóutǐng Mǎtóu', ja: 'サンセットマリーナ|Sansetto Marīna', ko: '선셋 요트 마리나|Seonset Yoteu Marina', fr: 'Port de Plaisance', ru: 'Яхтенная марина|Yakhtennaya marina' }
    },
    banquet: {
      ic: '🥂', vi: 'Cung Đại tiệc Gala & MICE', kind: 'place',
      x: 54, z: -18, w: 16, d: 12, h: 8.8, col: 0xfaf5ff, roof: 0x4c1d95, acc: 0xeab308, door: 's', dome: true,
      names: { en: 'Grand Ballroom & MICE', zh: '宴会与会议宫|Yànhuìtīng', ja: 'グランドボールルーム|Bōrurūmu', ko: '그랜드 볼룸 & MICE|Geuraendeu Bollum', fr: 'Salle de Gala', ru: 'Банкетный зал|Banketnyy zal' }
    },
    recovery: {
      ic: '🛡️', vi: 'Trung tâm Duty Manager (L.A.S.T.)', kind: 'place',
      x: -25, z: -52, w: 13, d: 10, h: 7.2, col: 0xfff1f2, roof: 0x881337, acc: 0xfb7185, door: 's',
      names: { en: 'Duty Manager Hub', zh: '值班经理中心|Zhíbān Jīnglǐ', ja: 'デューティマネージャー|Manējā', ko: '당직 지배인 센터|Dangjik Jibaein', fr: 'Direction de Garde', ru: 'Дежурный менеджер|Dezhurnyy menedzher' }
    },
    interview: {
      ic: '🤝', vi: 'Tuyển dụng 5★ & Họp Giao ban', kind: 'place',
      x: 25, z: -52, w: 13, d: 10, h: 7.2, col: 0xf0f9ff, roof: 0x1e40af, acc: 0x60a5fa, door: 's',
      names: { en: '5★ Talent & Briefing', zh: '人才招聘与例会|Róngcái ZhōngXīn', ja: '採用＆ブリーフィング|Saiyō Sentā', ko: '인재 채용 & 브리핑|Injae Chaeyong', fr: 'Talents & Briefing', ru: 'Отдел кадров 5★|Otdel kadrov' }
    },
    school: {
      ic: '🏫', vi: 'Học viện Phòng học 3D (20 Bàn)', kind: 'room',
      x: 0, z: -54, w: 17, d: 11, h: 8.8, col: 0xecfdf5, roof: 0x14532d, acc: 0xfacc15, door: 's',
      names: { en: 'GrandSpeak 3D Academy', zh: '五星培训学院|Péixùn Xuéyuàn', ja: 'ホスピタリティ学院|Gakuin', ko: '호스피탈리티 아카데미|Akademi', fr: 'Académie Hôtelière 3D', ru: 'Академия 3D|Akademiya 3D' }
    },
    store: {
      ic: '🛋️', vi: 'Boutique Nội thất & Nâng cấp Villa', kind: 'shop',
      x: -54, z: -52, w: 13, d: 10, h: 7.0, col: 0xfff7ed, roof: 0xc2410c, acc: 0xfbbf24, door: 's', awning: true,
      names: { en: 'Villa & Pet Boutique', zh: '别墅家居精品店|Biéshù Jīngpǐndiàn', ja: 'ヴィラ家具＆ペット|Vira Kagu', ko: '빌라 가구 & 펫 부티크|Billa Butikeu', fr: 'Boutique Villa & Animaux', ru: 'Бутик виллы|Butik villy' }
    },
    myhome: {
      ic: '🏡', vi: 'Biệt thự Biển của tôi', kind: 'home',
      x: 54, z: -52, w: 14, d: 11, h: 6.8, col: 0xfefce8, roof: 0x0f766e, acc: 0xf59e0b, door: 's', customHome: true,
      names: { en: 'My Private Villa', zh: '我的海景别墅|Wǒ de Biéshù', ja: 'マイ・プライベートヴィラ|Mai Vira', ko: '나의 프라이빗 빌라|Naui Billa', fr: 'Ma Villa Privée', ru: 'Моя вилла|Moya villa' }
    },
    wc: {
      ic: '🚿', vi: 'Khu Tắm tráng & Restroom 5★', kind: 'wc',
      x: 15, z: 43.5, w: 6.5, d: 5.5, h: 4.4, col: 0xe0f2fe, roof: 0x0284c7, acc: 0x38bdf8, door: 'n',
      names: { en: 'Beach Shower & Restroom', zh: '海滩淋浴与洗手间|Xǐshǒujiān', ja: 'ビーチシャワー＆化粧室|Keshōshitsu', ko: '비치 샤워 & 화장실|Hwajangsil', fr: 'Douches & Toilettes', ru: 'Душ и туалет|Dush i tualet' }
    }
  };

  /* 34 Đồ vật 3D ngoài trời trên Đảo Resort (bấm vào để hiện nghĩa & nghe đọc 6 thứ tiếng) */
  window.RESORT_VOC = {
    palm:        ['🌴', 'cây cọ dừa nhiệt đới', 'a palm tree|/pɑːm triː/', '棕榈树|zōnglǘshù', 'ヤシの木|yashi no ki', '야자수|yajasu', 'un palmier|/pal.mje/', 'пальма|pal’ma'],
    fountain:    ['⛲', 'đài phun nước đại sảnh', 'a resort fountain|/rɪˈzɔːrt ˈfaʊn.tən/', '度假村喷泉|pēnquán', '噴水|funsui', '리조트 분수|rijoteu bunsu', 'une fontaine|/fɔ̃.tɛn/', 'фонтан|fontan'],
    lounger:     ['🏖️', 'ghế dài tắm nắng bãi biển', 'a sun lounger|/sʌn ˈlaʊn.dʒɚ/', '沙滩躺椅|shātān tǎngyǐ', 'サンラウンジャー|san raunjā', '선베드|seonbedeu', 'une chaise longue|/ʃɛz lɔ̃ɡ/', 'шезлонг|shezlong'],
    parasol:     ['⛱️', 'dù che nắng bãi biển', 'a beach parasol|/biːtʃ ˈpær.ə.sɔːl/', '遮阳伞|zhēyángsǎn', 'ビーチパラソル|bīchi parasoru', '비치 파라솔|bichi parasol', 'un parasol|/pa.ʁa.sɔl/', 'пляжный зонт|plyazhnyy zont'],
    yacht:       ['🛥️', 'du thuyền 2 tầng hạng sang', 'a luxury yacht|/ˈlʌk.ʃɚ.i jɑːt/', '豪华游艇|háohuá yóutǐng', 'クルーザーヨット|kurūzā yotto', '럭셔리 요트|reoksyeori yoteu', 'un yacht de luxe|/jɔt/', 'роскошная яхта|roskoshnaya yakhta'],
    buggy:       ['🛺', 'xe điện Buggy đưa đón khách', 'an electric resort buggy|/rɪˈzɔːrt ˈbʌɡ.i/', '度假村电瓶车|diànpíngchē', 'リゾートバギー|rizōto bagī', '리조트 전동카트|jeondong kateu', 'une voiturette électrique|/vwa.ty.ʁɛt/', 'электрокар курорта|elektrokar'],
    limo:        ['🚘', 'xe Limousine đón sân bay', 'a hotel limousine|/hoʊˈtel ˈlɪm.ə.ziːn/', '礼宾轿车|lǐbīn jiàochē', 'ホテルリムジン|hoteru rimujin', '호텔 리무진|hotel rimujin', 'une limousine|/li.mu.zin/', 'лимузин отеля|limuzin'],
    bicycle:     ['🚲', 'xe đạp dạo biển miễn phí', 'a resort bicycle|/rɪˈzɔːrt ˈbaɪ.sɪ.kəl/', '度假村自行车|zìxíngchē', 'レンタサイクル|rentasaikuru', '리조트 자전거|jajeongeo', 'un vélo de plage|/ve.lo/', 'велосипед|velosiped'],
    pool:        ['🏊', 'hồ bơi vô cực hướng biển', 'an infinity pool|/ɪnˈfɪn.ə.t̬i puːl/', '无边际泳池|wúbiānjì yǒngchí', 'インフィニティプール|infiniti pūru', '인피니티 풀|inpiniti pul', 'une piscine à débordement|/pi.sin/', 'инфинити-бассейн|infiniti-basseyn'],
    cabana:      ['⛺', 'chòi nghỉ Cabana rèm lụa', 'an oceanfront cabana|/ˈoʊ.ʃən.frʌnt kəˈbæn.ə/', '海景凉亭|hǎijǐng liángtíng', 'ビーチカバナ|bīchi kabana', '오션 카바나|osyeon kabana', 'une cabana de plage|/ka.ba.na/', 'пляжная кабана|kabana'],
    lantern:     ['🏮', 'đèn lồng sân vườn Resort', 'a garden lantern|/ˈɡɑːr.dən ˈlæn.tɚn/', '花园灯笼|huāyuán dēnglóng', 'ガーデンランタン|gāden rantan', '가든 랜턴|gadeun raenteon', 'une lanterne|/lɑ̃.tɛʁn/', 'садовый фонарь|sadovyy fonar’'],
    lifebuoy:    ['🛟', 'phao cứu sinh bờ biển', 'a lifebuoy|/ˈlaɪf.bɔɪ/', '救生圈|jiùshēngquān', '救命浮輪|kyūmei ukiwa', '구명부환|gumyeongbuhwan', 'une bouée de sauvetage|/bwe/', 'спасательный круг|spasatel’nyy krug'],
    bench:       ['🪑', 'ghế nghỉ đại lộ cọ', 'a garden bench|/ˈɡɑːr.dən bentʃ/', '花园长椅|chángyǐ', 'ガーデンベンチ|gāden benchi', '정원 벤치|jeongwon benchi', 'un banc de jardin|/bɑ̃/', 'садовая скамейка|skameyka'],
    flowers:     ['🌺', 'bồn hoa dâm bụt nhiệt đới', 'tropical flowers|/ˈtrɑː.pɪ.kəl ˈflaʊ.ɚz/', '热带鲜花|rèdài xiānhuā', 'トロピカルフラワー|toropikaru furawā', '열대 꽃밭|yeoldae kkotbat', 'des fleurs tropicales|/flœʁ/', 'тропические цветы|tsvety'],
    portal:      ['🌀', 'cổng dịch chuyển tốc hành', 'a magic portal|/ˈmædʒ.ɪk ˈpɔːr.t̬əl/', '传送门|chuánsòngmén', 'ワープポータル|wāpu pōtaru', '순간이동 포털|poteol', 'un portail|/pɔʁ.taj/', 'портал|portal'],
    campfire:    ['🔥', 'lửa trại Đồi Hoàng Hôn', 'a beachside bonfire|/ˈbɑːn.faɪr/', '海景篝火|gōuhuǒ', '焚き火|takibi', '모닥불|modakbul', 'un feu de camp|/fø də kɑ̃/', 'костёр на холме|kostyor'],
    tent:        ['⛺', 'lều Glamping ngắm sao', 'a luxury glamping tent|/ˈɡlæm.pɪŋ tent/', '豪华露营帐篷|zhàngpeng', 'グランピングテント|guranpingu tento', '글램핑 텐트|geullaemping tenteu', 'une tente glamping|/tɑ̃t/', 'глэмпинг-шатер|shater'],
    telescope:   ['🔭', 'kính viễn vọng ngắm vịnh', 'an observation telescope|/ˈtel.ə.skoʊp/', '观景望远镜|wàngyuǎnjìng', '展望望遠鏡|bōenkyō', '전망 망원경|mangwongyeong', 'un télescope|/te.lɛs.kɔp/', 'телескоп|teleskop'],
    flamingo:    ['🦩', 'chim hồng hạc hồ sinh thái', 'a pink flamingo|/pɪŋk fləˈmɪŋ.ɡoʊ/', '火烈鸟|huǒlièniǎo', 'フラミンゴ|furamingo', '홍학|honghak', 'un flamant rose|/fla.mɑ̃/', 'фламинго|flamingo'],
    crab:        ['🦀', 'cua biển tinh nghịch', 'a beach crab|/biːtʃ kræb/', '沙滩螃蟹|pángxiè', 'ビーチクラブ|bīchi kurabu', '바닷게|badatge', 'un crabe de plage|/kʁab/', 'пляжный краб|krab'],
    guest:       ['🧳', 'du khách quốc tế lưu trú', 'an international guest|/ˌɪn.t̬ɚˈnæʃ.ən.əl ɡest/', '国际宾客|guójì bīnkè', '宿泊ゲスト|shukuhaku gesuto', '투숙객|tusukgaek', 'un client de l’hôtel|/kli.jɑ̃/', 'гость курорта|gost’'],
    surfboard:   ['🏄', 'ván lướt sóng thể thao biển', 'a surfboard|/ˈsɜːrf.bɔːrd/', '冲浪板|chōnglàngbǎn', 'サーフボード|sāfubōdo', '서핑보드|seopingbodeu', 'une planche de surf|/plɑ̃ʃ/', 'доска для сёрфинга|doska'],
    lighthouse:  ['🗼', 'ngọn hải đăng mũi đá', 'a coastal lighthouse|/ˈkoʊ.stəl ˈlaɪt.haʊs/', '海岸灯塔|dēngtǎ', '灯台|tōdai', '해안 등대|deungdae', 'un phare côtier|/faʁ/', 'маяк|mayak'],
    bridge:      ['🌉', 'cầu gỗ bắc qua hồ cảnh quan', 'a wooden lagoon bridge|/ləˈɡuːn brɪdʒ/', '泻湖木桥|mùqiáo', 'ラグーンの橋|ragūn no hashi', '라군 목조다리|mokjodari', 'un pont en bois|/pɔ̃/', 'деревянный мостик|mostik']
  };

  /* Bộ từ vựng 6 Cấp độ (CEFR 1..6) cho Kim cương 💎 & Đồng xu 🪙 trên Đảo Resort
     Mỗi mục: [level 1..6, icon, en, ipa, vi, exampleEn, exampleVi] */
  window.RESORT_DECK = [
    [1, '🛎️', 'check-in', '/ˈtʃek.ɪn/', 'thủ tục nhận phòng', 'Welcome! May I assist you with your check-in?', 'Chào mừng! Tôi hỗ trợ thủ tục nhận phòng cho quý khách nhé?'],
    [1, '🗝️', 'keycard', '/ˈkiː.kɑːrd/', 'thẻ từ mở cửa phòng', 'Here is your suite keycard on the eighth floor.', 'Đây là thẻ từ phòng Suite của quý khách trên tầng 8 ạ.'],
    [1, '🛂', 'passport', '/ˈpæs.pɔːrt/', 'hộ chiếu tùy thân', 'May I kindly see your passport, please?', 'Xin phép cho tôi mượn hộ chiếu của quý khách được không ạ?'],
    [1, '🧳', 'luggage', '/ˈlʌɡ.ɪdʒ/', 'hành lý của khách', 'Our bellman will bring your luggage to your villa.', 'Nhân viên hành lý sẽ chuyển vali về tận biệt thự cho quý khách.'],
    [1, '🥐', 'breakfast', '/ˈbrek.fəst/', 'bữa điểm tâm sáng', 'Breakfast is served from 6:30 to 10:30 a.m.', 'Bữa sáng phục vụ từ 6:30 đến 10:30 sáng ạ.'],
    [1, '🏖️', 'towel', '/ˈtaʊ.əl/', 'khăn tắm sạch', 'May I offer you a fresh pool towel?', 'Tôi gửi quý khách một chiếc khăn hồ bơi sạch mới nhé ạ?'],
    [1, '🍹', 'welcome drink', '/ˈwel.kəm drɪŋk/', 'thức uống chào mừng', 'Please enjoy this chilled lemongrass welcome drink.', 'Mời quý khách thưởng thức ly nước sả mát chào mừng ạ.'],
    [1, '🌊', 'ocean view', '/ˈoʊ.ʃən vjuː/', 'tầm nhìn hướng biển', 'Your balcony has a panoramic ocean view.', 'Ban công phòng mình có tầm nhìn toàn cảnh hướng biển ạ.'],

    [2, '📅', 'reservation', '/ˌrez.ɚˈveɪ.ʃən/', 'đơn đặt phòng / đặt bàn trước', 'I found your reservation for three nights.', 'Tôi đã tìm thấy đơn đặt phòng 3 đêm của quý khách.'],
    [2, '🍽️', 'appetizer', '/ˈæp.ə.taɪ.zɚ/', 'món khai vị đầu bữa', 'Would you like to start with a warm seafood appetizer?', 'Quý khách muốn mở đầu bằng món hải sản khai vị nóng không ạ?'],
    [2, '🍴', 'cutlery', '/ˈkʌt.lɚ.i/', 'bộ dao nĩa bàn tiệc', 'Allow me to bring fresh silver cutlery for your main course.', 'Xin phép thay bộ dao nĩa bạc mới cho món chính của quý khách.'],
    [2, '🚐', 'shuttle bus', '/ˈʃʌt.əl bʌs/', 'xe đưa đón theo lịch trình', 'The resort shuttle bus departs every twenty minutes.', 'Xe đưa đón của khu nghỉ dưỡng khởi hành mỗi 20 phút.'],
    [2, '🧴', 'amenities', '/əˈmen.ə.t̬iz/', 'bộ đồ tiện nghi phòng tắm', 'We replenished your botanical bath amenities.', 'Chúng tôi đã bổ sung đầy đủ bộ tiện nghi phòng tắm thảo mộc.'],
    [2, '☕', 'coffee break', '/ˈkɔː.fi breɪk/', 'tiệc trà bánh giải lao hội nghị', 'Pastries are served in the foyer during the coffee break.', 'Bánh ngọt được bày tại sảnh chờ trong giờ giải lao.'],
    [2, '🍹', 'mocktail', '/ˈmɑːk.teɪl/', 'cocktail trái cây không cồn', 'May I craft a passion-fruit mocktail for you?', 'Tôi pha cho quý khách một ly mocktail chanh dây không cồn nhé?'],
    [2, '🍳', 'steamed', '/stiːmd/', 'được hấp chín giữ vị ngọt', 'The sea bass is gently steamed with ginger.', 'Cá chẽm được hấp chín nhẹ nhàng cùng gừng tươi.'],

    [3, '🎁', 'complimentary', '/ˌkɑːm.pləˈmen.t̬ɚ.i/', 'miễn phí tặng kèm chuẩn 5 sao', 'Spa sauna access is complimentary during your stay.', 'Phòng xông hơi Spa được phục vụ miễn phí trong kỳ lưu trú ạ.'],
    [3, '💳', 'deposit', '/dɪˈpɑː.zɪt/', 'tiền đặt cọc chi phí phát sinh', 'May I take a card pre-authorization as an incidental deposit?', 'Xin phép giữ hạn mức thẻ làm cọc chi phí phát sinh nhé ạ?'],
    [3, '🥩', 'medium-rare', '/ˌmiː.di.əmˈrer/', 'độ chín tái vừa mềm mọng', 'Ribeye steak is most tender when grilled medium-rare.', 'Thăn lưng bò mềm mọng nhất khi nướng độ chín tái vừa.'],
    [3, '⚠️', 'allergy', '/ˈæl.ɚ.dʒi/', 'dị ứng thực phẩm', 'Do any guests at the table have food allergies?', 'Trên bàn mình có quý khách nào dị ứng thực phẩm không ạ?'],
    [3, '🛏️', 'turndown service', '/ˈtɜːrn.daʊn ˈsɜːr.vɪs/', 'chỉnh trang phòng buổi tối', 'Good evening! May I perform our turndown service?', 'Chào buổi tối! Xin phép thực hiện dịch vụ chỉnh trang giường tối ạ?'],
    [3, '🚘', 'chauffeur', '/ʃoʊˈfɜːr/', 'tài xế riêng phục vụ Limousine', 'Your private airport chauffeur is waiting outside.', 'Tài xế xe riêng đón tiễn sân bay đang chờ sẵn bên ngoài ạ.'],
    [3, '🙏', 'apologize', '/əˈpɑː.lə.dʒaɪz/', 'xin lỗi chân thành chuẩn 5 sao', 'I sincerely apologize for the wait; allow me to check now.', 'Tôi chân thành xin lỗi vì sự chờ đợi; để tôi kiểm tra ngay ạ.'],
    [3, '🔪', 'mise en place', '/ˌmiːz ɑːn ˈplɑːs/', 'chuẩn bị sơ chế sẵn sàng trước ca', 'Every station completed its mise en place before 5 p.m.', 'Mọi quầy bếp đã hoàn tất sơ chế chuẩn bị trước 17:00.'],

    [4, '🧾', 'guest folio', '/ɡest ˈfoʊ.li.oʊ/', 'bảng kê chi tiết chi phí lưu trú', 'Here is your itemized guest folio for review.', 'Đây là bảng kê chi tiết chi phí lưu trú để quý khách kiểm tra ạ.'],
    [4, '🍷', 'bouquet', '/buˈkeɪ/', 'tầng hương phức hợp của rượu vang', 'Swirl gently to appreciate the wine’s berry bouquet.', 'Lắc nhẹ ly để cảm nhận tầng hương quả mọng của rượu vang.'],
    [4, '💜', 'cross-contact', '/krɒs ˈkɒn.tækt/', 'nhiễm chéo tác nhân gây dị ứng', 'Purple utensils prevent any allergen cross-contact.', 'Bộ dụng cụ màu tím ngăn tuyệt đối nguy cơ nhiễm chéo dị ứng.'],
    [4, '🗺️', 'itinerary', '/aɪˈtɪn.ə.rer.i/', 'lịch trình tham quan cá nhân hoá', 'Our Concierge curated a sunset island itinerary for you.', 'Concierge đã thiết kế riêng lịch trình du ngoạn đảo hoàng hôn cho ngài.'],
    [4, '🛎️', 'cloche', '/kloʊʃ/', 'nắp chụp đĩa bạc phục vụ VIP', 'Servers lift the silver cloches in synchronized unison.', 'Đội ngũ phục vụ mở nắp chụp bạc đồng loạt cùng một nhịp.'],
    [4, '🛡️', 'service recovery', '/ˈsɜːr.vɪs rɪˈkʌv.ɚ.i/', 'khôi phục niềm tin sau sự cố', 'Thoughtful service recovery builds lasting guest loyalty.', 'Khôi phục dịch vụ tinh tế tạo dựng lòng trung thành bền vững.'],
    [4, '🌡️', 'core temperature', '/kɔːr ˈtem.prə.tʃɚ/', 'nhiệt độ tâm an toàn HACCP', 'Poultry must reach a core temperature of 74°C.', 'Thịt gia cầm phải đạt nhiệt độ tâm tối thiểu 74 độ C.'],
    [4, '💤', 'pillow menu', '/ˈpɪl.oʊ ˈmen.juː/', 'thực đơn chọn gối ngủ theo ý thích', 'Choose lavender or contour foam from our pillow menu.', 'Mời chọn gối oải hương hoặc cao su non từ thực đơn gối ngủ ạ.'],

    [5, '🏺', 'decant', '/dɪˈkænt/', 'gạn thở rượu vang trong bình pha lê', 'Allow me to decant this vintage Bordeaux for thirty minutes.', 'Xin phép gạn thở chai Bordeaux cổ điển này trong 30 phút ạ.'],
    [5, '🍽️', 'amuse-bouche', '/əˌmjuːzˈbuːʃ/', 'món quà khai vị nhỏ từ Bếp trưởng', 'Please enjoy this amuse-bouche with our Chef’s compliments.', 'Mời thưởng thức món khai vị nhỏ do Bếp trưởng gửi tặng ạ.'],
    [5, '💳', 'pre-authorization', '/ˌpriː.ɔː.θər.əˈzeɪ.ʃən/', 'tạm giữ hạn mức thẻ tín dụng', 'The pre-authorization hold is released upon check-out.', 'Khoản tạm giữ hạn mức thẻ sẽ giải toả ngay khi trả phòng.'],
    [5, '💧', 'hydrotherapy', '/ˌhaɪ.droʊˈθer.ə.pi/', 'liệu pháp thuỷ trị liệu khoáng ấm', 'Arrive early to enjoy our warm hydrotherapy pool.', 'Mời quý khách đến sớm tận hưởng hồ thuỷ trị liệu khoáng ấm.'],
    [5, '🤝', 'personal ownership', '/ˈpɜːr.sən.əl ˈoʊ.nɚ.ʃɪp/', 'nhận trách nhiệm theo dõi đến cùng', 'Let me take personal ownership of this request for you.', 'Xin để cá nhân tôi trực tiếp phụ trách yêu cầu này tới cùng cho ngài.'],
    [5, '🥣', 'emulsion', '/ɪˈmʌl.ʃən/', 'nhũ tương bơ trứng mịn mượt (xốt)', 'Whisk gently at 62°C to keep a silky butter emulsion.', 'Đánh nhẹ tay ở 62°C để giữ kết cấu nhũ tương bơ mịn mượt.'],

    [6, '👑', 'degustation', '/ˌdeɪ.ɡʊsˈteɪ.ʃən/', 'thực đơn thưởng thức nghệ thuật cao cấp', 'Our seven-course degustation celebrates coastal harvests.', 'Thực đơn thưởng thức 7 món tôn vinh sản vật biển tinh tuyển.'],
    [6, '⚜️', 'les clefs d’or', '/leɪ kleɪ dɔːr/', 'chuẩn Chìa Khoá Vàng Concierge quốc tế', 'Les Clefs d’Or concierges fulfill bespoke wishes discreetly.', 'Concierge Chìa Khoá Vàng đáp ứng mọi ước muốn tinh tế và kín đáo.'],
    [6, '🕊️', 'de-escalate', '/ˌdiːˈes.kə.leɪt/', 'hạ nhiệt khủng hoảng bằng sự thấu cảm', 'Empathetic listening helps de-escalate guest frustration.', 'Lắng nghe thấu cảm giúp xoa dịu nhanh chóng sự bức xúc của khách.'],
    [6, '🎩', 'bespoke butler', '/bɪˈspoʊk ˈbʌt.lɚ/', 'dịch vụ quản gia cá nhân hoá 24/7', 'Your bespoke butler will press your evening attire.', 'Quản gia riêng sẽ là phẳng trang phục dạ tiệc cho ngài.'],
    [6, '🥃', 'digestif', '/diː.ʒeˈstiːf/', 'rượu dùng sau bữa tối hỗ trợ tiêu hoá', 'Would you care for an aged Cognac digestif after dessert?', 'Ngài có muốn dùng một ly Cognac ủ lâu năm sau bữa tối không ạ?'],
    [6, '📋', 'banquet event order', '/ˈbæŋ.kwɪt ɪˈvent ˈɔːr.dɚ/', 'phiếu lệnh điều phối sự kiện (BEO)', 'Every department aligns timing strictly with the BEO.', 'Mọi bộ phận phối hợp kịch bản chuẩn từng phút theo lệnh BEO.']
  ];

  /* 4 Cấp Kiến trúc Biệt thự Biển & 16 Nội thất / Thú cưng trong Boutique (#hs / #hv) */
  window.RESORT_VILLA_STYLES = [
    { id: 'bungalow', ic: '🛖', vi: 'Garden Bungalow', sub: '1 tầng · ấm cúng giữa vườn cọ', cost: 0, floors: 1, col: 0xfef3c7, roof: 0x0f766e },
    { id: 'poolvilla', ic: '🏡', vi: 'Ocean Pool Villa', sub: '2 tầng · sân hiên & hồ bơi riêng', cost: 6, floors: 2, col: 0xfff7ed, roof: 0x1e3a8a },
    { id: 'overwater', ic: '🏝️', vi: 'Lagoon Overwater Villa', sub: '2 tầng · sàn gỗ ngọc bích sát biển', cost: 14, floors: 2, col: 0xecfeff, roof: 0x0369a1 },
    { id: 'palace', ic: '👑', vi: 'Presidential Beach Palace', sub: '3 tầng · mái vòm vàng kim đế vương', cost: 25, floors: 3, col: 0xfefce8, roof: 0x78350f }
  ];

  window.RESORT_SHOP_ITEMS = [
    /* Nội thất phòng Suite (furn) */
    { id: 'kingbed', cat: 'furn', ic: '🛏️', cost: 2, vi: 'Giường King Canopy 5★', en: 'king canopy bed|/kɪŋ ˈkæn.ə.pi bed/', x: -3.2, z: -2.6 },
    { id: 'sofa', cat: 'furn', ic: '🛋️', cost: 2, vi: 'Sofa Nhung Hoàng Gia', en: 'velvet lounge sofa|/ˈvel.vɪt ˈsoʊ.fə/', x: 2.8, z: -2.4 },
    { id: 'jacuzzi', cat: 'furn', ic: '🛁', cost: 3, vi: 'Bồn tắm Cẩm thạch Jacuzzi', en: 'marble jacuzzi tub|/ˈmɑːr.bəl dʒəˈkuː.zi/', x: -3.5, z: 2.2 },
    { id: 'espresso', cat: 'furn', ic: '☕', cost: 2, vi: 'Quầy Barista Espresso Ý', en: 'espresso bar station|/eˈspres.oʊ bɑːr/', x: 3.4, z: 2.2 },
    { id: 'winecellar', cat: 'furn', ic: '🍷', cost: 3, vi: 'Tủ Rượu Vang Sommelier', en: 'vintage wine cabinet|/waɪn ˈkæb.ɪ.nət/', x: 0, z: -3.8 },
    { id: 'piano', cat: 'furn', ic: '🎹', cost: 5, vi: 'Đại Dương Cầm Trắng', en: 'white grand piano|/ɡrænd piˈæn.oʊ/', x: 2.6, z: 0.2 },
    { id: 'orchid', cat: 'furn', ic: '🌸', cost: 1, vi: 'Bàn Trà Hoa Lan Trắng', en: 'white orchid table|/ˈɔːr.kɪd ˈteɪ.bəl/', x: 0, z: 0.4 },
    { id: 'chandelier', cat: 'furn', ic: '✨', cost: 4, vi: 'Đèn Chùm Pha Lê Vàng', en: 'crystal chandelier|/ˈkrɪs.təl ˌʃæn.dəˈlɪr/', x: -1.4, z: -0.2 },
    /* Sân vườn hướng biển (garden) */
    { id: 'cabana', cat: 'garden', ic: '🏖️', cost: 3, vi: 'Chòi Nghỉ Cabana Lụa', en: 'silk beach cabana|/biːtʃ kəˈbæn.ə/', x: -4.2, z: 4.0 },
    { id: 'bbq', cat: 'garden', ic: '🍖', cost: 3, vi: 'Bếp Nướng Hải Sản Sân Vườn', en: 'seafood teppanyaki grill|/ˈsiː.fuːd ɡrɪl/', x: 4.0, z: 4.0 },
    { id: 'fountain', cat: 'garden', ic: '⛲', cost: 4, vi: 'Tiểu Cảnh Thác Nước Đá', en: 'zen waterfall fountain|/ˈwɔː.t̬ɚ.fɔːl/', x: 0, z: 4.2 },
    { id: 'hammock', cat: 'garden', ic: '🌴', cost: 2, vi: 'Võng Đôi Dưới Tán Dừa', en: 'oceanfront hammock|/ˈhæm.ək/', x: -2.2, z: 4.1 },
    /* Thú cưng đồng hành tự đi dạo trong Villa (pet) */
    { id: 'retriever', cat: 'pet', ic: '🐕', cost: 4, vi: 'Cún Golden Retriever Hiếu Khách', en: 'golden retriever|/ˈɡoʊl.dən rɪˈtriː.vɚ/', petCol: 0xeab308 },
    { id: 'royalcat', cat: 'pet', ic: '🐈', cost: 3, vi: 'Mèo Ba Tư Tuyết Trắng', en: 'white Persian cat|/ˈpɜːr.ʒən kæt/', petCol: 0xf8fafc },
    { id: 'panda', cat: 'pet', ic: '🐼', cost: 5, vi: 'Gấu Trúc Nhỏ Đáng Yêu', en: 'baby panda|/ˈbeɪ.bi ˈpæn.də/', petCol: 0x1e293b },
    { id: 'flamingo', cat: 'pet', ic: '🦩', cost: 4, vi: 'Hồng Hạc Cảnh Resort', en: 'pink flamingo|/pɪŋk fləˈmɪŋ.ɡoʊ/', petCol: 0xf472b6 }
  ];

  /* Cụm từ tự động bật lên theo khoảnh khắc thực tế (#pm) */
  window.RESORT_MOMENTS = {
    sprint:  ['pick up the pace', 'tăng tốc bước nhanh khẩn trương', 'Let’s *pick up the pace* to greet our VIP arrival at the lobby!', 'Hãy bước nhanh hơn một chút để kịp đón đoàn khách VIP tại sảnh!', '🏃'],
    sit:     ['unwind by the sea', 'thư giãn nghỉ ngơi bên bờ biển', 'Please sit back and *unwind by the sea* with a chilled drink.', 'Mời quý khách ngả lưng thư giãn bên bờ biển cùng ly nước mát.', '🏖️'],
    stand:   ['back on duty', 'sẵn sàng quay lại ca phục vụ', 'Refreshed and *back on duty* with a warm five-star smile!', 'Tràn đầy năng lượng quay lại ca trực cùng nụ cười 5 sao ấm áp!', '✨'],
    jump:    ['hop right over', 'nhảy vượt qua nhẹ nhàng', 'Watch your step and *hop right over* the low garden hedge!', 'Chú ý bước chân và nhảy nhẹ qua hàng cây cảnh thấp nhé!', '🦘'],
    rain:    ['take shelter under the cabana', 'vào trú mưa dưới mái hiên / chòi nghỉ', 'It’s pouring tropical rain — let’s *take shelter under the cabana*!', 'Mưa rào nhiệt đới bất chợt rồi — mau vào trú dưới mái hiên thôi!', '🌧️'],
    clear:   ['the sky has cleared up', 'trời đã tạnh mưa và quang đãng', '*The sky has cleared up* — a rainbow is shining over the bay!', 'Trời đã tạnh mưa quang đãng — cầu vồng đang rực rỡ trên vịnh biển!', '🌈'],
    ride:    ['hop aboard the resort buggy', 'lên xe điện Buggy dạo quanh khu nghỉ dưỡng', '*Hop aboard the resort buggy* — allow me to give you an island tour!', 'Mời lên xe điện Buggy — xin phép đưa quý khách dạo một vòng quanh đảo!', '🛺'],
    crab:    ['watch out for beach crabs', 'coi chừng mấy chú cua biển kẹp chân', '*Watch out for beach crabs* scurrying along the boardwalk!', 'Coi chừng mấy chú cua biển đang bò ngang lối dạo ven biển nhé!', '🦀']
  };

  /* Hội thoại Trú mưa nhiệt đới (#rainCard) & Hỏi đường đi khu Tắm tráng (#wcAsk) & Chat Online (#mpChat) */
  window.RESORT_RAIN_PHRASES = [
    ['Allow me to escort you under an umbrella to the main lobby.', 'Xin phép để tôi che ô đưa quý khách về đại sảnh chính ạ.'],
    ['Sudden tropical showers pass quickly — may I offer you warm ginger tea?', 'Cơn mưa rào nhiệt đới sẽ tạnh nhanh thôi — mời quý khách dùng tách trà gừng ấm nhé ạ?'],
    ['Here is a dry fluffy towel for your comfort.', 'Xin gửi quý khách chiếc khăn bông khô ấm áp ạ.']
  ];

  window.RESORT_MP_PHRASES = [
    ['Good afternoon! Welcome to GrandSpeak Island Resort!', 'Chào buổi chiều! Chào mừng đến Đảo Resort GrandSpeak!'],
    ['Which hospitality department are you training in today?', 'Hôm nay bạn đang luyện nghiệp vụ bộ phận nào thế?'],
    ['Let’s head to the Ocean Fine Dining restaurant together!', 'Mình cùng ghé Nhà hàng Fine Dining hướng biển luyện hội thoại nhé!'],
    ['How many diamonds have you collected for your Beach Villa?', 'Bạn gom được bao nhiêu kim cương xây Biệt thự Biển rồi?'],
    ['Have a smooth and successful five-star shift!', 'Chúc bạn một ca trực 5 sao thật suôn sẻ và rực rỡ!']
  ];
})();
