// ============================================================================
// GRANDSPEAK STANDALONE ENGINE (100% Serverless / On-Device Backend & Speech)
// Runs completely on Phone (iOS TrollStore / Android APK) & PC without any server.
// ============================================================================
(function () {
  if (window.__grandSpeakStandaloneInstalled) return;
  window.__grandSpeakStandaloneInstalled = true;
  window.ACADEMY_STANDALONE = true;

  const DB_KEY = 'grandspeak_standalone_db_v1';
  const AUTH_CACHE_KEY = 'academy_auth_user_v2';
  const MOBILE_TOKEN_KEY = 'academy_mobile_token_v1';

  // Sync standalone DB to Native iOS UserDefaults / Android SharedPreferences when inside Native App
  function syncDbToNative(rawJson) {
    try {
      window.webkit?.messageHandlers?.native?.postMessage?.({ cmd: 'saveStandaloneDB', dbJson: rawJson });
    } catch {}
    try {
      window.AndroidNative?.postMessage?.(JSON.stringify({ cmd: 'saveStandaloneDB', dbJson: rawJson }));
    } catch {}
  }

  function simpleHash(str) {
    let h1 = 0xdeadbeef ^ str.length;
    let h2 = 0x41c6ce57 ^ str.length;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (h2 >>> 0).toString(16).padStart(8, '0') + (h1 >>> 0).toString(16).padStart(8, '0');
  }

  function makeHexToken() {
    const arr = new Uint8Array(32);
    if (window.crypto?.getRandomValues) {
      window.crypto.getRandomValues(arr);
    } else {
      for (let i = 0; i < 32; i++) arr[i] = Math.floor(Math.random() * 256);
    }
    return Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join('');
  }

  function createDefaultAdmin() {
    const now = new Date().toISOString();
    return {
      id: 'usr_owner_local',
      identifier: 'admin',
      name: 'Quản lý GrandSpeak',
      email: 'admin@grandspeak.vn',
      role: 'owner',
      status: 'active',
      areaId: 'exec_board',
      areaLabel: 'Ban Điều Hành & Quản Lý Cấp Cao',
      rankId: 'gm',
      rankTitle: 'Tổng Quản lý (General Manager - GM)',
      rankTier: 'exec',
      rankBadge: '👑 Cấp Điều Hành Cao Nhất',
      department: 'Supervisor',
      passwordHash: simpleHash('gs-salt:123456'),
      revision: 0,
      backup: null,
      createdAt: now,
      updatedAt: now,
    };
  }

  function defaultDb() {
    const admin = createDefaultAdmin();
    const defaultToken = 'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90';
    return {
      version: 1,
      users: [admin],
      sessions: { [defaultToken]: admin.id },
      activeUserId: admin.id,
      activeToken: defaultToken,
      otps: {},
      contentRecords: [],
      customLibrary: { sops: [], menus: [] },
      leaderboard: [
        { id: 'lb1', name: 'Minh Anh · Front Office', department: 'Front Office', game: 'all', score: 980, updatedAt: new Date().toISOString() },
        { id: 'lb2', name: 'Hoàng Nam · Fine Dining', department: 'Server', game: 'all', score: 920, updatedAt: new Date().toISOString() },
        { id: 'lb3', name: 'Thanh Trúc · Sommelier', department: 'Bar', game: 'all', score: 890, updatedAt: new Date().toISOString() },
      ],
      forumPosts: [
        {
          id: 'fp_welcome',
          author: 'Ban Đào Tạo 5 Sao',
          department: 'Supervisor',
          title: 'Chào mừng đến với GrandSpeak bản Độc lập (Offline-First)',
          body: 'Toàn bộ bài học, từ điển 1.000+ thuật ngữ, phòng luyện phát âm bằng Micro trực tiếp và Đảo Resort 3D đều hoạt động ngay trên thiết bị của bạn mà không cần máy chủ.',
          likes: 12,
          comments: [],
          createdAt: new Date().toISOString(),
        },
      ],
      communityMessages: [
        {
          id: 'cm_1',
          sender: 'GrandSpeak Coach',
          role: 'Supervisor',
          rankBadge: '👑 Ban Đào Tạo',
          text: 'Chúc bạn một ca học tập tràn đầy năng lượng! Nhấn nút Micro ở bất kỳ bài học nào để luyện phát âm trực tiếp trên thiết bị nhé.',
          createdAt: new Date().toISOString(),
        },
      ],
      sopReceipts: {},
      foodShifts: {},
      voicePrefs: { voice: 'alloy', speed: 1.0, accent: 'en-US' },
      companionScripts: {},
      lastRoleplay: null,
    };
  }

  function loadDb() {
    try {
      const raw = localStorage.getItem(DB_KEY) || window.__ACADEMY_NATIVE_RESTORED_DB || '';
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.users) && parsed.users.length > 0) {
          return parsed;
        }
      }
    } catch {}
    const fresh = defaultDb();
    saveDb(fresh);
    return fresh;
  }

  function saveDb(db) {
    try {
      const raw = JSON.stringify(db);
      localStorage.setItem(DB_KEY, raw);
      syncDbToNative(raw);
    } catch {}
  }

  // Auto-seed active session on very first launch so user enters the app seamlessly
  // (while still allowing Logout / Register / Switch Account at any time!)
  (function bootstrapFirstRunSession() {
    const db = loadDb();
    try {
      const hasExplicitLogout = sessionStorage.getItem('gs_explicit_logout') === '1';
      if (!hasExplicitLogout && db.activeUserId && !localStorage.getItem(AUTH_CACHE_KEY)) {
        const u = db.users.find((x) => x.id === db.activeUserId) || db.users[0];
        if (u) {
          const pub = publicUser(u);
          const tk = db.activeToken || makeHexToken();
          db.activeToken = tk;
          db.sessions[tk] = u.id;
          saveDb(db);
          localStorage.setItem(MOBILE_TOKEN_KEY, tk);
          localStorage.setItem(AUTH_CACHE_KEY, JSON.stringify(pub));
        }
      }
    } catch {}
  })();

  function publicUser(u) {
    if (!u) return null;
    const copy = { ...u };
    delete copy.passwordHash;
    delete copy.backup;
    return copy;
  }

  function getCurrentUser(db) {
    let token = '';
    try {
      token = localStorage.getItem(MOBILE_TOKEN_KEY) || '';
    } catch {}
    if (token && db.sessions && db.sessions[token]) {
      const found = db.users.find((x) => x.id === db.sessions[token]);
      if (found) return found;
    }
    if (db.activeUserId) {
      return db.users.find((x) => x.id === db.activeUserId) || null;
    }
    return null;
  }

  // =========================================================================
  // LOCAL PRONUNCIATION SCORER (Word-level & Ending-Consonant Analysis)
  // =========================================================================
  function cleanWords(text) {
    return String(text || '')
      .toLowerCase()
      .replace(/[^a-z0-9'\s]/g, ' ')
      .split(/\s+/)
      .filter(Boolean);
  }

  function editDistance(a, b) {
    const m = a.length;
    const n = b.length;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        dp[i][j] =
          a[i - 1] === b[j - 1]
            ? dp[i - 1][j - 1]
            : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
    }
    return dp[m][n];
  }

  window.gradeHospitalityPronunciation = function (targetText, heardText) {
    const target = cleanWords(targetText);
    const heard = cleanWords(heardText);
    if (!heard.length) {
      return {
        configured: true,
        score: 0,
        transcript: '',
        tip_vi: 'Chưa nghe rõ câu nói. Hãy giữ micro gần miệng hơn và đọc rõ từng từ nhé.',
      };
    }
    if (!target.length) {
      return {
        configured: true,
        score: 90,
        transcript: heardText,
        tip_vi: 'Giọng nói rõ ràng! Tiếp tục giữ nhịp điệu tự nhiên 5 sao.',
      };
    }
    let matched = 0;
    const missedEndings = [];
    for (const tw of target) {
      let best = 0;
      for (const hw of heard) {
        if (tw === hw) {
          best = 1;
          break;
        }
        const dist = editDistance(tw, hw);
        const sim = 1 - dist / Math.max(tw.length, hw.length, 1);
        if (sim > best) best = sim;
        if (sim >= 0.7 && /(s|ed|t|d|k|v|ce|se)$/.test(tw) && hw === tw.slice(0, -1)) {
          missedEndings.push(tw);
        }
      }
      matched += best >= 0.82 ? 1 : best >= 0.55 ? 0.65 : 0;
    }
    const rawScore = Math.round(Math.min(100, Math.max(15, (matched / target.length) * 100)));
    let tip = 'Phát âm chuẩn mực, phong thái rất tự tin!';
    if (missedEndings.length > 0) {
      tip = `Chú ý bật rõ âm cuối ở từ "${missedEndings[0]}" để câu nói sang trọng hơn.`;
    } else if (rawScore < 65) {
      tip = 'Hãy nghe lại câu mẫu ở tốc độ 0.75× và nhấn rõ các từ khóa chính trong câu.';
    } else if (rawScore < 85) {
      tip = 'Khá tốt! Hãy nối âm mượt hơn và giữ ngữ điệu trầm ấm cuối câu.';
    }
    return {
      configured: true,
      score: rawScore,
      transcript: String(heardText || '').trim(),
      tip_vi: tip,
    };
  };

  // Track most recent live SpeechRecognition transcript for MediaRecorder hybrid fallback
  window.__lastLiveSpeechTranscript = '';

  // =========================================================================
  // LOCAL OFFLINE DICTIONARY & HOSPITALITY AI COACH
  // =========================================================================
  function lookupOfflineWord(query) {
    const q = String(query || '').trim().toLowerCase();
    if (!q) return null;
    const allWords = [];
    if (Array.isArray(window.WORDS)) allWords.push(...window.WORDS);
    if (Array.isArray(window.MORE_WORDS)) allWords.push(...window.MORE_WORDS);
    if (Array.isArray(window.MEGA_LEXICON)) allWords.push(...window.MEGA_LEXICON);
    const hit =
      allWords.find((w) => String(w.id || w.term || w.en || '').toLowerCase() === q) ||
      allWords.find((w) => String(w.id || w.term || w.en || '').toLowerCase().includes(q));
    if (hit) {
      return {
        ok: true,
        word: hit.id || hit.term || hit.en || query,
        entry: {
          word: hit.id || hit.term || hit.en || query,
          ipa: hit.ipa || hit.pron || '',
          pos: hit.pos || 'hospitality term',
          vi: hit.vi || hit.meaning || '',
          definitions: [hit.context || hit.example || hit.chunk || hit.vi || 'Thuật ngữ chuyên ngành Khách sạn – Resort 5 sao.'],
          examples: [hit.chunk || hit.example || ''].filter(Boolean),
          audioUs: '',
          audioUk: '',
        },
      };
    }
    return {
      ok: true,
      word: query,
      entry: {
        word: query,
        ipa: '',
        pos: 'expression',
        vi: 'Bấm biểu tượng Loa để nghe phát âm trực tiếp trên thiết bị',
        definitions: ['Từ/cụm từ tiếng Anh giao tiếp trong môi trường dịch vụ khách sạn.'],
        examples: [],
        audioUs: '',
        audioUk: '',
      },
    };
  }

  async function callDirectGeminiOrLocalCoach(task, text, userKey, messages) {
    const cleanKey = String(userKey || localStorage.getItem('gs_personal_gemini_key') || '').trim();
    if (cleanKey) {
      try {
        localStorage.setItem('gs_personal_gemini_key', cleanKey);
        const promptText = messages
          ? messages.map((m) => `${m.role === 'user' ? 'Staff' : 'Coach'}: ${m.content || m.text || ''}`).join('\n')
          : `You are a 5-Star Luxury Hotel English Coach for Vietnamese staff. Task: ${task || 'coach'}. Input: ${text}. Reply concisely in bilingual English + Vietnamese.`;
        const r = await nativeFetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(cleanKey)}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contents: [{ parts: [{ text: promptText }] }] }),
          }
        );
        if (r.ok) {
          const d = await r.json();
          const out = d?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
          if (out.trim()) return out.trim();
        }
      } catch {}
    }
    // Instant Built-in Offline 5-Star Hospitality Coach
    const sample = String(text || (messages?.[messages.length - 1]?.content) || '').trim();
    const polite = sample
      ? sample
          .replace(/\bcan you\b/gi, 'Could you kindly')
          .replace(/\bwait\b/gi, 'allow me just a moment')
          .replace(/\bi want\b/gi, 'I would be delighted to')
          .replace(/\bno\b/gi, 'I am afraid at the moment')
      : 'Certainly, right away. It would be my pleasure to assist you.';
    return [
      '✨ **Gợi ý Chuẩn Dịch Vụ 5 Sao (Chế độ Độc lập trên thiết bị):**',
      `- **Câu nâng cấp lịch thiệp:** *"Certainly. ${polite.charAt(0).toUpperCase() + polite.slice(1)}"*`,
      '- **Mẫu câu thay thế sang trọng:** *"Allow me a moment to check this personally for you, Madam/Sir."*',
      '- **Mẹo phát âm:** Nhấn nhẹ vào từ *Certainly* và hạ giọng ấm áp ở cuối câu; bấm nút **Micro** để luyện đọc trực tiếp.',
    ].join('\n');
  }

  // =========================================================================
  // JSON RESPONSE HELPER & COMPLETE /api/* ROUTER
  // =========================================================================
  function jsonRes(obj, status = 200) {
    return new Response(JSON.stringify(obj), {
      status,
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
    });
  }

  function parseBody(init) {
    if (!init || !init.body) return {};
    if (typeof init.body === 'string') {
      try {
        return JSON.parse(init.body);
      } catch {
        return {};
      }
    }
    return {};
  }

  async function handleLocalApi(urlObj, init = {}) {
    const pathname = urlObj.pathname;
    const method = String(init.method || 'GET').toUpperCase();
    const body = parseBody(init);
    const db = loadDb();

    // 1. Health
    if (pathname === '/api/health') {
      return jsonRes({ ok: true, standalone: true, mode: 'on-device' });
    }

    // 2. Authentication & Local Staff Accounts (/api/auth)
    if (pathname === '/api/auth') {
      if (method === 'GET') {
        const u = getCurrentUser(db);
        return jsonRes({
          authenticated: Boolean(u && u.status !== 'paused'),
          paused: Boolean(u && u.status === 'paused'),
          user: publicUser(u),
          sessionsCount: u ? 1 : 0,
          ownerNeedsSetup: false,
          ownerIdentifier: 'admin',
          isLoopback: true,
          smtpConfigured: true,
          smtpUser: 'che-do-doc-lap@grandspeak.local',
          recentEmails: [],
        });
      }

      const action = body.action || '';
      if (action === 'register' || action === 'setup-owner') {
        const identifier = String(body.identifier || 'nv001').trim().toLowerCase();
        const email = String(body.email || `${identifier}@grandspeak.local`).trim().toLowerCase();
        const exists = db.users.find(
          (x) => x.identifier.toLowerCase() === identifier || (email && x.email?.toLowerCase() === email)
        );
        if (exists && action === 'register') {
          return jsonRes(
            { message: `Mã đăng nhập hoặc Email "${identifier}" đã tồn tại trên thiết bị này. Hãy chuyển sang Đăng nhập!` },
            409
          );
        }
        const now = new Date().toISOString();
        const newUser = {
          id: 'usr_' + Date.now().toString(36),
          identifier,
          name: String(body.name || identifier).trim(),
          email,
          role: action === 'setup-owner' || db.users.length === 0 ? 'owner' : 'admin',
          status: 'active',
          areaId: body.areaId || 'restaurant',
          areaLabel: body.areaLabel || 'Nhà Hàng & Ẩm Thực',
          rankId: body.rankId || 'waiter',
          rankTitle: body.rankTitle || 'Nhân viên Phục vụ Nhà hàng',
          rankTier: body.rankTier || 'staff',
          rankBadge: body.rankBadge || '🛡️ Cấp Nhân Viên Chính Thức',
          department: body.department || 'Server',
          passwordHash: simpleHash('gs-salt:' + String(body.password || '1234')),
          revision: 0,
          backup: null,
          createdAt: now,
          updatedAt: now,
        };
        if (exists && action === 'setup-owner') {
          Object.assign(exists, newUser, { id: exists.id });
        } else {
          db.users.push(newUser);
        }
        saveDb(db);
        return jsonRes({
          ok: true,
          registeredIdentifier: identifier,
          message: `✅ Đã tạo hồ sơ "${newUser.name}" (${newUser.rankBadge}) ngay trên thiết bị! Hãy nhập mật khẩu để đăng nhập.`,
          mailPreview: {
            to: email,
            subject: 'Chào mừng gia nhập Học viện GrandSpeak 5 Sao',
            delivery: 'local-device',
            html: `<div style="padding:14px;font-family:sans-serif"><strong>Xin chào ${newUser.name}!</strong><p>Hồ sơ <b>${identifier}</b> (${newUser.rankTitle}) đã được lưu an toàn trên thiết bị của bạn.</p></div>`,
          },
        });
      }

      if (action === 'login') {
        const idRaw = String(body.identifier || '').trim().toLowerCase();
        const pwd = String(body.password || '');
        const u = db.users.find(
          (x) => x.identifier.toLowerCase() === idRaw || (x.email && x.email.toLowerCase() === idRaw)
        );
        if (!u) {
          return jsonRes(
            { message: 'Chưa tìm thấy tài khoản này trên thiết bị (Tài khoản mặc định: admin / 123456, hoặc bấm Đăng ký hồ sơ mới).' },
            401
          );
        }
        if (u.passwordHash !== simpleHash('gs-salt:' + pwd)) {
          return jsonRes({ message: 'Mật khẩu chưa đúng. (Nếu dùng tài khoản admin mặc định, mật khẩu là 123456).' }, 401);
        }
        const token = makeHexToken();
        db.sessions[token] = u.id;
        db.activeUserId = u.id;
        db.activeToken = token;
        saveDb(db);
        try {
          sessionStorage.removeItem('gs_explicit_logout');
        } catch {}
        return jsonRes({
          ok: true,
          authenticated: true,
          sessionToken: token,
          sessionsCount: 1,
          user: publicUser(u),
        });
      }

      if (action === 'request-otp') {
        const idRaw = String(body.identifier || body.email || '').trim().toLowerCase();
        const u =
          db.users.find((x) => x.identifier.toLowerCase() === idRaw || (x.email && x.email.toLowerCase() === idRaw)) ||
          db.users[0];
        const code = String(Math.floor(100000 + Math.random() * 900000));
        db.otps[u.identifier.toLowerCase()] = { code, expiresAt: Date.now() + 10 * 60 * 1000 };
        saveDb(db);
        return jsonRes({
          ok: true,
          identifier: u.identifier,
          maskedEmail: u.email || 'thiet-bi-cuc-bo',
          cooldownSec: 5,
          expiresAt: Date.now() + 10 * 60 * 1000,
          message: `🔑 Mã xác nhận đặt lại mật khẩu trên thiết bị của bạn là: ${code}`,
          mailPreview: {
            to: u.email || u.identifier,
            subject: `Mã OTP đặt lại mật khẩu: ${code}`,
            delivery: 'local-device',
            html: `<div style="padding:14px;font-family:sans-serif">Mã xác nhận 6 chữ số của bạn là: <strong style="font-size:22px;letter-spacing:3px;color:#0f472d">${code}</strong></div>`,
          },
        });
      }

      if (action === 'verify-otp-reset') {
        const idRaw = String(body.identifier || '').trim().toLowerCase();
        const u = db.users.find((x) => x.identifier.toLowerCase() === idRaw) || getCurrentUser(db) || db.users[0];
        const savedOtp = db.otps[u.identifier.toLowerCase()];
        if (savedOtp && savedOtp.code !== String(body.otpCode || '').trim()) {
          return jsonRes({ message: 'Mã xác nhận 6 số chưa khớp. Hãy kiểm tra mã hiển thị ngay phía trên.' }, 400);
        }
        u.passwordHash = simpleHash('gs-salt:' + String(body.newPassword || '123456'));
        u.updatedAt = new Date().toISOString();
        delete db.otps[u.identifier.toLowerCase()];
        saveDb(db);
        return jsonRes({
          ok: true,
          identifier: u.identifier,
          sessionsCount: 1,
          message: '✅ Đã cập nhật mật khẩu mới ngay trên thiết bị!',
        });
      }

      if (action === 'update-profile') {
        const u = getCurrentUser(db) || db.users[0];
        if (body.name) u.name = String(body.name).trim();
        if (body.email) u.email = String(body.email).trim();
        for (const k of ['areaId', 'areaLabel', 'rankId', 'rankTitle', 'rankTier', 'rankBadge', 'department']) {
          if (body[k]) u[k] = body[k];
        }
        u.updatedAt = new Date().toISOString();
        saveDb(db);
        return jsonRes({ ok: true, user: publicUser(u) });
      }

      if (action === 'logout') {
        db.activeUserId = '';
        db.activeToken = '';
        db.sessions = {};
        saveDb(db);
        try {
          sessionStorage.setItem('gs_explicit_logout', '1');
        } catch {}
        return jsonRes({ ok: true });
      }

      return jsonRes({ ok: true, sessionsCount: 1 });
    }

    // 3. Member Progress Backup (/api/member & /api/members)
    if (pathname === '/api/member') {
      const u = getCurrentUser(db) || db.users[0];
      if (method === 'GET') {
        return jsonRes({
          ok: true,
          revision: u?.revision || 0,
          updatedAt: u?.updatedAt || new Date().toISOString(),
          backup: u?.backup || { version: 1, exportedAt: new Date().toISOString(), data: {} },
        });
      }
      if (body.action === 'delete') {
        if (u) {
          u.backup = null;
          u.revision = 0;
          saveDb(db);
        }
        return jsonRes({ ok: true, revision: 0 });
      }
      if (u) {
        u.revision = (Number(u.revision) || 0) + 1;
        u.updatedAt = new Date().toISOString();
        u.backup = body.backup || null;
        saveDb(db);
      }
      return jsonRes({ ok: true, revision: u?.revision || 1, updatedAt: u?.updatedAt });
    }

    if (pathname === '/api/members') {
      return jsonRes({
        ok: true,
        members: db.users.map((u) => publicUser(u)),
      });
    }

    // 4. Local Pronunciation Grader (/api/pronunciation)
    if (pathname === '/api/pronunciation') {
      const heard = body.transcript || window.__lastLiveSpeechTranscript || '';
      if (heard) {
        window.__lastLiveSpeechTranscript = '';
        return jsonRes(window.gradeHospitalityPronunciation(body.targetText || '', heard));
      }
      return jsonRes({
        configured: false,
        score: 0,
        transcript: '',
        tip_vi: 'Đã ghi âm thành công trên thiết bị! Hãy nghe lại bản thu để đối chiếu ngữ điệu câu mẫu.',
      });
    }

    // 5. Content & Custom Studio (/api/content, /api/logo, /api/custom-library)
    if (pathname === '/api/content') {
      if (method === 'GET') {
        const u = getCurrentUser(db);
        return jsonRes({
          ok: true,
          isAdmin: Boolean(u && ['owner', 'admin'].includes(u.role)),
          adminRole: u?.role || 'owner',
          records: db.contentRecords || [],
        });
      }
      if (method === 'DELETE') {
        db.contentRecords = (db.contentRecords || []).filter((r) => !(r.kind === body.kind && r.id === body.id));
        saveDb(db);
        return jsonRes({ ok: true });
      }
      const now = new Date().toISOString();
      const idx = (db.contentRecords || []).findIndex((r) => r.kind === body.kind && r.id === body.id);
      const rec = { kind: body.kind, id: body.id, value: body.value, updatedAt: now };
      if (idx >= 0) db.contentRecords[idx] = rec;
      else db.contentRecords.push(rec);
      saveDb(db);
      return jsonRes({ ok: true, updatedAt: now });
    }

    if (pathname === '/api/custom-library') {
      if (method === 'GET') return jsonRes({ ok: true, ...(db.customLibrary || { sops: [], menus: [] }) });
      db.customLibrary = {
        sops: Array.isArray(body.sops) ? body.sops : db.customLibrary?.sops || [],
        menus: Array.isArray(body.menus) ? body.menus : db.customLibrary?.menus || [],
      };
      saveDb(db);
      return jsonRes({ ok: true, ...db.customLibrary });
    }

    // 6. Dictionary (/api/dict)
    if (pathname === '/api/dict') {
      const q = urlObj.searchParams.get('word') || urlObj.searchParams.get('q') || '';
      return jsonRes(lookupOfflineWord(q));
    }

    // 7. AI Tools & Chat (/api/ai-tools, /api/chat, /api/voice, /api/gemini)
    if (pathname === '/api/ai-tools') {
      if (method === 'GET') return jsonRes({ ok: true, configured: true, standalone: true });
      const result = await callDirectGeminiOrLocalCoach(body.task, body.text, body.key, null);
      return jsonRes({ ok: true, configured: true, result });
    }

    if (pathname === '/api/chat') {
      if (method === 'GET') return jsonRes({ ok: true, configured: true, standalone: true });
      const reply = await callDirectGeminiOrLocalCoach('roleplay-chat', '', body.key, body.messages || []);
      return jsonRes({ ok: true, configured: true, reply, message: reply });
    }

    if (pathname === '/api/voice' || pathname === '/api/gemini') {
      return jsonRes({ ok: true, configured: false, standalone: true });
    }

    // 8. Leaderboard, Forum, Community Chat, Shifts, SOP Receipts, Room Ping
    if (pathname === '/api/games-leaderboard') {
      if (method === 'POST' && body.score) {
        const u = getCurrentUser(db);
        db.leaderboard.unshift({
          id: 'lb_' + Date.now(),
          name: body.name || u?.name || 'Nhân viên 5★',
          department: body.department || u?.department || 'Server',
          game: body.game || 'all',
          score: Number(body.score) || 0,
          updatedAt: new Date().toISOString(),
        });
        db.leaderboard.sort((a, b) => b.score - a.score);
        db.leaderboard = db.leaderboard.slice(0, 30);
        saveDb(db);
      }
      return jsonRes({ ok: true, entries: db.leaderboard, leaderboard: db.leaderboard });
    }

    if (pathname === '/api/community-chat') {
      if (method === 'POST' && body.text) {
        const u = getCurrentUser(db);
        db.communityMessages.push({
          id: 'cm_' + Date.now(),
          sender: u?.name || 'Nhân viên 5★',
          role: u?.department || 'Server',
          rankBadge: u?.rankBadge || '🛡️ Nhân viên',
          text: String(body.text).slice(0, 500),
          createdAt: new Date().toISOString(),
        });
        db.communityMessages = db.communityMessages.slice(-80);
        saveDb(db);
      }
      return jsonRes({ ok: true, messages: db.communityMessages, onlineCount: 1 });
    }

    if (pathname === '/api/forum') {
      if (method === 'POST' && body.title) {
        const u = getCurrentUser(db);
        db.forumPosts.unshift({
          id: 'fp_' + Date.now(),
          author: u?.name || 'Thành viên GrandSpeak',
          department: u?.department || 'Server',
          title: String(body.title).slice(0, 160),
          body: String(body.body || body.content || '').slice(0, 2000),
          likes: 1,
          comments: [],
          createdAt: new Date().toISOString(),
        });
        saveDb(db);
      }
      return jsonRes({ ok: true, posts: db.forumPosts });
    }

    if (pathname === '/api/voice-preferences') {
      if (method === 'POST') {
        db.voicePrefs = { ...db.voicePrefs, ...body };
        saveDb(db);
      }
      return jsonRes({ ok: true, preferences: db.voicePrefs, ...db.voicePrefs });
    }

    if (pathname === '/api/companion-scripts') {
      if (method === 'POST') {
        db.companionScripts = { ...db.companionScripts, ...body };
        saveDb(db);
      }
      return jsonRes({ ok: true, scripts: db.companionScripts });
    }

    if (pathname === '/api/sop-receipts') {
      const sopId = urlObj.searchParams.get('id') || body.id || 'default';
      if (method === 'POST') {
        db.sopReceipts[sopId] = { accepted: true, acceptedAt: new Date().toISOString() };
        saveDb(db);
      }
      return jsonRes({ ok: true, receipt: db.sopReceipts[sopId] || null, receipts: db.sopReceipts });
    }

    if (pathname === '/api/food-shifts') {
      const shiftId = urlObj.searchParams.get('id') || body.id || 'local-shift';
      if (method === 'POST') {
        db.foodShifts[shiftId] = { ...(db.foodShifts[shiftId] || {}), ...body, id: shiftId, updatedAt: new Date().toISOString() };
        saveDb(db);
      }
      return jsonRes({ ok: true, shift: db.foodShifts[shiftId] || null });
    }

    if (pathname === '/api/last-roleplay') {
      if (method === 'POST') {
        db.lastRoleplay = body;
        saveDb(db);
      }
      return jsonRes({ ok: true, roleplay: db.lastRoleplay });
    }

    if (pathname === '/api/room-ping') {
      return jsonRes({ ok: true, peers: [], count: 1 });
    }

    if (pathname === '/api/donation' || pathname === '/api/flc-sop') {
      return jsonRes({ ok: true, items: [], documents: [] });
    }

    return jsonRes({ ok: true, standalone: true });
  }

  // Intercept all /api/* calls locally so ZERO server is ever needed!
  const nativeFetch = window.fetch.bind(window);
  window.fetch = function (input, init = {}) {
    try {
      const rawUrl = typeof input === 'string' ? input : input?.url || '';
      const resolved = new URL(rawUrl, window.location.origin && window.location.origin !== 'null' ? window.location.origin : 'http://127.0.0.1');
      if (resolved.pathname.startsWith('/api/')) {
        return handleLocalApi(resolved, init);
      }
    } catch {}
    return nativeFetch(input, init);
  };

  // Capture transcripts from any SpeechRecognition instance so hybrid MediaRecorder grading works offline
  const BaseSR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (BaseSR && !BaseSR.__gsWrapped) {
    const OrigProtoStart = BaseSR.prototype?.start;
    if (typeof OrigProtoStart === 'function') {
      BaseSR.prototype.start = function (...args) {
        this.addEventListener?.('result', (ev) => {
          try {
            const txt = Array.from(ev.results || [])
              .map((r) => r?.[0]?.transcript || '')
              .join(' ')
              .trim();
            if (txt) window.__lastLiveSpeechTranscript = txt;
          } catch {}
        });
        return OrigProtoStart.apply(this, args);
      };
      BaseSR.__gsWrapped = true;
    }
  }
})();
