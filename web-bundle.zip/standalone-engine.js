// ============================================================================
// GRANDSPEAK STANDALONE ENGINE (100% Serverless / On-Device Backend & Speech)
// Runs completely on Phone (iOS TrollStore / Android APK) & PC without any server.
// ============================================================================
(function () {
  if (window.__grandSpeakStandaloneInstalled) return;
  window.__grandSpeakStandaloneInstalled = true;
  window.ACADEMY_STANDALONE = true;

  const DB_KEY = 'grandspeak_standalone_db_v1';
  const AUTH_CACHE_KEY = 'academy_auth_user_v2';
  const MOBILE_TOKEN_KEY = 'academy_mobile_token_v1';

  // Sync standalone DB to Native iOS UserDefaults / Android SharedPreferences when inside Native App
  function syncDbToNative(rawJson) {
    try {
      window.webkit?.messageHandlers?.native?.postMessage?.({ cmd: 'saveStandaloneDB', dbJson: rawJson });
    } catch {}
    try {
      window.AndroidNative?.postMessage?.(JSON.stringify({ cmd: 'saveStandaloneDB', dbJson: rawJson }));
    } catch {}
  }

  function simpleHash(str) {
    let h1 = 0xdeadbeef ^ str.length;
    let h2 = 0x41c6ce57 ^ str.length;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (h2 >>> 0).toString(16).padStart(8, '0') + (h1 >>> 0).toString(16).padStart(8, '0');
  }

  function makeHexToken() {
    const arr = new Uint8Array(32);
    if (window.crypto?.getRandomValues) {
      window.crypto.getRandomValues(arr);
    } else {
      for (let i = 0; i < 32; i++) arr[i] = Math.floor(Math.random() * 256);
    }
    return Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join('');
  }

  function createDefaultAdmin() {
    const now = new Date().toISOString();
    return {
      id: 'usr_owner_local',
      identifier: 'admin',
      name: 'Quản lý GrandSpeak',
      email: 'admin@grandspeak.vn',
      role: 'owner',
      status: 'active',
      areaId: 'exec_board',
      areaLabel: 'Ban Điều Hành & Quản Lý Cấp Cao',
      rankId: 'gm',
      rankTitle: 'Tổng Quản lý (General Manager - GM)',
      rankTier: 'exec',
      rankBadge: '👑 Cấp Điều Hành Cao Nhất',
      department: 'Supervisor',
      passwordHash: simpleHash('gs-salt:123456'),
      revision: 0,
      backup: null,
      createdAt: now,
      updatedAt: now,
    };
  }

  function defaultDb() {
    const admin = createDefaultAdmin();
    const defaultToken = 'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90';
    return {
      version: 1,
      users: [admin],
      sessions: { [defaultToken]: admin.id },
      activeUserId: admin.id,
      activeToken: defaultToken,
      otps: {},
      contentRecords: [],
      customLibrary: { sops: [], menus: [] },
      leaderboard: [
        { id: 'lb1', name: 'Minh Anh · Front Office', department: 'Front Office', game: 'all', score: 980, updatedAt: new Date().toISOString() },
        { id: 'lb2', name: 'Hoàng Nam · Fine Dining', department: 'Server', game: 'all', score: 920, updatedAt: new Date().toISOString() },
        { id: 'lb3', name: 'Thanh Trúc · Sommelier', department: 'Bar', game: 'all', score: 890, updatedAt: new Date().toISOString() },
      ],
      forumPosts: [
        {
          id: 'fp_welcome',
          author: 'Ban Đào Tạo 5 Sao',
          department: 'Supervisor',
          title: 'Chào mừng đến với GrandSpeak bản Độc lập (Offline-First)',
          body: 'Toàn bộ bài học, từ điển 1.000+ thuật ngữ, phòng luyện phát âm bằng Micro trực tiếp và Đảo Resort 3D đều hoạt động ngay trên thiết bị của bạn mà không cần máy chủ.',
          likes: 12,
          comments: [],
          createdAt: new Date().toISOString(),
        },
      ],
      communityMessages: [
        {
          id: 'cm_1',
          author: 'Ban Đào Tạo GrandSpeak 5★',
          authorId: 'usr_owner_local',
          authorRole: 'owner',
          body: '@Tất cả Chào mừng các đồng nghiệp đến với Phòng Chat Cộng Đồng GrandSpeak! Bấm ↩ Trả lời, thả cảm xúc hoặc gõ @ để tag đồng nghiệp ngay trong ca trực nhé ✨',
          isAnnouncement: true,
          pinned: true,
          replyTo: null,
          reactions: { '❤️': ['usr_owner_local'], '✨': ['usr_minh_anh'] },
          followers: ['usr_owner_local'],
          createdAt: new Date().toISOString(),
        },
      ],
      sopReceipts: {},
      foodShifts: {},
      voicePrefs: { voice: 'alloy', speed: 1.0, accent: 'en-US' },
      companionScripts: {},
      lastRoleplay: null,
      smtpConfig: { host: 'smtp.gmail.com', port: 465, user: '', pass: '' },
    };
  }

  function escHtmlMail(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function buildEmailSignatureBlock() {
    return `<div data-gs-signature="1" style="padding:18px 24px 20px;background:#0b231a;border-top:1px solid rgba(201,154,59,0.45);color:#f7f3e8;font-family:'Segoe UI',Arial,sans-serif">
      <div style="font-size:12.5px;color:#d6e5dd;font-style:italic;margin-bottom:12px">
        Trân trọng &amp; Chúc bạn một ca học tập hiệu quả,<br>
        <span style="font-size:11.5px;color:#9eb7ac">With Warmest Five-Star Hospitality Regards,</span>
      </div>
      <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="width:100%">
        <tr>
          <td valign="top" style="width:58px;padding-right:12px">
            <img src="https://grandspeak.vercel.app/logo.png" alt="GrandSpeak" width="50" height="50" style="display:block;width:50px;height:50px;border-radius:12px;border:1.5px solid #e2be6f;object-fit:cover">
          </td>
          <td valign="top" style="font-size:12.5px;line-height:1.55">
            <div style="font-size:10px;letter-spacing:0.14em;color:#ecc978;font-weight:700">FIVE-STAR HOTEL &amp; RESORT EDUCATION</div>
            <div style="font-size:15px;font-weight:800;color:#ffffff">GRANDSPEAK · HOSPITALITY ENGLISH ACADEMY</div>
            <div style="font-size:12px;color:#c7dbd1;margin-bottom:6px">Hội Đồng Đào Tạo Ngôn Ngữ &amp; Tiêu Chuẩn Nghiệp Vụ Khách Sạn 5 Sao</div>
            <div style="font-size:11.5px;color:#f5e6c4;margin-bottom:6px">✨ <em>“Tinh tế trong từng lời chào, chuẩn mực trong mỗi ca trực.”</em></div>
            <div style="font-size:11.5px;color:#e3ede8">
              🌐 <a href="https://grandspeak.vercel.app/app" style="color:#f4d384;text-decoration:none;font-weight:700">grandspeak.vercel.app/app</a>
              &nbsp;·&nbsp;
              🏝️ <a href="https://grandspeak.vercel.app/resort" style="color:#f4d384;text-decoration:none;font-weight:700">Đảo Resort 3D</a>
            </div>
            <div style="font-size:10.5px;color:#8fa99d;margin-top:4px">🎓 Front Office · Fine Dining · Mixology &amp; Sommelier · Housekeeping · VIP Butler SOP</div>
          </td>
        </tr>
      </table>
      <div style="margin-top:12px;padding-top:10px;border-top:1px solid rgba(255,255,255,0.1);font-size:10.5px;color:#8aa398;text-align:center">
        🔒 Thư tự động từ Hệ thống Quản trị Đào tạo &amp; Định danh Nhân sự <strong>GrandSpeak</strong> · Vui lòng không chia sẻ mã xác thực OTP.
      </div>
    </div>`;
  }

  function buildWelcomeMailHtml(member) {
    return `<div style="font-family:'Segoe UI',Arial,sans-serif;max-width:600px;margin:0 auto;background:#0e2c21;color:#f7f3e8;border-radius:16px;overflow:hidden;border:1px solid #c99a3b">
      <div style="padding:22px 26px;background:linear-gradient(135deg,#181c22,#103529);border-bottom:1px solid rgba(201,154,59,0.4)">
        <div style="font-size:11px;letter-spacing:0.12em;color:#e8c472;font-weight:700">GRANDSPEAK · HOSPITALITY ENGLISH 5★</div>
        <h1 style="margin:6px 0 0;font-size:22px;color:#ffffff">🎉 Đăng ký Tài khoản Thành công!</h1>
      </div>
      <div style="padding:24px 26px;background:#ffffff;color:#143628">
        <p style="margin:0 0 14px;font-size:15px">Kính chào đồng nghiệp <strong>${escHtmlMail(member.name)}</strong>,</p>
        <p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#2f4f41">Chào mừng bạn chính thức gia nhập <strong>Học viện Tiếng Anh &amp; Nghiệp vụ Khách sạn 5 Sao GrandSpeak</strong>. Hồ sơ năng lực và Huy hiệu Cấp bậc của bạn đã được kích hoạt:</p>
        <div style="background:#f5f9f6;border:1px solid #cfe0d6;border-radius:12px;padding:16px 18px;margin-bottom:18px">
          <div style="margin-bottom:8px"><span style="display:inline-block;background:#144233;color:#ffe4a0;padding:4px 12px;border-radius:999px;font-size:12px;font-weight:700">${escHtmlMail(member.rankBadge || '🛡️ Nhân viên 5★')}</span></div>
          <div style="font-size:13.5px;line-height:1.75;color:#173b2c">
            <div>• <strong>Họ và tên nhân sự:</strong> ${escHtmlMail(member.name)}</div>
            <div>• <strong>Mã định danh đăng nhập:</strong> <code>${escHtmlMail(member.identifier)}</code></div>
            <div>• <strong>Email bảo mật:</strong> ${escHtmlMail(member.email)}</div>
            <div>• <strong>Khối / Bộ phận:</strong> ${escHtmlMail(member.areaLabel || member.department)}</div>
            <div>• <strong>Cấp bậc &amp; Chức danh:</strong> ${escHtmlMail(member.rankTitle || member.department)}</div>
          </div>
        </div>
        <p style="margin:0;font-size:13.5px;color:#39584a">🔒 Hãy đăng nhập tại <a href="https://grandspeak.vercel.app/app" style="color:#0f5132;font-weight:700">grandspeak.vercel.app/app</a> để bắt đầu lộ trình rèn luyện phản xạ tiếng Anh 5 sao của bạn!</p>
      </div>
      ${buildEmailSignatureBlock()}
    </div>`;
  }

  function buildOtpMailHtml(member, otpCode) {
    return `<div style="font-family:'Segoe UI',Arial,sans-serif;max-width:600px;margin:0 auto;background:#0e2c21;color:#f7f3e8;border-radius:16px;overflow:hidden;border:1px solid #c99a3b">
      <div style="padding:22px 26px;background:linear-gradient(135deg,#103529,#1d523f);border-bottom:1px solid rgba(201,154,59,0.4)">
        <div style="font-size:11px;letter-spacing:0.12em;color:#e8c472;font-weight:700">5-STAR SECURITY OTP · GRANDSPEAK</div>
        <h1 style="margin:6px 0 0;font-size:21px;color:#ffffff">🔑 Mã Xác Nhận Bảo Mật Tài Khoản</h1>
      </div>
      <div style="padding:24px 26px;background:#ffffff;color:#143628">
        <p style="margin:0 0 12px;font-size:15px">Kính chào <strong>${escHtmlMail(member.name)}</strong> (<code>${escHtmlMail(member.identifier)}</code>),</p>
        <p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#2f4f41">Hệ thống vừa tiếp nhận yêu cầu đặt lại mật khẩu cho hồ sơ nhân sự của bạn tại <strong>GrandSpeak</strong>. Vui lòng nhập <strong>Mã xác nhận 6 chữ số (OTP)</strong> dưới đây vào ứng dụng:</p>
        <div style="text-align:center;margin:20px 0;padding:18px;background:linear-gradient(135deg,#fffdf5,#f8ecd0);border:2px dashed #c99a3b;border-radius:14px">
          <div style="font-size:11px;font-weight:700;color:#7a5813;letter-spacing:0.1em;margin-bottom:6px">MÃ XÁC NHẬN 6 SỐ CỦA BẠN</div>
          <div style="font-size:34px;font-weight:900;letter-spacing:10px;color:#103529;font-family:Consolas,monospace">${escHtmlMail(otpCode)}</div>
          <div style="font-size:12px;color:#5c6f65;margin-top:6px">Hiệu lực trong vòng <strong>10 phút</strong> · Tuyệt đối không chia sẻ mã này</div>
        </div>
        <p style="margin:0;font-size:12.5px;color:#5a7065">Nếu bạn không thực hiện yêu cầu này, vui lòng bỏ qua thư — tài khoản của bạn vẫn được bảo vệ an toàn.</p>
      </div>
      ${buildEmailSignatureBlock()}
    </div>`;
  }

  let serverMailStatusCache = null;
  function resolveMailEndpoint() {
    const h = String(window.location?.hostname || '').toLowerCase();
    if (h.endsWith('.vercel.app')) return '/api/send-mail';
    return 'https://grandspeak.vercel.app/api/send-mail';
  }

  async function trySendRealVercelEmail(db, { to, subject, html, overrideCreds = null }) {
    if (!to || !to.includes('@') || to.endsWith('.local')) {
      return { delivered: false, delivery: 'local-device', message: '' };
    }
    const cfg = overrideCreds || db.smtpConfig || {};
    try {
      const r = await nativeFetch(resolveMailEndpoint(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to,
          subject,
          html,
          smtpUser: cfg.user || '',
          smtpPass: cfg.pass || '',
          smtpHost: cfg.host || 'smtp.gmail.com',
          smtpPort: cfg.port || 465,
        }),
      });
      const d = await r.json();
      if (r.ok && d?.delivered) {
        return { delivered: true, delivery: 'gmail-smtp', message: d.message || '' };
      }
      return { delivered: false, delivery: 'local-device', error: d?.message || '' };
    } catch (err) {
      return { delivered: false, delivery: 'local-device', error: err?.message || '' };
    }
  }

  function loadDb() {
    try {
      const raw = localStorage.getItem(DB_KEY) || window.__ACADEMY_NATIVE_RESTORED_DB || '';
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.users) && parsed.users.length > 0) {
          return parsed;
        }
      }
    } catch {}
    const fresh = defaultDb();
    saveDb(fresh);
    return fresh;
  }

  function saveDb(db) {
    try {
      const raw = JSON.stringify(db);
      localStorage.setItem(DB_KEY, raw);
      syncDbToNative(raw);
    } catch {}
  }

  // Auto-seed active session on very first launch so user enters the app seamlessly
  // (while still allowing Logout / Register / Switch Account at any time!)
  (function bootstrapFirstRunSession() {
    const db = loadDb();
    try {
      const hasExplicitLogout = sessionStorage.getItem('gs_explicit_logout') === '1';
      if (!hasExplicitLogout && db.activeUserId && !localStorage.getItem(AUTH_CACHE_KEY)) {
        const u = db.users.find((x) => x.id === db.activeUserId) || db.users[0];
        if (u) {
          const pub = publicUser(u);
          const tk = db.activeToken || makeHexToken();
          db.activeToken = tk;
          db.sessions[tk] = u.id;
          saveDb(db);
          localStorage.setItem(MOBILE_TOKEN_KEY, tk);
          localStorage.setItem(AUTH_CACHE_KEY, JSON.stringify(pub));
        }
      }
      const cur = getCurrentUser(db);
      if (cur && ['owner', 'admin'].includes(cur.role)) {
        window.academyAdminAllowed = true;
        window.academyAdminRole = cur.role;
      } else {
        window.academyAdminAllowed = true;
        window.academyAdminRole = 'owner';
      }
    } catch {}
  })();

  // =========================================================================
  // UNIVERSAL SMOOTH SCROLL & VIEW TRANSITION HELPER
  // =========================================================================
  window.academyScrollTop = function (smooth = true) {
    const behavior = smooth ? 'smooth' : 'auto';
    try {
      window.scrollTo({ top: 0, behavior });
    } catch {
      window.scrollTo(0, 0);
    }
    for (const sel of ['.main', '.content', '#app']) {
      const el = document.querySelector(sel);
      if (el && el.scrollTop > 0) {
        try {
          el.scrollTo({ top: 0, behavior });
        } catch {
          el.scrollTop = 0;
        }
      }
    }
  };

  window.academyScrollTo = function (selector, offsetPx = 86) {
    requestAnimationFrame(() => {
      setTimeout(() => {
        const el = typeof selector === 'string' ? document.querySelector(selector) : selector;
        if (!el) return;
        const rect = el.getBoundingClientRect();
        const targetY = Math.max(0, window.scrollY + rect.top - offsetPx);
        try {
          window.scrollTo({ top: targetY, behavior: 'smooth' });
        } catch {
          window.scrollTo(0, targetY);
        }
        el.classList?.remove('gs-jump-highlight');
        void el.offsetWidth;
        el.classList?.add('gs-jump-highlight');
      }, 25);
    });
  };

  // Inject subtle CSS for Pronunciation Score Cards & Auto-Scroll Highlight Pulse
  (function injectStandaloneStyles() {
    if (typeof document === 'undefined') return;
    const inject = () => {
      if (document.getElementById('gs-standalone-pro-css')) return;
      const st = document.createElement('style');
      st.id = 'gs-standalone-pro-css';
      st.textContent = `
        @keyframes gsJumpPulse {
          0% { box-shadow: 0 0 0 0 rgba(201, 154, 59, 0.55); }
          60% { box-shadow: 0 0 0 10px rgba(201, 154, 59, 0); }
          100% { box-shadow: 0 0 0 0 rgba(201, 154, 59, 0); }
        }
        .gs-jump-highlight { animation: gsJumpPulse 1.1s ease-out; border-radius: 14px; }
        .gs-pron-card { margin-top: 10px; padding: 13px 15px; border-radius: 14px; border: 1.5px solid rgba(201,154,59,0.45); background: linear-gradient(135deg, rgba(16,53,41,0.06), rgba(201,154,59,0.09)); color: inherit; text-align: left; }
        .gs-pron-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap; margin-bottom: 8px; }
        .gs-pron-pill { display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; border-radius: 999px; font-weight: 800; font-size: 13.5px; }
        .gs-pron-pill.is-good { background: #0f5132; color: #ffe8a3; }
        .gs-pron-pill.is-near { background: #8a5a00; color: #fff8e1; }
        .gs-pron-pill.is-low { background: #842029; color: #ffe3e3; }
        .gs-pron-words { display: flex; flex-wrap: wrap; gap: 5px; margin: 8px 0; }
        .gs-pron-w { border: 1px solid transparent; border-radius: 7px; padding: 3px 8px; font-size: 13.5px; font-weight: 700; cursor: pointer; background: rgba(255,255,255,0.7); }
        .gs-pron-w.w-good { background: #d1f2e0; color: #0b4628; border-color: #8ad6ad; }
        .gs-pron-w.w-near { background: #fff0c2; color: #6e4700; border-color: #e6c365; }
        .gs-pron-w.w-miss { background: #ffe0e0; color: #841c26; border-color: #f19ca2; text-decoration: underline wavy; }
        .gs-pron-heard { font-size: 12.5px; opacity: 0.88; margin: 4px 0; }
        .gs-pron-tip { font-size: 12.5px; font-weight: 600; color: #19523b; margin-top: 5px; }
        [data-night-mode="true"] .gs-pron-tip { color: #e8c97a; }
        .gs-pron-meter { height: 7px; border-radius: 999px; background: rgba(20,66,51,0.12); overflow: hidden; margin: 6px 0 8px; }
        .gs-pron-meter > span { display: block; height: 100%; border-radius: 999px; transition: width 0.35s ease; }
        .gs-pron-meter > span.is-good { background: linear-gradient(90deg, #0f5132, #198754); }
        .gs-pron-meter > span.is-near { background: linear-gradient(90deg, #b7791f, #ecc94b); }
        .gs-pron-meter > span.is-low { background: linear-gradient(90deg, #842029, #dc3545); }
        .gs-quick-mic-btn { display: inline-flex; align-items: center; gap: 5px; padding: 5px 11px; border-radius: 999px; border: 1px solid rgba(201,154,59,0.55); background: rgba(201,154,59,0.13); color: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer; transition: transform 0.12s ease, background 0.15s ease; }
        .gs-quick-mic-btn:active { transform: scale(0.97); }
        .gs-quick-mic-btn.is-listening { background: #b02a37; color: #fff; border-color: #b02a37; box-shadow: 0 0 0 3px rgba(176,42,55,0.22); }
        .is-speaking-audio { outline: 2px solid #c99a3b !important; box-shadow: 0 0 0 3px rgba(201,154,59,0.25) !important; }
        .flc-pdf-canvas-wrap { display: flex; flex-direction: column; gap: 14px; align-items: center; padding: 14px; background: #1e242b; border-radius: 14px; overflow-x: auto; }
        .flc-pdf-page-canvas-card { background: #fff; border-radius: 8px; box-shadow: 0 8px 26px rgba(0,0,0,0.28); max-width: 100%; overflow: hidden; }
        .flc-pdf-page-canvas-card canvas { display: block; width: 100%; height: auto; max-width: 920px; }
        .flc-pdf-page-tag { padding: 6px 12px; background: #0f291e; color: #f6df9d; font-size: 12px; font-weight: 700; display: flex; justify-content: space-between; }
      `;
      (document.head || document.documentElement).appendChild(st);
    };
    if (document.head) inject();
    else document.addEventListener('DOMContentLoaded', inject, { once: true });
  })();

  // =========================================================================
  // UNIVERSAL 3-TIER AUDIO TTS ENGINE (Works on All Web, PC & Mobile Apps)
  // =========================================================================
  let sharedTtsAudio = null;
  let universalTtsSeq = 0;
  let lastClickedListenBtn = null;
  const ttsBlobCache = new Map();

  function getSharedUnlockedAudio() {
    if (!sharedTtsAudio && typeof Audio !== 'undefined') {
      sharedTtsAudio = new Audio();
      sharedTtsAudio.preload = 'auto';
      sharedTtsAudio.setAttribute('playsinline', 'true');
      sharedTtsAudio.setAttribute('webkit-playsinline', 'true');
    }
    return sharedTtsAudio;
  }

  if (typeof document !== 'undefined') {
    const unlockShared = () => {
      try {
        if (navigator.audioSession && navigator.audioSession.type !== 'playback') {
          navigator.audioSession.type = 'playback';
        }
        const a = getSharedUnlockedAudio();
        if (a && !a.__gsUnlocked) {
          a.__gsUnlocked = true;
          a.muted = true;
          a.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';
          const p = a.play();
          if (p && p.then) {
            p.then(() => {
              a.pause();
              a.muted = false;
            }).catch(() => {
              a.muted = false;
            });
          } else {
            a.muted = false;
          }
        }
      } catch {}
    };
    document.addEventListener('touchstart', unlockShared, { once: true, passive: true });
    document.addEventListener('pointerdown', unlockShared, { once: true, passive: true });
    document.addEventListener(
      'click',
      (ev) => {
        const b = ev.target?.closest?.('[data-action="listen"], [data-hala-slow], .exsay, [data-say]');
        if (b) {
          lastClickedListenBtn?.classList?.remove('is-speaking-audio');
          lastClickedListenBtn = b;
        }
      },
      true
    );
  }

  function clearListenHighlight() {
    if (lastClickedListenBtn) {
      lastClickedListenBtn.classList?.remove('is-speaking-audio');
      lastClickedListenBtn = null;
    }
  }

  function resolveTtsEndpoint() {
    const h = String(window.location?.hostname || '').toLowerCase();
    if (h.endsWith('.vercel.app')) return '/api/tts';
    return 'https://grandspeak.vercel.app/api/tts';
  }

  window.academyUniversalTtsStop = function () {
    universalTtsSeq++;
    clearListenHighlight();
    if (sharedTtsAudio) {
      sharedTtsAudio.onplaying = sharedTtsAudio.onended = sharedTtsAudio.onerror = null;
      try {
        sharedTtsAudio.pause();
      } catch {}
    }
    try {
      window.academyNativeStopSpeak?.();
    } catch {}
    try {
      window.speechSynthesis?.cancel();
    } catch {}
  };

  function speakViaBrowserFallback(text, lang, rate, seq, onStart, onEnd) {
    if (!window.speechSynthesis || !window.SpeechSynthesisUtterance) {
      clearListenHighlight();
      if (typeof onEnd === 'function') onEnd();
      return;
    }
    try {
      window.speechSynthesis.cancel();
      setTimeout(() => {
        if (seq !== universalTtsSeq) return;
        const u = new SpeechSynthesisUtterance(text);
        u.lang = lang || 'en-US';
        u.rate = Math.max(0.5, Math.min(2.0, Number(rate) || 0.9));
        const voices = window.speechSynthesis.getVoices?.() || [];
        const match =
          voices.find((v) => (v.lang || '').toLowerCase() === u.lang.toLowerCase()) ||
          voices.find((v) => (v.lang || '').toLowerCase().startsWith(u.lang.slice(0, 2).toLowerCase()));
        if (match) u.voice = match;
        const safety = setTimeout(() => {
          if (seq === universalTtsSeq) {
            clearListenHighlight();
            if (typeof onEnd === 'function') onEnd();
          }
        }, Math.min(20000, 2200 + text.length * 100));
        u.onstart = () => {
          if (seq === universalTtsSeq) {
            lastClickedListenBtn?.classList?.add('is-speaking-audio');
            if (typeof onStart === 'function') onStart();
          }
        };
        u.onend = u.onerror = () => {
          clearTimeout(safety);
          if (seq === universalTtsSeq) {
            clearListenHighlight();
            if (typeof onEnd === 'function') onEnd();
          }
        };
        window.speechSynthesis.speak(u);
      }, 35);
    } catch {
      clearListenHighlight();
      if (typeof onEnd === 'function') onEnd();
    }
  }

  window.academyUniversalTtsPlay = function (text, lang = 'en-US', rate = 0.9, onStart = null, onEnd = null) {
    const clean = String(text || '')
      .replace(/[*↗↘]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!clean) {
      if (typeof onEnd === 'function') onEnd();
      return;
    }
    const targetBtn = lastClickedListenBtn;
    window.academyUniversalTtsStop();
    if (targetBtn) {
      lastClickedListenBtn = targetBtn;
      targetBtn.classList?.add('is-speaking-audio');
    }
    const seq = ++universalTtsSeq;

    // Tier 1: Native iOS AVSpeechSynthesizer / Android TextToSpeech inside IPA & APK
    if (typeof window.academyNativeSpeak === 'function') {
      window.academyNativeSpeak(
        clean,
        lang,
        rate,
        () => {
          if (seq === universalTtsSeq && typeof onStart === 'function') onStart();
        },
        () => {
          if (seq === universalTtsSeq) {
            clearListenHighlight();
            if (typeof onEnd === 'function') onEnd();
          }
        }
      );
      return;
    }

    // Tier 2: Cloud MP3 stream (/api/tts) via persistent unlocked <audio> + memory blob cache
    if (typeof navigator === 'undefined' || navigator.onLine !== false) {
      const audio = getSharedUnlockedAudio();
      if (audio) {
        try {
          if (navigator.audioSession && navigator.audioSession.type !== 'playback') {
            navigator.audioSession.type = 'playback';
          }
        } catch {}
        const cacheKey = `${lang}::${clean}`;
        const remoteUrl = `${resolveTtsEndpoint()}?accent=${encodeURIComponent(lang)}&text=${encodeURIComponent(clean)}`;
        const playSrc = (srcUrl) => {
          if (seq !== universalTtsSeq) return;
          try {
            audio.muted = false;
            audio.src = srcUrl;
            audio.playbackRate = Math.max(0.5, Math.min(2.0, Number(rate) || 0.9));
            audio.onplaying = () => {
              if (seq === universalTtsSeq) {
                audio.playbackRate = Math.max(0.5, Math.min(2.0, Number(rate) || 0.9));
                if (typeof onStart === 'function') onStart();
              }
            };
            audio.onended = () => {
              if (seq === universalTtsSeq) {
                clearListenHighlight();
                if (typeof onEnd === 'function') onEnd();
              }
            };
            audio.onerror = () => {
              if (seq === universalTtsSeq) speakViaBrowserFallback(clean, lang, rate, seq, onStart, onEnd);
            };
            const p = audio.play();
            if (p && typeof p.catch === 'function') {
              p.catch(() => {
                if (seq === universalTtsSeq) speakViaBrowserFallback(clean, lang, rate, seq, onStart, onEnd);
              });
            }
          } catch {
            if (seq === universalTtsSeq) speakViaBrowserFallback(clean, lang, rate, seq, onStart, onEnd);
          }
        };

        if (ttsBlobCache.has(cacheKey)) {
          playSrc(ttsBlobCache.get(cacheKey));
          return;
        }
        playSrc(remoteUrl);
        if (clean.length <= 240) {
          nativeFetch(remoteUrl)
            .then((r) => (r.ok ? r.blob() : null))
            .then((b) => {
              if (!b || !b.size) return;
              if (ttsBlobCache.size >= 80) {
                const oldest = ttsBlobCache.keys().next().value;
                const oldUrl = ttsBlobCache.get(oldest);
                ttsBlobCache.delete(oldest);
                try {
                  URL.revokeObjectURL(oldUrl);
                } catch {}
              }
              ttsBlobCache.set(cacheKey, URL.createObjectURL(b));
            })
            .catch(() => {});
        }
        return;
      }
    }

    // Tier 3: Offline Browser SpeechSynthesis fallback
    speakViaBrowserFallback(clean, lang, rate, seq, onStart, onEnd);
  };

  function publicUser(u) {
    if (!u) return null;
    const copy = { ...u };
    delete copy.passwordHash;
    delete copy.backup;
    return copy;
  }

  function getCurrentUser(db) {
    let token = '';
    try {
      token = localStorage.getItem(MOBILE_TOKEN_KEY) || '';
    } catch {}
    if (token && db.sessions && db.sessions[token]) {
      const found = db.users.find((x) => x.id === db.sessions[token]);
      if (found) return found;
    }
    if (db.activeUserId) {
      return db.users.find((x) => x.id === db.activeUserId) || null;
    }
    return null;
  }

  // =========================================================================
  // LOCAL PRONUNCIATION SCORER (Word-level, Contraction & Ending Analysis)
  // =========================================================================
  const SPOKEN_EQUIV = {
    "i'll": 'i will',
    "i'd": 'i would',
    "i'm": 'i am',
    "i've": 'i have',
    "we'll": 'we will',
    "we're": 'we are',
    "we've": 'we have',
    "you're": 'you are',
    "you'll": 'you will',
    "it's": 'it is',
    "that's": 'that is',
    "there's": 'there is',
    "don't": 'do not',
    "doesn't": 'does not',
    "can't": 'cannot',
    "won't": 'will not',
    "let's": 'let us',
    "ma'am": 'madam',
    mr: 'mister',
    mrs: 'missus',
    ms: 'miss',
    0: 'zero',
    1: 'one',
    2: 'two',
    3: 'three',
    4: 'four',
    5: 'five',
    6: 'six',
    7: 'seven',
    8: 'eight',
    9: 'nine',
    10: 'ten',
    11: 'eleven',
    12: 'twelve',
    14: 'fourteen',
    15: 'fifteen',
    20: 'twenty',
    30: 'thirty',
    50: 'fifty',
    100: 'one hundred',
  };

  function cleanWords(text) {
    const tokens = String(text || '')
      .toLowerCase()
      .replace(/[’‘]/g, "'")
      .replace(/[^a-z0-9'\s]/g, ' ')
      .split(/\s+/)
      .filter(Boolean);
    const expanded = [];
    for (const tk of tokens) {
      const mapped = SPOKEN_EQUIV[tk];
      if (mapped) expanded.push(...mapped.split(' '));
      else expanded.push(tk);
    }
    return expanded;
  }

  function editDistance(a, b) {
    const m = a.length;
    const n = b.length;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        dp[i][j] =
          a[i - 1] === b[j - 1]
            ? dp[i - 1][j - 1]
            : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
    }
    return dp[m][n];
  }

  window.gradeHospitalityPronunciation = function (targetText, heardText) {
    const rawTargetWords = String(targetText || '')
      .trim()
      .split(/\s+/)
      .filter(Boolean);
    const target = cleanWords(targetText);
    const heard = cleanWords(heardText);
    if (!heard.length) {
      return {
        configured: true,
        score: 0,
        words: rawTargetWords.map((w) => ({ word: w, state: 'miss' })),
        transcript: '',
        tip_vi: 'Chưa nghe rõ câu nói. Hãy giữ micro gần miệng hơn và đọc rõ từng từ nhé.',
      };
    }
    if (!target.length) {
      return {
        configured: true,
        score: 92,
        words: [],
        transcript: heardText,
        tip_vi: 'Giọng nói rõ ràng! Tiếp tục giữ nhịp điệu tự nhiên 5 sao.',
      };
    }
    let matched = 0;
    const missedEndings = [];
    const missedCore = [];
    const usedIdx = new Set();
    const wordDetails = rawTargetWords.map((origWord) => {
      const subParts = cleanWords(origWord);
      if (!subParts.length) return { word: origWord, state: 'good' };
      let partSum = 0;
      for (const tw of subParts) {
        let best = 0;
        let bestIdx = -1;
        for (let i = 0; i < heard.length; i++) {
          if (usedIdx.has(i) && heard[i] !== tw) continue;
          const hw = heard[i];
          if (tw === hw) {
            best = 1;
            bestIdx = i;
            break;
          }
          const dist = editDistance(tw, hw);
          const sim = 1 - dist / Math.max(tw.length, hw.length, 1);
          if (sim > best) {
            best = sim;
            bestIdx = i;
          }
          if (sim >= 0.68 && /(s|ed|t|d|k|v|ce|se|th)$/.test(tw) && hw === tw.slice(0, -1)) {
            missedEndings.push(origWord.replace(/[.,!?;:]+$/, ''));
          }
        }
        if (bestIdx >= 0 && best >= 0.55) usedIdx.add(bestIdx);
        partSum += best;
      }
      const avgBest = partSum / subParts.length;
      if (avgBest >= 0.84) {
        matched += 1;
        return { word: origWord, state: 'good' };
      }
      if (avgBest >= 0.55) {
        matched += 0.68;
        return { word: origWord, state: 'near' };
      }
      missedCore.push(origWord.replace(/[.,!?;:]+$/, ''));
      return { word: origWord, state: 'miss' };
    });

    const rawScore = Math.round(Math.min(100, Math.max(18, (matched / Math.max(1, rawTargetWords.length)) * 100)));
    let tip = '🌟 Phát âm chuẩn mực, rõ âm cuối và ngữ điệu rất tự tin chuẩn 5 sao!';
    if (missedEndings.length > 0) {
      tip = `💡 Chú ý bật rõ âm cuối ở từ “${missedEndings[0]}” để câu nói sang trọng và chuẩn xác hơn.`;
    } else if (missedCore.length > 0 && rawScore < 80) {
      tip = `💡 Bấm vào từ màu đỏ “${missedCore.slice(0, 2).join(', ')}” bên trên để nghe mẫu và đọc chậm lại nhé.`;
    } else if (rawScore < 85) {
      tip = '👍 Khá tốt! Hãy nối âm mượt hơn và hạ nhẹ giọng ấm áp ở cuối câu.';
    }
    return {
      configured: true,
      score: rawScore,
      words: wordDetails,
      transcript: String(heardText || '').trim(),
      tip_vi: tip,
    };
  };

  window.renderPronunciationScoreCard = function (targetText, heardText, awardXp = true) {
    const res = window.gradeHospitalityPronunciation(targetText, heardText);
    const s = res.score;
    const tierCls = s >= 85 ? 'is-good' : s >= 65 ? 'is-near' : 'is-low';
    const tierLabel = s >= 85 ? '🌟 Xuất sắc 5★' : s >= 65 ? '👍 Khá tốt' : '💪 Cần luyện thêm';
    if (awardXp && s >= 70 && typeof window.earn === 'function') {
      try {
        window.earn(5);
      } catch {}
    }
    const esc = (v) =>
      String(v || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    const wordsHtml = (res.words || []).length
      ? `<div class="gs-pron-words" aria-label="Chi tiết từng từ (bấm vào từ để nghe mẫu)">${res.words
          .map(
            (w) =>
              `<button type="button" class="gs-pron-w w-${w.state}" data-action="listen" data-value="${esc(
                w.word.replace(/[.,!?;:"'”]+$/g, '')
              )}" title="Bấm để nghe phát âm từ này">${esc(w.word)}</button>`
          )
          .join('')}</div>`
      : '';
    return `<div class="gs-pron-card" role="status">
      <div class="gs-pron-top">
        <span class="gs-pron-pill ${tierCls}">🎯 Điểm phát âm: ${s}/100 · ${tierLabel}</span>
        <div style="display:flex;gap:8px;align-items:center">
          ${s >= 70 ? '<small style="font-weight:700;color:#0f5132">+5 XP</small>' : ''}
          ${targetText ? `<button type="button" class="gs-pron-w" data-hala-slow="${esc(targetText)}" title="Nghe mẫu tốc độ chậm 0.65×">🐢 Nghe chậm</button>` : ''}
        </div>
      </div>
      <div class="gs-pron-meter" aria-hidden="true"><span class="${tierCls}" style="width:${Math.max(8, s)}%"></span></div>
      ${wordsHtml}
      ${res.transcript ? `<div class="gs-pron-heard">🎙️ Máy nhận diện: <strong>“${esc(res.transcript)}”</strong></div>` : ''}
      <div class="gs-pron-tip">${esc(res.tip_vi)}</div>
    </div>`;
  };

  // Global One-Click Inline Pronunciation Grader ([data-quick-grade="English phrase"])
  let activeQuickSr = null;
  let activeQuickBtn = null;
  let activeQuickTimer = 0;
  if (typeof document !== 'undefined') {
    document.addEventListener('click', (e) => {
      const btn = e.target.closest?.('[data-quick-grade]');
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation();
      const targetPhrase = String(btn.dataset.quickGrade || '').trim();
      if (!targetPhrase) return;
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SR) {
        if (typeof window.openPronunciationStudio === 'function') {
          window.openPronunciationStudio(targetPhrase, '', '');
        }
        return;
      }
      if (activeQuickSr && activeQuickBtn === btn) {
        try {
          activeQuickSr.stop();
        } catch {}
        return;
      }
      if (activeQuickSr) {
        try {
          activeQuickSr.abort();
        } catch {}
      }
      clearTimeout(activeQuickTimer);
      window.academyUniversalTtsStop?.();
      window.academyStopViSpeech?.();

      let slot = btn.parentElement?.parentElement?.querySelector?.('.gs-quick-grade-slot');
      if (!slot) {
        slot = document.createElement('div');
        slot.className = 'gs-quick-grade-slot';
        (
          btn.closest(
            '.button-row, .service-actions, .ops-phrase-actions, .flc-act-en-row, .flc-std-en-row, .vocab-actions, .star-phrase, .fs-actions, .md-flash-controls, .question-card, .glossary-card'
          ) ||
          btn.parentElement ||
          btn
        ).insertAdjacentElement('afterend', slot);
      }

      const origHtml = btn.dataset.origLabel || btn.innerHTML;
      btn.dataset.origLabel = origHtml;
      btn.classList.add('is-listening');
      btn.innerHTML = '⏹ Đang nghe… (Bấm để dừng)';
      slot.innerHTML = '<div class="gs-pron-card">🔴 <strong>Đang nghe từ Micro…</strong> Hãy đọc to câu tiếng Anh bên trên!</div>';

      const sr = new SR();
      activeQuickSr = sr;
      activeQuickBtn = btn;
      sr.lang = 'en-US';
      sr.interimResults = false;
      sr.maxAlternatives = 1;
      let gotResult = false;

      const restoreBtn = () => {
        clearTimeout(activeQuickTimer);
        btn.classList.remove('is-listening');
        btn.innerHTML = origHtml;
        if (activeQuickSr === sr) {
          activeQuickSr = null;
          activeQuickBtn = null;
        }
      };

      activeQuickTimer = setTimeout(() => {
        if (activeQuickSr === sr) {
          try {
            sr.stop();
          } catch {
            restoreBtn();
          }
        }
      }, 8000);

      sr.onresult = (ev) => {
        gotResult = true;
        const heard = Array.from(ev.results || [])
          .map((r) => r?.[0]?.transcript || '')
          .join(' ')
          .trim();
        slot.innerHTML = window.renderPronunciationScoreCard(targetPhrase, heard, true);
        restoreBtn();
      };
      sr.onerror = (ev) => {
        slot.innerHTML = `<div class="gs-pron-card">⚠️ ${
          ev?.error === 'not-allowed'
            ? 'Hãy bấm Cho phép (Allow) quyền Micro trên trình duyệt/điện thoại rồi thử lại nhé.'
            : 'Chưa nghe rõ giọng nói. Hãy đọc to hơn một chút và thử lại!'
        }</div>`;
        restoreBtn();
      };
      sr.onend = () => {
        if (!gotResult && activeQuickSr === sr) {
          slot.innerHTML = '<div class="gs-pron-card">⏹ Đã dừng nghe. Bấm lại nút <strong>🎙️ Chấm điểm</strong> để nói thử nhé!</div>';
        }
        restoreBtn();
      };
      try {
        sr.start();
      } catch {
        restoreBtn();
      }
    });
  }

  // Track most recent live SpeechRecognition transcript for MediaRecorder hybrid fallback
  window.__lastLiveSpeechTranscript = '';

  // =========================================================================
  // LOCAL OFFLINE DICTIONARY & HOSPITALITY AI COACH
  // =========================================================================
  function lookupOfflineWord(query) {
    const q = String(query || '').trim().toLowerCase();
    if (!q) return null;
    const allWords = [];
    if (Array.isArray(window.WORDS)) allWords.push(...window.WORDS);
    if (Array.isArray(window.MORE_WORDS)) allWords.push(...window.MORE_WORDS);
    if (Array.isArray(window.MEGA_LEXICON)) allWords.push(...window.MEGA_LEXICON);
    const hit =
      allWords.find((w) => String(w.id || w.term || w.en || '').toLowerCase() === q) ||
      allWords.find((w) => String(w.id || w.term || w.en || '').toLowerCase().includes(q));
    if (hit) {
      return {
        ok: true,
        word: hit.id || hit.term || hit.en || query,
        entry: {
          word: hit.id || hit.term || hit.en || query,
          ipa: hit.ipa || hit.pron || '',
          pos: hit.pos || 'hospitality term',
          vi: hit.vi || hit.meaning || '',
          definitions: [hit.context || hit.example || hit.chunk || hit.vi || 'Thuật ngữ chuyên ngành Khách sạn – Resort 5 sao.'],
          examples: [hit.chunk || hit.example || ''].filter(Boolean),
          audioUs: '',
          audioUk: '',
        },
      };
    }
    return {
      ok: true,
      word: query,
      entry: {
        word: query,
        ipa: '',
        pos: 'expression',
        vi: 'Bấm biểu tượng Loa để nghe phát âm trực tiếp trên thiết bị',
        definitions: ['Từ/cụm từ tiếng Anh giao tiếp trong môi trường dịch vụ khách sạn.'],
        examples: [],
        audioUs: '',
        audioUk: '',
      },
    };
  }

  async function callDirectGeminiOrLocalCoach(task, text, userKey, messages) {
    const cleanKey = String(userKey || localStorage.getItem('gs_personal_gemini_key') || '').trim();
    if (cleanKey) {
      try {
        localStorage.setItem('gs_personal_gemini_key', cleanKey);
        const promptText = messages
          ? messages.map((m) => `${m.role === 'user' ? 'Staff' : 'Coach'}: ${m.content || m.text || ''}`).join('\n')
          : `You are a 5-Star Luxury Hotel English Coach for Vietnamese staff. Task: ${task || 'coach'}. Input: ${text}. Reply concisely in bilingual English + Vietnamese.`;
        const r = await nativeFetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(cleanKey)}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contents: [{ parts: [{ text: promptText }] }] }),
          }
        );
        if (r.ok) {
          const d = await r.json();
          const out = d?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
          if (out.trim()) return out.trim();
        }
      } catch {}
    }
    // Instant Built-in Offline 5-Star Hospitality Coach
    const sample = String(text || (messages?.[messages.length - 1]?.content) || '').trim();
    const polite = sample
      ? sample
          .replace(/\bcan you\b/gi, 'Could you kindly')
          .replace(/\bwait\b/gi, 'allow me just a moment')
          .replace(/\bi want\b/gi, 'I would be delighted to')
          .replace(/\bno\b/gi, 'I am afraid at the moment')
      : 'Certainly, right away. It would be my pleasure to assist you.';
    return [
      '✨ **Gợi ý Chuẩn Dịch Vụ 5 Sao (Chế độ Độc lập trên thiết bị):**',
      `- **Câu nâng cấp lịch thiệp:** *"Certainly. ${polite.charAt(0).toUpperCase() + polite.slice(1)}"*`,
      '- **Mẫu câu thay thế sang trọng:** *"Allow me a moment to check this personally for you, Madam/Sir."*',
      '- **Mẹo phát âm:** Nhấn nhẹ vào từ *Certainly* và hạ giọng ấm áp ở cuối câu; bấm nút **Micro** để luyện đọc trực tiếp.',
    ].join('\n');
  }

  // =========================================================================
  // JSON RESPONSE HELPER & COMPLETE /api/* ROUTER
  // =========================================================================
  function jsonRes(obj, status = 200) {
    return new Response(JSON.stringify(obj), {
      status,
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
    });
  }

  function parseBody(init) {
    if (!init || !init.body) return {};
    if (typeof init.body === 'string') {
      try {
        return JSON.parse(init.body);
      } catch {
        return {};
      }
    }
    return {};
  }

  async function handleLocalApi(urlObj, init = {}) {
    const pathname = urlObj.pathname;
    const method = String(init.method || 'GET').toUpperCase();
    const body = parseBody(init);
    const db = loadDb();

    // 1. Health
    if (pathname === '/api/health') {
      return jsonRes({ ok: true, standalone: true, mode: 'on-device' });
    }

    // 2. Authentication & Local Staff Accounts (/api/auth)
    if (pathname === '/api/auth') {
      if (method === 'GET') {
        const u = getCurrentUser(db);
        if (!serverMailStatusCache && (typeof navigator === 'undefined' || navigator.onLine !== false)) {
          try {
            const mr = await nativeFetch(resolveMailEndpoint());
            if (mr.ok) serverMailStatusCache = await mr.json();
          } catch {}
        }
        const localSmtpUser = db.smtpConfig?.user || '';
        const smtpReady = Boolean((localSmtpUser && db.smtpConfig?.pass) || serverMailStatusCache?.configured);
        return jsonRes({
          authenticated: Boolean(u && u.status !== 'paused'),
          paused: Boolean(u && u.status === 'paused'),
          user: publicUser(u),
          sessionsCount: u ? 1 : 0,
          ownerNeedsSetup: false,
          ownerIdentifier: 'admin',
          isLoopback: true,
          smtpConfigured: smtpReady,
          smtpUser: localSmtpUser || serverMailStatusCache?.smtpUser || '',
          smtpHost: db.smtpConfig?.host || serverMailStatusCache?.smtpHost || 'smtp.gmail.com',
          smtpPort: Number(db.smtpConfig?.port) || 465,
          recentEmails: [],
        });
      }

      const action = body.action || '';
      if (action === 'save-smtp-config') {
        const user = String(body.user || '').trim();
        const pass = String(body.pass || '').replace(/\s+/g, '');
        const host = String(body.host || 'smtp.gmail.com').trim();
        const port = Number(body.port) || 465;
        const testEmail = String(body.testEmail || user).trim();
        if (!user || !user.includes('@')) {
          return jsonRes({ message: 'Vui lòng nhập địa chỉ Gmail gửi thư hợp lệ.' }, 400);
        }
        if (!pass && !db.smtpConfig?.pass) {
          return jsonRes({ message: 'Vui lòng nhập Mật khẩu ứng dụng Google 16 ký tự (App Password).' }, 400);
        }
        db.smtpConfig = {
          user,
          pass: pass || db.smtpConfig?.pass || '',
          host,
          port,
        };
        saveDb(db);
        const testRes = await trySendRealVercelEmail(db, {
          to: testEmail,
          subject: '✅ Kết nối Gmail SMTP Thành công — GrandSpeak 5★',
          html: `<div style="padding:20px;font-family:sans-serif;border:1px solid #c99a3b;border-radius:12px"><h2>🎉 Đã kết nối Máy chủ Gửi thư Gmail thật!</h2><p>Hệ thống <b>GrandSpeak (grandspeak.vercel.app)</b> đã gửi thử thành công tới <b>${escHtmlMail(testEmail)}</b>.</p><p>Từ nay mọi thông báo Đăng ký &amp; Mã OTP 6 số sẽ gửi thẳng về hộp thư Gmail người học.</p></div>`,
          overrideCreds: db.smtpConfig,
        });
        if (!testRes.delivered) {
          return jsonRes(
            {
              smtpConfigured: false,
              message:
                testRes.error ||
                'Chưa gửi thử được qua Gmail. Hãy kiểm tra Mật khẩu ứng dụng Google 16 ký tự (bật Xác minh 2 bước -> Mật khẩu ứng dụng).',
            },
            400
          );
        }
        return jsonRes({
          ok: true,
          smtpConfigured: true,
          smtpUser: user,
          message: `📨 Đã lưu cấu hình và gửi thử 1 thư thật tới hộp thư Gmail "${testEmail}"! Hãy mở Gmail kiểm tra.`,
        });
      }

      if (action === 'register' || action === 'setup-owner') {
        const identifier = String(body.identifier || 'nv001').trim().toLowerCase();
        const email = String(body.email || `${identifier}@grandspeak.local`).trim().toLowerCase();
        const exists = db.users.find(
          (x) => x.identifier.toLowerCase() === identifier || (email && x.email?.toLowerCase() === email)
        );
        if (exists && action === 'register') {
          return jsonRes(
            { message: `Mã đăng nhập hoặc Email "${identifier}" đã tồn tại trên thiết bị này. Hãy chuyển sang Đăng nhập!` },
            409
          );
        }
        const now = new Date().toISOString();
        const newUser = {
          id: 'usr_' + Date.now().toString(36),
          identifier,
          name: String(body.name || identifier).trim(),
          email,
          role: action === 'setup-owner' || db.users.length === 0 ? 'owner' : 'admin',
          status: 'active',
          areaId: body.areaId || 'restaurant',
          areaLabel: body.areaLabel || 'Nhà Hàng & Ẩm Thực',
          rankId: body.rankId || 'waiter',
          rankTitle: body.rankTitle || 'Nhân viên Phục vụ Nhà hàng',
          rankTier: body.rankTier || 'staff',
          rankBadge: body.rankBadge || '🛡️ Cấp Nhân Viên Chính Thức',
          department: body.department || 'Server',
          passwordHash: simpleHash('gs-salt:' + String(body.password || '1234')),
          revision: 0,
          backup: null,
          createdAt: now,
          updatedAt: now,
        };
        if (exists && action === 'setup-owner') {
          Object.assign(exists, newUser, { id: exists.id });
        } else {
          db.users.push(newUser);
        }
        saveDb(db);
        const welcomeHtml = buildWelcomeMailHtml(newUser);
        const mailRes = await trySendRealVercelEmail(db, {
          to: email,
          subject: '🎉 Chào mừng gia nhập GrandSpeak · Hospitality English 5★',
          html: welcomeHtml,
        });
        return jsonRes({
          ok: true,
          registeredIdentifier: identifier,
          message: mailRes.delivered
            ? `📨 Đã tạo hồ sơ "${newUser.name}" và gửi thư xác nhận thẳng về hộp thư Gmail "${email}"! Hãy nhập mật khẩu bên dưới để đăng nhập.`
            : `✅ Đã tạo hồ sơ "${newUser.name}" (${newUser.rankBadge})! Hãy nhập mật khẩu bên dưới để đăng nhập.`,
          mailPreview: {
            to: email,
            subject: 'Chào mừng gia nhập Học viện GrandSpeak 5 Sao',
            delivery: mailRes.delivered ? 'gmail-smtp' : 'local-device',
            html: welcomeHtml,
          },
        });
      }

      if (action === 'login') {
        const idRaw = String(body.identifier || '').trim().toLowerCase();
        const pwd = String(body.password || '');
        const u = db.users.find(
          (x) => x.identifier.toLowerCase() === idRaw || (x.email && x.email.toLowerCase() === idRaw)
        );
        if (!u) {
          return jsonRes(
            { message: 'Chưa tìm thấy tài khoản này trên thiết bị (Tài khoản mặc định: admin / 123456, hoặc bấm Đăng ký hồ sơ mới).' },
            401
          );
        }
        if (u.passwordHash !== simpleHash('gs-salt:' + pwd)) {
          return jsonRes({ message: 'Mật khẩu chưa đúng. (Nếu dùng tài khoản admin mặc định, mật khẩu là 123456).' }, 401);
        }
        const token = makeHexToken();
        db.sessions[token] = u.id;
        db.activeUserId = u.id;
        db.activeToken = token;
        saveDb(db);
        try {
          sessionStorage.removeItem('gs_explicit_logout');
        } catch {}
        return jsonRes({
          ok: true,
          authenticated: true,
          sessionToken: token,
          sessionsCount: 1,
          user: publicUser(u),
        });
      }

      if (action === 'request-otp') {
        const idRaw = String(body.identifier || body.email || '').trim().toLowerCase();
        const targetEmailInput = String(body.email || '').trim().toLowerCase();
        const u =
          db.users.find((x) => x.identifier.toLowerCase() === idRaw || (x.email && x.email.toLowerCase() === idRaw)) ||
          db.users[0];
        const recipientEmail = targetEmailInput && targetEmailInput.includes('@') ? targetEmailInput : u.email;
        const code = String(Math.floor(100000 + Math.random() * 900000));
        db.otps[u.identifier.toLowerCase()] = { code, expiresAt: Date.now() + 10 * 60 * 1000 };
        saveDb(db);
        const otpHtml = buildOtpMailHtml(u, code);
        const mailRes = await trySendRealVercelEmail(db, {
          to: recipientEmail,
          subject: `🔑 Mã OTP xác nhận GrandSpeak: ${code}`,
          html: otpHtml,
        });
        return jsonRes({
          ok: true,
          identifier: u.identifier,
          maskedEmail: recipientEmail || 'thiet-bi-cuc-bo',
          cooldownSec: 15,
          expiresAt: Date.now() + 10 * 60 * 1000,
          message: mailRes.delivered
            ? `📨 Đã gửi Mã xác nhận 6 chữ số thẳng về hộp thư Gmail "${recipientEmail}"! Hãy mở Gmail lấy mã OTP nhập vào bên dưới.`
            : `🔑 Mã xác nhận đặt lại mật khẩu của bạn là: ${code} (Mở mục ⚙️ Cấu hình Gmail SMTP bên dưới nếu muốn gửi thẳng về hộp thư Gmail thật).`,
          mailPreview: mailRes.delivered
            ? {
                to: recipientEmail,
                subject: `Đã gửi Mã OTP 6 số tới hộp thư Gmail của bạn`,
                delivery: 'gmail-smtp',
                html: '',
              }
            : {
                to: recipientEmail || u.identifier,
                subject: `Mã OTP đặt lại mật khẩu: ${code}`,
                delivery: 'local-device',
                html: otpHtml,
              },
        });
      }

      if (action === 'verify-otp-reset') {
        const idRaw = String(body.identifier || '').trim().toLowerCase();
        const u = db.users.find((x) => x.identifier.toLowerCase() === idRaw) || getCurrentUser(db) || db.users[0];
        const savedOtp = db.otps[u.identifier.toLowerCase()];
        if (savedOtp && savedOtp.code !== String(body.otpCode || '').trim()) {
          return jsonRes({ message: 'Mã xác nhận 6 số chưa khớp. Hãy kiểm tra mã hiển thị ngay phía trên.' }, 400);
        }
        u.passwordHash = simpleHash('gs-salt:' + String(body.newPassword || '123456'));
        u.updatedAt = new Date().toISOString();
        delete db.otps[u.identifier.toLowerCase()];
        saveDb(db);
        return jsonRes({
          ok: true,
          identifier: u.identifier,
          sessionsCount: 1,
          message: '✅ Đã cập nhật mật khẩu mới ngay trên thiết bị!',
        });
      }

      if (action === 'update-profile') {
        const u = getCurrentUser(db) || db.users[0];
        if (body.name) u.name = String(body.name).trim();
        if (body.email) u.email = String(body.email).trim();
        for (const k of ['areaId', 'areaLabel', 'rankId', 'rankTitle', 'rankTier', 'rankBadge', 'department']) {
          if (body[k]) u[k] = body[k];
        }
        u.updatedAt = new Date().toISOString();
        saveDb(db);
        return jsonRes({ ok: true, user: publicUser(u) });
      }

      if (action === 'logout') {
        db.activeUserId = '';
        db.activeToken = '';
        db.sessions = {};
        saveDb(db);
        try {
          sessionStorage.setItem('gs_explicit_logout', '1');
        } catch {}
        return jsonRes({ ok: true });
      }

      return jsonRes({ ok: true, sessionsCount: 1 });
    }

    // 3. Member Progress Backup (/api/member & /api/members)
    if (pathname === '/api/member') {
      const u = getCurrentUser(db) || db.users[0];
      if (method === 'GET') {
        return jsonRes({
          ok: true,
          revision: u?.revision || 0,
          updatedAt: u?.updatedAt || new Date().toISOString(),
          backup: u?.backup || { version: 1, exportedAt: new Date().toISOString(), data: {} },
        });
      }
      if (body.action === 'delete') {
        if (u) {
          u.backup = null;
          u.revision = 0;
          saveDb(db);
        }
        return jsonRes({ ok: true, revision: 0 });
      }
      if (u) {
        u.revision = (Number(u.revision) || 0) + 1;
        u.updatedAt = new Date().toISOString();
        u.backup = body.backup || null;
        saveDb(db);
      }
      return jsonRes({ ok: true, revision: u?.revision || 1, updatedAt: u?.updatedAt });
    }

    if (pathname === '/api/members') {
      return jsonRes({
        ok: true,
        members: db.users.map((u) => publicUser(u)),
      });
    }

    // 4. Local Pronunciation Grader (/api/pronunciation)
    if (pathname === '/api/pronunciation') {
      const heard = body.transcript || window.__lastLiveSpeechTranscript || '';
      if (heard) {
        window.__lastLiveSpeechTranscript = '';
        return jsonRes(window.gradeHospitalityPronunciation(body.targetText || '', heard));
      }
      return jsonRes({
        configured: false,
        score: 0,
        transcript: '',
        tip_vi: 'Đã ghi âm thành công trên thiết bị! Hãy nghe lại bản thu để đối chiếu ngữ điệu câu mẫu.',
      });
    }

    // 5. Content & Custom Studio (/api/content, /api/logo, /api/custom-library)
    if (pathname === '/api/content') {
      if (method === 'GET') {
        const u = getCurrentUser(db);
        return jsonRes({
          ok: true,
          isAdmin: Boolean(u && ['owner', 'admin'].includes(u.role)),
          adminRole: u?.role || 'owner',
          records: db.contentRecords || [],
        });
      }
      if (method === 'DELETE') {
        db.contentRecords = (db.contentRecords || []).filter((r) => !(r.kind === body.kind && r.id === body.id));
        saveDb(db);
        return jsonRes({ ok: true });
      }
      const now = new Date().toISOString();
      const idx = (db.contentRecords || []).findIndex((r) => r.kind === body.kind && r.id === body.id);
      const rec = { kind: body.kind, id: body.id, value: body.value, updatedAt: now };
      if (idx >= 0) db.contentRecords[idx] = rec;
      else db.contentRecords.push(rec);
      saveDb(db);
      return jsonRes({ ok: true, updatedAt: now });
    }

    if (pathname === '/api/custom-library') {
      if (method === 'GET') return jsonRes({ ok: true, ...(db.customLibrary || { sops: [], menus: [] }) });
      db.customLibrary = {
        sops: Array.isArray(body.sops) ? body.sops : db.customLibrary?.sops || [],
        menus: Array.isArray(body.menus) ? body.menus : db.customLibrary?.menus || [],
      };
      saveDb(db);
      return jsonRes({ ok: true, ...db.customLibrary });
    }

    // 6. Dictionary (/api/dict)
    if (pathname === '/api/dict') {
      const q = urlObj.searchParams.get('word') || urlObj.searchParams.get('q') || '';
      return jsonRes(lookupOfflineWord(q));
    }

    // 7. AI Tools & Chat (/api/ai-tools, /api/chat, /api/voice, /api/gemini)
    if (pathname === '/api/ai-tools') {
      if (method === 'GET') return jsonRes({ ok: true, configured: true, standalone: true });
      const result = await callDirectGeminiOrLocalCoach(body.task, body.text, body.key, null);
      return jsonRes({ ok: true, configured: true, result });
    }

    if (pathname === '/api/chat') {
      if (method === 'GET') return jsonRes({ ok: true, configured: true, standalone: true });
      const reply = await callDirectGeminiOrLocalCoach('roleplay-chat', '', body.key, body.messages || []);
      return jsonRes({ ok: true, configured: true, reply, message: reply });
    }

    if (pathname === '/api/voice' || pathname === '/api/gemini') {
      return jsonRes({ ok: true, configured: false, standalone: true });
    }

    // 8. Leaderboard, Forum, Community Chat, Shifts, SOP Receipts, Room Ping
    if (pathname === '/api/games-leaderboard') {
      if (method === 'POST' && body.score) {
        const u = getCurrentUser(db);
        db.leaderboard.unshift({
          id: 'lb_' + Date.now(),
          name: body.name || u?.name || 'Nhân viên 5★',
          department: body.department || u?.department || 'Server',
          game: body.game || 'all',
          score: Number(body.score) || 0,
          updatedAt: new Date().toISOString(),
        });
        db.leaderboard.sort((a, b) => b.score - a.score);
        db.leaderboard = db.leaderboard.slice(0, 30);
        saveDb(db);
      }
      return jsonRes({ ok: true, entries: db.leaderboard, leaderboard: db.leaderboard });
    }

    if (pathname === '/api/community-chat') {
      const u = getCurrentUser(db) || db.users[0] || { id: 'usr_local', name: 'Thành viên GrandSpeak', role: 'admin', department: 'Server' };
      const viewerId = u.id || 'usr_local';
      const viewerName = u.name || 'Thành viên GrandSpeak';
      const viewerRole = String(u.role || 'admin').toLowerCase();
      const viewerDept = u.areaLabel || u.department || 'Hospitality 5★';

      // 1. Try Live Shared Cloud Room first when online so all Web/iOS/Android users chat together!
      if (typeof navigator === 'undefined' || navigator.onLine !== false) {
        try {
          const isVercelHost = String(window.location?.hostname || '').toLowerCase().endsWith('.vercel.app');
          const cloudBase = isVercelHost ? '/api/community-chat' : 'https://grandspeak.vercel.app/api/community-chat';
          const cloudUrl =
            method === 'GET'
              ? `${cloudBase}?uid=${encodeURIComponent(viewerId)}&uname=${encodeURIComponent(viewerName)}&urole=${encodeURIComponent(viewerRole)}&udept=${encodeURIComponent(viewerDept)}`
              : cloudBase;
          const cloudInit =
            method === 'POST'
              ? {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ ...body, uid: viewerId, uname: viewerName, urole: viewerRole, udept: viewerDept }),
                }
              : { method: 'GET', cache: 'no-store' };
          const cr = await nativeFetch(cloudUrl, cloudInit);
          if (cr.ok) {
            const cdata = await cr.json();
            if (cdata && Array.isArray(cdata.messages)) {
              return jsonRes(cdata);
            }
          }
        } catch {}
      }

      // 2. Full Offline-Capable Local Fallback (100% compatible with community-chat.js & community-drawer.js)
      if (!Array.isArray(db.communityMessages)) db.communityMessages = [];
      // Migrate any legacy { sender, text } entries cleanly
      db.communityMessages = db.communityMessages.map((m) => ({
        id: m.id || 'cm_' + Date.now(),
        author: m.author || m.sender || 'Thành viên GrandSpeak',
        authorId: m.authorId || 'usr_owner_local',
        authorRole: m.authorRole || (m.role === 'Supervisor' ? 'owner' : 'member'),
        body: m.body || m.text || '',
        isAnnouncement: Boolean(m.isAnnouncement),
        pinned: Boolean(m.pinned),
        replyTo: m.replyTo || null,
        reactions: m.reactions && typeof m.reactions === 'object' && !Array.isArray(m.reactions) ? m.reactions : {},
        followers: Array.isArray(m.followers) ? m.followers : [],
        createdAt: m.createdAt || new Date().toISOString(),
      }));

      if (method === 'POST') {
        const act = String(body.action || (body.body || body.text ? 'send' : ''));
        if (act === 'send') {
          const msgText = String(body.body || body.text || '').trim().slice(0, 600);
          if (!msgText) return jsonRes({ message: 'Hãy nhập nội dung tin nhắn.' }, 400);
          let replyTo = null;
          if (body.replyToId) {
            const ref = db.communityMessages.find((x) => x.id === body.replyToId);
            if (ref) replyTo = { id: ref.id, author: ref.author, snippet: String(ref.body || '').slice(0, 100) };
          }
          db.communityMessages.push({
            id: 'cm_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 5),
            author: viewerName,
            authorId: viewerId,
            authorRole: viewerRole,
            body: msgText,
            isAnnouncement: Boolean(body.isAnnouncement),
            pinned: Boolean(body.pinNow),
            replyTo,
            reactions: {},
            followers: body.isAnnouncement || body.pinNow ? [viewerId] : [],
            createdAt: new Date().toISOString(),
          });
          db.communityMessages = db.communityMessages.slice(-100);
          saveDb(db);
        } else if (act === 'react') {
          const m = db.communityMessages.find((x) => x.id === body.id);
          const emo = String(body.emoji || '');
          if (m && emo) {
            const cur = Array.isArray(m.reactions[emo]) ? m.reactions[emo] : [];
            m.reactions[emo] = cur.includes(viewerId) ? cur.filter((x) => x !== viewerId) : [...cur, viewerId];
            saveDb(db);
          }
        } else if (act === 'pin') {
          const m = db.communityMessages.find((x) => x.id === body.id);
          if (m) {
            m.pinned = !m.pinned;
            saveDb(db);
          }
        } else if (act === 'follow') {
          const m = db.communityMessages.find((x) => x.id === body.id);
          if (m) {
            m.followers = m.followers.includes(viewerId)
              ? m.followers.filter((x) => x !== viewerId)
              : [...m.followers, viewerId];
            saveDb(db);
          }
        } else if (act === 'remove') {
          db.communityMessages = db.communityMessages.filter((x) => x.id !== body.id);
          saveDb(db);
        }
      }

      const formatted = db.communityMessages.map((m) => {
        const reactions = Object.entries(m.reactions || {})
          .map(([emoji, ids]) => ({
            emoji,
            count: Array.isArray(ids) ? ids.length : 0,
            mine: Array.isArray(ids) ? ids.includes(viewerId) : false,
          }))
          .filter((r) => r.count > 0);
        const lower = String(m.body || '').toLowerCase();
        const mentionedMe =
          lower.includes('@tất cả') ||
          lower.includes('@tat ca') ||
          lower.includes('@all') ||
          (viewerName && lower.includes('@' + viewerName.toLowerCase()));
        return {
          ...m,
          mine: m.authorId === viewerId || m.author === viewerName,
          reactions,
          following: m.followers.includes(viewerId),
          followCount: m.followers.length,
          mentionedMe,
        };
      });

      const members = [
        ...db.users.map((usr) => ({
          id: usr.id,
          name: usr.name,
          role: usr.role || 'member',
          dept: usr.areaLabel || usr.department || 'Thành viên',
        })),
        { id: 'usr_minh_anh', name: 'Minh Anh · Front Office', role: 'member', dept: 'Front Office' },
        { id: 'usr_hoang_nam', name: 'Hoàng Nam · Fine Dining', role: 'member', dept: 'Nhà Hàng' },
      ];

      return jsonRes({
        ok: true,
        canPost: true,
        moderator: viewerRole === 'owner' || viewerRole === 'admin',
        currentUser: { id: viewerId, name: viewerName, role: viewerRole },
        messages: formatted,
        pinnedMessages: formatted.filter((m) => m.pinned),
        members,
        onlineCount: members.length,
      });
    }

    if (pathname === '/api/forum') {
      if (method === 'POST' && body.title) {
        const u = getCurrentUser(db);
        db.forumPosts.unshift({
          id: 'fp_' + Date.now(),
          author: u?.name || 'Thành viên GrandSpeak',
          department: u?.department || 'Server',
          title: String(body.title).slice(0, 160),
          body: String(body.body || body.content || '').slice(0, 2000),
          likes: 1,
          comments: [],
          createdAt: new Date().toISOString(),
        });
        saveDb(db);
      }
      return jsonRes({ ok: true, posts: db.forumPosts });
    }

    if (pathname === '/api/voice-preferences') {
      if (method === 'POST') {
        db.voicePrefs = { ...db.voicePrefs, ...body };
        saveDb(db);
      }
      return jsonRes({ ok: true, preferences: db.voicePrefs, ...db.voicePrefs });
    }

    if (pathname === '/api/companion-scripts') {
      if (method === 'POST') {
        db.companionScripts = { ...db.companionScripts, ...body };
        saveDb(db);
      }
      return jsonRes({ ok: true, scripts: db.companionScripts });
    }

    if (pathname === '/api/sop-receipts') {
      const sopId = urlObj.searchParams.get('id') || body.id || 'default';
      if (method === 'POST') {
        db.sopReceipts[sopId] = { accepted: true, acceptedAt: new Date().toISOString() };
        saveDb(db);
      }
      return jsonRes({ ok: true, receipt: db.sopReceipts[sopId] || null, receipts: db.sopReceipts });
    }

    if (pathname === '/api/food-shifts') {
      const shiftId = urlObj.searchParams.get('id') || body.id || 'local-shift';
      if (method === 'POST') {
        db.foodShifts[shiftId] = { ...(db.foodShifts[shiftId] || {}), ...body, id: shiftId, updatedAt: new Date().toISOString() };
        saveDb(db);
      }
      return jsonRes({ ok: true, shift: db.foodShifts[shiftId] || null });
    }

    if (pathname === '/api/last-roleplay') {
      if (method === 'POST' && body.staffReply) {
        const text = String(body.staffReply || '').toLowerCase();
        const listenScore = /\b(understand|hear|see|frustrat|tired|long flight|important|serious|right away|certainly)\b/.test(text) ? 24 : 15;
        const apolScore = /\b(sorry|apologize|apologies|sincerely|regret|inconvenience)\b/.test(text) ? 25 : 12;
        const solveScore = /\b(check|replace|upgrade|prepare|manager|chef|immediately|minutes|lounge|fresh|remove|adjust)\b/.test(text) ? 24 : 14;
        const thankScore = /\b(thank|appreciate|patience|bringing this|pleasure|assist)\b/.test(text) ? 23 : 14;
        const total = Math.min(100, listenScore + apolScore + solveScore + thankScore);
        const turn = Number(body.turn) || 1;
        const resolved = turn >= 2 && total >= 70;
        const replyEn = resolved
          ? 'Thank you very much. I truly appreciate how quickly and professionally you handled this for me.'
          : 'I appreciate your apology. How quickly can you confirm the exact solution for me right now?';
        const replyVi = resolved
          ? 'Cảm ơn bạn rất nhiều. Tôi đánh giá cao sự chuyên nghiệp và tốc độ xử lý của bạn.'
          : 'Tôi ghi nhận lời xin lỗi của bạn. Vậy chính xác bao lâu nữa bạn hoàn tất phương án này cho tôi?';
        const rubric = {
          listen: listenScore,
          apologize: apolScore,
          solve: solveScore,
          thank: thankScore,
          total,
          coach_vi:
            total >= 85
              ? '🌟 Phản hồi chuẩn mực 5 sao theo đúng 4 bước L.A.S.T.!'
              : '💡 Mẹo 5 sao: Kết hợp đủ 4 yếu tố — Đồng cảm (I understand) + Xin lỗi chân thành (I sincerely apologize) + Thời gian cụ thể + Cảm ơn sự kiên nhẫn của khách.',
        };
        db.lastRoleplay = { ...body, rubric };
        saveDb(db);
        return jsonRes({ ok: true, rubric, guest_reply_en: replyEn, guest_reply_vi: replyVi, resolved });
      }
      return jsonRes({ ok: true, roleplay: db.lastRoleplay });
    }

    if (pathname === '/api/room-ping') {
      return jsonRes({ ok: true, peers: [], count: 1 });
    }

    // 9. Full 219-Document FLC SOP & Brand Standards Library (/api/flc-sop)
    if (pathname === '/api/flc-sop') {
      if (!window.__flcIndexCache) {
        try {
          const r = await nativeFetch('/flc-sop-index.json');
          if (r.ok) window.__flcIndexCache = await r.json();
        } catch {}
      }
      const baseDocs = Array.isArray(window.__flcIndexCache?.documents) ? window.__flcIndexCache.documents : [];
      const customDocs = Array.isArray(db.customFlcDocs) ? db.customFlcDocs : [];
      const allDocs = [...customDocs, ...baseDocs];

      if (method === 'POST') {
        if (body.action === 'add-doc') {
          const newDoc = {
            id: 'custom-flc-' + Date.now(),
            code: String(body.code || 'SOP.NEW.01').trim(),
            group: String(body.group || 'general').trim(),
            title: String(body.title || 'Quy trình mới').trim(),
            english: String(body.english || body.title || 'New SOP').trim(),
            sourceFile: String(body.fileName || '').trim(),
            pageCount: 1,
            pages: [String(body.contentText || body.title || '')],
            custom: true,
            pdfDataUrl: String(body.fileBase64 || ''),
          };
          db.customFlcDocs = [newDoc, ...customDocs];
          saveDb(db);
          return jsonRes({ ok: true, document: newDoc, total: allDocs.length + 1 });
        }
        if (body.action === 'delete-doc') {
          db.customFlcDocs = customDocs.filter((x) => x.id !== body.id);
          saveDb(db);
          return jsonRes({ ok: true });
        }
      }

      const id = (urlObj.searchParams.get('id') || '').trim();
      if (id) {
        const doc = allDocs.find((d) => d.id === id);
        if (!doc) return jsonRes({ message: 'Không tìm thấy tài liệu SOP FLC này.' }, 404);
        return jsonRes({ document: doc });
      }

      const group = (urlObj.searchParams.get('group') || 'all').trim();
      const q = String(urlObj.searchParams.get('q') || '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/đ/gi, 'd')
        .toLowerCase()
        .trim();

      const groupCounts = { all: allDocs.length };
      for (const d of allDocs) {
        groupCounts[d.group] = (groupCounts[d.group] || 0) + 1;
      }

      const filtered = allDocs
        .filter((d) => {
          if (group && group !== 'all' && d.group !== group) return false;
          if (!q) return true;
          const hay = [d.code, d.title, d.english, d.sourceFile, ...(Array.isArray(d.pages) ? d.pages : [])]
            .join(' ')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/đ/gi, 'd')
            .toLowerCase();
          return hay.includes(q);
        })
        .map((d) => ({
          id: d.id,
          code: d.code,
          dept: d.dept,
          group: d.group,
          title: d.title,
          english: d.english,
          sourceFile: d.sourceFile,
          pageCount: Number(d.pageCount) || (Array.isArray(d.pages) ? d.pages.length : 1),
          custom: Boolean(d.custom),
          hasPdf: Boolean(d.pdfFile || d.pdfDataUrl),
        }));

      return jsonRes({
        documents: filtered,
        total: allDocs.length || 219,
        totalPages: window.__flcIndexCache?.totalPages || 1012,
        groupCounts,
      });
    }

    if (pathname === '/api/donation') {
      return jsonRes({ ok: true, items: [] });
    }

    return jsonRes({ ok: true, standalone: true });
  }

  // Intercept all /api/* calls locally so ZERO server is ever needed!
  const nativeFetch = window.fetch.bind(window);
  window.fetch = function (input, init = {}) {
    try {
      const rawUrl = typeof input === 'string' ? input : input?.url || '';
      const resolved = new URL(rawUrl, window.location.origin && window.location.origin !== 'null' ? window.location.origin : 'http://127.0.0.1');
      if (resolved.pathname === '/api/tts-vi' || resolved.pathname === '/api/tts-en' || resolved.pathname === '/api/tts') {
        const accent =
          resolved.pathname === '/api/tts-vi'
            ? 'vi-VN'
            : resolved.searchParams.get('accent') || resolved.searchParams.get('lang') || 'en-US';
        const text = resolved.searchParams.get('text') || resolved.searchParams.get('q') || '';
        const targetTts = `${resolveTtsEndpoint()}?accent=${encodeURIComponent(accent)}&text=${encodeURIComponent(text)}`;
        return nativeFetch(targetTts, init);
      }
      if (resolved.pathname.startsWith('/api/') && resolved.pathname !== '/api/send-mail') {
        return handleLocalApi(resolved, init);
      }
    } catch {}
    return nativeFetch(input, init);
  };

  // Capture transcripts from any SpeechRecognition instance so hybrid MediaRecorder grading works offline
  const BaseSR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (BaseSR && !BaseSR.__gsWrapped) {
    const OrigProtoStart = BaseSR.prototype?.start;
    if (typeof OrigProtoStart === 'function') {
      BaseSR.prototype.start = function (...args) {
        this.addEventListener?.('result', (ev) => {
          try {
            const txt = Array.from(ev.results || [])
              .map((r) => r?.[0]?.transcript || '')
              .join(' ')
              .trim();
            if (txt) window.__lastLiveSpeechTranscript = txt;
          } catch {}
        });
        return OrigProtoStart.apply(this, args);
      };
      BaseSR.__gsWrapped = true;
    }
  }
})();
